# 问鼎经营分析

版本：1.0.0。包含7个独立Skill，通过现有问鼎CLI执行只读经营查询。每个Skill目录包含运行所需的场景规范、通用规则、CLI参数快照和Python标准库计算辅助，可以单独迁移完整目录。

| 场景 | Skill名称 | 默认交付 |
| --- | --- | --- |
| 问鼎会员客户分析 | `wd-member-analysis` | 对话完整表格与3—5条有依据的观察；不默认增加Excel。 |
| 问鼎CRM券效果 | `wd-coupon-effect` | 三张完整对话表格与本窗口观察；不默认增加Excel。 |
| 问鼎门店活动配置 | `wd-shop-activity-config` | 配置覆盖、组合、重点门店、全部明细及观察的对话表格。 |
| 问鼎门店开闭情况 | `wd-shop-open-close` | 完整对话及Excel；单Sheet“门店开闭情况”。 |
| 问鼎门店竞品流向 | `wd-shop-competitor-flow` | 七类汇总/明细板块及观察的完整对话表格。 |
| 问鼎门店人群画像 | `wd-shop-crowd-profile` | 对话汇总与观察＋交互HTML全部截取明细＋Excel单Sheet“门店人群画像”；用户要求对话全量时分批展示。 |
| 问鼎CRM营销效果 | `wd-crm-marketing-effect` | 两张8列表、各自合计与ROI算术均值、核心诊断；对话＋Excel单Sheet“CRM营销效果”。 |

## 使用

安装插件后新建Codex任务，用中文描述品牌、日期和需要的场景即可自动匹配，也可显式提及 `$wd-crm-marketing-effect` 等Skill名称。例如：“使用 $wd-crm-marketing-effect 查询【品牌】【开始日期】至【结束日期】返回状态为进行中的活动，输出对话和Excel。”将占位符换成真实参数。

此包不包含问鼎CLI、账号、令牌、业务数据、模型或电子表格库。需要可用的crm-brand-cli、品牌访问权限及其已登录运行目录。CLI不在PATH时可提供绝对路径或设置WENDING_CLI。计算辅助需要Python 3；生成Excel和后台HTML校验使用目标Codex环境可用的库与工具。

这是工作流插件：CLI负责取数，Skill引导参数核对、数据处理、输出和验证。首次使用仍须核对接口业务口径；结构校验及合成数据测试不代表真实品牌数据已验收。

## 安装与迁移

将解压后的完整 `wending-crm-analysis` 目录交给Codex，要求“使用plugin-creator安装此本地插件到个人marketplace”。首次安装应将目录放入用户的plugins目录，由官方scaffold工具登记个人marketplace，再执行 `codex plugin add wending-crm-analysis@个人marketplace实际名称`。不要只复制SKILL.md，也不应复制另一台机器的插件缓存或登录信息。

若仅安装某个Skill，复制其完整目录到目标Codex的用户skills目录即可；无需同时安装同名独立Skill与插件，避免重复发现。外部服务登录仍需在目标环境完成。已安装同名插件时按plugin-creator的更新及重装流程操作，保留其他插件与现有marketplace配置。

## 来源与验证

业务规范来自用户确认的“问鼎cli-精选skill合集-修订版.md”，七个场景正文和通用规则完整保留。CLI帮助参考采集于2026-09-07。发布包的SHA-256文件清单用于检查完整性，不是发布者签名。原规范文件和完整开发校验记录位于交付目录，不写入业务结果。
