# CLI参数参考

以下是2026-09-07本机命令帮助快照，只证明当时的参数和字段声明。首次使用或版本变化时应与当前 `--help` 对照；业务口径及权限需运行时核实。

## query-shop-crowd-profile

```text
Usage: crm-brand-cli data-analysis query-shop-crowd-profile 

           [OPTIONS]



  查询 CRM 门店人群画像（dataset 10002431，EAV 键值对画像，单日快照）



  注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。



  可选分组维度（group，默认全部 7 个，可用 --dimensions 选子集）：

    商户ID / 城市id / 交易类型 / 周期类型 / 投放人群类型 / 画像维度类型 / 画像维度值



  可查询指标（2 个，默认全部）：人数占比 / 淘宝闪购用户数



  可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions



  注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，

      禁止作为查询/分组条件，由后端自动注入。

      画像为“维度类型+维度值”键值对（如性别=男），需用 --filter "画像维度类型=性别" 选定画像维度。



Options:

  --filter TEXT                   维度筛选，格式

                                  维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）

  --date TEXT                     业务日期 yyyyMMdd 单日快照（默认昨天）

  --metrics TEXT                  需要查询的指标标准名，逗号分隔；默认全部2个

  --order-by-field TEXT           排序字段，不传则不排序

  --sort-order [asc|desc]         排序方向  [default: asc]

  --page INTEGER                  页码  [default: 1]

  --page-size INTEGER             每页条数  [default: 1000]

  --query-count / --no-query-count

                                  是否返回总行数  [default: query-count]

  --dimensions TEXT               需要分组的维度标准名，逗号分隔；默认全部维度

  --help                          Show this message and exit.
```

