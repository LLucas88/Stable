# CLI参数参考

以下是2026-09-07本机命令帮助快照，只证明当时的参数和字段声明。首次使用或版本变化时应与当前 `--help` 对照；业务口径及权限需运行时核实。

## query-shop-activity-config

```text
Usage: crm-brand-cli data-analysis query-shop-activity-config 

           [OPTIONS]



  查询 CRM 门店活动配置明细（dataset 10002365，一行一门店，单日快照）



  注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。



  可选分组维度（group，可用 --dimensions 选子集）：crm门店id / crm门店名称



  可查询指标（12 个 0/1 标志位，默认全部）：

    是否开通会员卡 / 是否开通开卡礼 / 是否开通会员特价菜 / 是否开通新会员特价菜 /

    是否开通等级礼 / 是否开通会员粉丝群 / 是否开通累计消费次数送券活动 /

    是否开通累计金额送券活动 / 是否开通畅享金 / 是否有生效的会员日活动 /

    是否有生效的会员日领券活动 / 是否有生效的会员日专享菜活动



  可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions



  注：本数据集为配置快照，ds 固定单日；品牌隔离字段由后端自动注入。



Options:

  --filter TEXT                   维度筛选，格式

                                  维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）

  --date TEXT                     业务日期 yyyyMMdd 单日快照（默认昨天）

  --metrics TEXT                  需要查询的指标标准名，逗号分隔；默认全部12个

  --page INTEGER                  页码  [default: 1]

  --page-size INTEGER             每页条数  [default: 35000]

  --query-count / --no-query-count

                                  是否返回总行数  [default: query-count]

  --dimensions TEXT               需要分组的维度标准名，逗号分隔；默认全部维度

  --help                          Show this message and exit.
```

