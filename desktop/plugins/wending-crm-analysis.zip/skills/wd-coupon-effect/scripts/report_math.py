"""Decimal arithmetic for already normalized business values; no API or file writes.

This module does not establish whether metrics are additive or units are compatible.
Those decisions must be made from the skill's reporting contract before calling it.
"""
from decimal import Decimal, InvalidOperation, localcontext
import argparse
import json
from pathlib import Path


def numeric(value):
    if value is None or isinstance(value, bool):
        return None
    if not isinstance(value, (str, int, float, Decimal)):
        return None
    if isinstance(value, str):
        value = value.strip()
        if not value or ',' in value or '%' in value or '_' in value:
            return None
    try:
        result = Decimal(str(value))
    except (ValueError, InvalidOperation):
        return None
    return result if result.is_finite() else None


def as_text(value):
    return None if value is None else format(value, 'f')


def summarize(values):
    if not isinstance(values, list):
        raise ValueError('values must be an array of normalized numbers or missing values')
    converted = [numeric(value) for value in values]
    valid = [value for value in converted if value is not None]
    excluded = [index + 1 for index, value in enumerate(converted) if value is None]
    with localcontext() as ctx:
        ctx.prec = 50
        known_sum = sum(valid, Decimal(0)) if valid else None
        mean = known_sum / len(valid) if valid else None
    return {
        'row_count': len(values),
        'valid_count': len(valid),
        'excluded_row_numbers': excluded,
        'known_sum': as_text(known_sum),
        'complete_sum': as_text(known_sum) if valid and not excluded else None,
        'arithmetic_mean': as_text(mean),
    }


def safe_ratio(numerator, denominator):
    top, bottom = numeric(numerator), numeric(denominator)
    if top is None or bottom is None:
        return {'ratio': None, 'reason': 'missing_or_invalid_value'}
    if bottom <= 0:
        return {'ratio': None, 'reason': 'nonpositive_denominator'}
    with localcontext() as ctx:
        ctx.prec = 50
        return {'ratio': as_text(top / bottom), 'reason': None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path, help='UTF-8 JSON with operation=summary or ratio')
    args = parser.parse_args()
    try:
        payload = json.loads(args.input.read_text(encoding='utf-8-sig'), parse_float=Decimal)
        if not isinstance(payload, dict):
            raise ValueError('input must be an object')
        operation = payload.get('operation')
        if operation == 'summary':
            result = summarize(payload.get('values'))
        elif operation == 'ratio':
            result = safe_ratio(payload.get('numerator'), payload.get('denominator'))
        else:
            raise ValueError('operation must be summary or ratio')
    except (OSError, ValueError, InvalidOperation) as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
