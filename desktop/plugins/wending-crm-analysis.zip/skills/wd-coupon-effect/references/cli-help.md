# CLI参数参考

以下是2026-09-07本机命令帮助快照，只证明当时的参数和字段声明。首次使用或版本变化时应与当前 `--help` 对照；业务口径及权限需运行时核实。

## query-coupon-effect

```text
Usage: crm-brand-cli data-analysis query-coupon-effect [OPTIONS]



  查询 CRM 券效果（dataset 10002373，一行一 券模版×活动）



  注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。



  可选分组维度（group，可用 --dimensions 选子集）：券模版id / 券模板名称 / CRM活动id / 活动状态 / crm活动类型id



  可查询指标（7 个，默认全部）：

    CRM券面额 / 发券券门槛 / 当日发券量 / 当日核销券量 / 当日失效券量 / 当日券核销率 / 剩余可发券量



  可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）

    --start-date / --end-date（默认近 7 天） / --dimensions



  注：品牌隔离字段由后端自动注入。



Options:

  --filter TEXT                   维度筛选，格式

                                  维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）

  --start-date TEXT               开始日期 yyyyMMdd（默认 T-7）

  --end-date TEXT                 结束日期 yyyyMMdd（默认 T-1）

  --metrics TEXT                  需要查询的指标标准名，逗号分隔；默认全部7个

  --order-by-field TEXT           排序字段，不传则不排序

  --sort-order [asc|desc]         排序方向  [default: asc]

  --page INTEGER                  页码  [default: 1]

  --page-size INTEGER             每页条数  [default: 1000]

  --query-count / --no-query-count

                                  是否返回总行数  [default: query-count]

  --dimensions TEXT               需要分组的维度标准名，逗号分隔；默认全部维度

  --help                          Show this message and exit.
```

