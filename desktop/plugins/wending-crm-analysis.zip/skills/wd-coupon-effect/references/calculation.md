# 确定性数值辅助

`scripts/report_math.py`仅用Python标准库，不联网、不写文件、不调用CLI。先依据场景规范确认字段单位、可加性和计算范围，再在任务输出目录创建UTF-8 JSON输入：

```json
{"operation":"summary","values":["0","2","10",null]}
```

执行 `python <本Skill目录>/scripts/report_math.py <输入JSON路径>`。返回valid_count=3、row_count=4、known_sum=12、arithmetic_mean=4、complete_sum=null，并列出排除行号。缺失、布尔值、非数值、NaN及无穷值不进入均值；真实0和负数保留。完整合计仅在非空且每个值均有效时提供，不能把known_sum称为完整合计。

均值是各行有效值的算术均值，不是加权均值。活动ROI和商品ROI必须分别输入，不能将核销率直接拿来平均。`summary`同时返回和与均值只为方便复用，不代表这些结果都获准用于业务报告。

```json
{"operation":"ratio","numerator":"1","denominator":"4"}
```

返回ratio="0.25"，不会自动乘100；分母<=0、缺失或无效时返回null及原因。比率转百分数需要事先确认单位与展示规则。普通核销率的分子、分母窗口和定义也必须先确认。

数值结果用十进制字符串输出，以免JSON浮点改变精度。按接口精度和场景规定格式化，不能将运算的额外位数当作接口精度；输入优先用原始数值或十进制字符串。带百分号、千位逗号、单位或模糊规模的字符串不自动解析，应先核实来源；不得猜测“2十+单”的精确数值。
