# CLI参数参考

以下是2026-09-07本机命令帮助快照，只证明当时的参数和字段声明。首次使用或版本变化时应与当前 `--help` 对照；业务口径及权限需运行时核实。

## query-activity-product

```text
Usage: crm-brand-cli data-analysis query-activity-product [OPTIONS]



  查询 CRM 活动商品（dataset 10002383，一行一 活动×商品规格）



  注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。



  可选分组维度（group，可用 --dimensions 选子集）：

    CRM活动id / CRM活动名称 / CRM活动类型名称 / 活动状态 / 商品规格id / 商品名称 / 商品优惠类型



  可查询指标（8 个，默认全部）：

    净GMV / 活动商品订单数 / 活动商品购买份数 / 活动商品优惠金额 / 活动商品核销金额 /

    活动商品ROI / 商品原价 / 商品核销价格



  可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）

    --start-date / --end-date（默认近 7 天） / --dimensions



  注：品牌隔离字段（crm品牌id/crm品牌名称）禁止作为查询/分组条件，由后端自动注入。



Options:

  --filter TEXT                   维度筛选，格式

                                  维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）

  --start-date TEXT               开始日期 yyyyMMdd（默认 T-7）

  --end-date TEXT                 结束日期 yyyyMMdd（默认 T-1）

  --metrics TEXT                  需要查询的指标标准名，逗号分隔；默认全部8个

  --order-by-field TEXT           排序字段，不传则不排序

  --sort-order [asc|desc]         排序方向  [default: asc]

  --page INTEGER                  页码  [default: 1]

  --page-size INTEGER             每页条数  [default: 1000]

  --query-count / --no-query-count

                                  是否返回总行数  [default: query-count]

  --dimensions TEXT               需要分组的维度标准名，逗号分隔；默认全部维度

  --help                          Show this message and exit.
```

## query-activity-effect

```text
Usage: crm-brand-cli data-analysis query-activity-effect [OPTIONS]



  查询 CRM 营销活动效果（dataset 10002381，一行一活动，ds 范围内指标汇总）



  注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。



  可选聚合维度（group，可用 --dimensions 选子集）：

    CRM活动id / CRM活动名称 / 活动类型名称 / 活动状态 / CRM活动创建时间 / CRM活动结束时间



  可查询指标（16 个，默认全部，可用 --metrics 逗号分隔选子集）：

    净GMV / 店均活动订单净G / 总订单数 / 店均订单数 / 补贴金额 / 店均活动优惠金额 /

    当日发券量 / 店均发券量 / 当日核销券量 / 店均核销券量 / 当日券核销率 / 店均券核销率 /

    活动适用门店数 / 商户活动覆盖率 / CRM活动ROI / 店均ROI



  可用查询条件：

    --filter（任意可分组维度，格式 维度名=值1,值2；如 "活动状态=ENABLED"）

    --start-date / --end-date（ds 时间范围，默认近 7 天 [T-7, T-1]） / --dimensions

    未指定 活动状态/CRM活动id/CRM活动名称 筛选时，默认按有效状态 IN_ENABLED,STARTING,ENABLED 过滤



  注：品牌隔离字段（crm品牌id 等）由后端自动注入，无需传入。



Options:

  --filter TEXT                   维度筛选，格式

                                  维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）

  --start-date TEXT               效果统计开始日期 yyyyMMdd（默认 T-7）

  --end-date TEXT                 效果统计结束日期 yyyyMMdd（默认 T-1）

  --metrics TEXT                  需要查询的指标标准名，逗号分隔；默认全部16个

  --order-by-field TEXT           排序字段，不传则不排序

  --sort-order [asc|desc]         排序方向  [default: desc]

  --page INTEGER                  页码  [default: 1]

  --page-size INTEGER             每页条数  [default: 1000]

  --query-count / --no-query-count

                                  是否返回总行数  [default: query-count]

  --dimensions TEXT               需要分组的维度标准名，逗号分隔；默认全部维度

  --help                          Show this message and exit.
```

