---
name: wd-crm-marketing-effect
description: "通过问鼎CLI查询品牌起止日期内返回状态为进行中的CRM活动，按活动和商品分别展示净GMV、订单、购买份数、优惠及ROI，补查创建时间并交付对话和Excel。发券核销分析使用wd-coupon-effect。"
---

# 问鼎CRM营销效果

两张8列表、各自合计与ROI算术均值、核心诊断；对话＋Excel单Sheet“CRM营销效果”。

## 输入与范围

品牌名称、开始日期、结束日期；状态固定为接口返回的进行中，核对实际筛选代码。
沿用对话中已确认的参数；只补问会改变查询范围的缺项。用户指定格式和范围优先，不能把下面模板中的占位符或示例当成真实参数。

## 执行

1. 读取[场景规范](references/workflow.md)和[通用规则](references/common-rules.md)，保留字段、排序、统计粒度、合计及交付结构。
2. 按[运行与交付](references/execution.md)找到现有CLI、已登录运行目录并核对目标品牌；对照[CLI参数参考](references/cli-help.md)与当前命令帮助。
3. 按本场景获取数据：`query-activity-product`, `query-activity-effect`。活动与商品分开请求对应粒度；创建时间只按活动ID补元数据。两表订单合计不强制相等，ROI分别按各表有效行算术均值计算。
4. 依据已确认的口径处理数据；需要精确数值运算时使用[计算辅助](references/calculation.md)。未核实的定义执行场景中的降级规则，不补造数值或因果解释。
5. 从同一批结果生成约定交付，核对明细范围、分组、排序、合计、缺失与观察依据，再提供结果及文件链接。

## 调用示例

查询【品牌】【开始日期】至【结束日期】返回状态为进行中的CRM营销效果，输出对话和Excel。
