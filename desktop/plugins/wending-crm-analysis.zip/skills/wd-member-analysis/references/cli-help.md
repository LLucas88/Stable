# CLI参数参考

以下是2026-09-07本机命令帮助快照，只证明当时的参数和字段声明。首次使用或版本变化时应与当前 `--help` 对照；业务口径及权限需运行时核实。

## query-customer-data

```text
Usage: crm-brand-cli data-analysis query-customer-data [OPTIONS]



  查询品牌客户分析数据



  注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。



  参数说明：

    crowdType  : 人群类型，NEW_CUSTOMER(新客) | OLD_CUSTOMER(老客) | MEMBER(会员)

    dateType   : 时间类型，MONTH(月) | WEEK(周)

    endDate    : 结束日期，格式 yyyyMMdd



Options:

  --crowd-type [new_customer|old_customer|member]

                                  人群类型（NEW_CUSTOMER 新客、OLD_CUSTOMER 老客、MEMBER

                                  会员）

  --date-type TEXT                时间类型（MONTH 月、WEEK 周）

  --end-date TEXT                 结束日期，格式 yyyyMMdd

  --request TEXT                  请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）

  --help                          Show this message and exit.
```

