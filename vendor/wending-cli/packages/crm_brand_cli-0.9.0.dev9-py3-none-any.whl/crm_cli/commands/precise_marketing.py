#!/usr/bin/env python3
# ============================================================================
# 本文件基于 @CrmCli 注解自动生成
# Module: precise-marketing
# 对应 Java 接口: com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.CrowdGroupMtopServiceCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.CrowdTagMtopServiceCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.AiOperationTipsV2MtopServiceCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.AICrowdServiceCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.GotoneTemplateApiCliApi,
#               com.alsc.crm.bench.cli.precisemarketing.ShopDecorationMtopServiceCliApi
# ============================================================================

from typing import Optional

import click

from crm_base_cli.cli import output, handle_error, parse_optional_request_json
from crm_base_cli.api import CrmAPI


@click.group("precise-marketing")
def precise_marketing_cli():
    """精准营销模块（precise-marketing）。"""
    pass


# ============================================================================
# Schema 定义
# ============================================================================

ESTIMATE_CROWD_USER_NUM_REQUEST_SCHEMA = {
    "name": "EstimateCrowdUserNumCliReq",
    "description": "预估托管投放人群数量 CLI 请求",
    "fields": [
        {"name": "crowdGroupCode", "type": "String", "required": True, "description": "锦囊策略Code"},
        {"name": "shopIdList", "type": "List<String>", "required": True, "description": "门店ID列表"},
        {"name": "cityIdList", "type": "List<String>", "required": False, "description": "异地出行城市ID列表"},
        {"name": "newItemList", "type": "List<ItemInfo>", "required": False, "description": "新品列表，每项含 label(商品名称) + value(商品ID)"},
    ],
}

ESTIMATE_CROWD_USER_NUM_RESPONSE_SCHEMA = {
    "name": "EntrustEstimateCrowdUserNumMInfo",
    "description": "预估托管投放人群数量响应",
    "fields": [
        {"name": "crowdGroupUserNum", "type": "Integer", "required": True, "description": "人群数量"},
    ],
}

ESTIMATE_ORDER_REQUEST_SCHEMA = {
    "name": "EstimateOrderCliReq",
    "description": "预估订单量 CLI 请求",
    "fields": [
        {"name": "shopNum", "type": "Integer", "required": True, "description": "门店数量"},
        {"name": "avgDenomination", "type": "Double", "required": True, "description": "平均优惠面额，单位：元"},
        {"name": "crowdUserNum", "type": "Integer", "required": True, "description": "人群用户数"},
        {"name": "crowdGroupCode", "type": "String", "required": True, "description": "人群Code"},
        {"name": "effectTimeRange", "type": "String", "required": True, "description": "生效时间范围，毫秒时间戳JSON数组，如[1751368870084,1752368870084]"},
        {"name": "maxDenomination", "type": "String", "required": False, "description": "券上限，单位：元"},
        {"name": "minDenomination", "type": "String", "required": False, "description": "券下限，单位：元"},
        {"name": "timeSlot", "type": "String", "required": False, "description": "时间段范围，JSON字符串，如{\"period\":[\"1\",\"2\"],\"week\":[\"1\",\"2\"]}"},
        {"name": "minCharge", "type": "String", "required": False, "description": "券门槛，单位：元"},
    ],
}

ESTIMATE_ORDER_RESPONSE_SCHEMA = {
    "name": "EstimateOrderCliRes",
    "description": "预估订单量 CLI 响应（精简字段）",
    "fields": [
        {"name": "checkRate", "type": "String", "required": False, "description": "订单转化率"},
        {"name": "orderNum", "type": "Long", "required": False, "description": "预估订单量"},
        {"name": "recoBudget", "type": "String", "required": False, "description": "推荐短信营销预算"},
    ],
}

CREATE_ENTRUST_DELIVERY_PLAN_REQUEST_SCHEMA = {
    "name": "CreateEntrustDeliveryPlanCliReq",
    "description": "创建托管投放计划 CLI 请求",
    "fields": [
        {"name": "crowdGroupCode", "type": "String", "required": True, "description": "人群Code"},
        {"name": "shopIdList", "type": "List<String>", "required": True, "description": "门店ID列表，JSON数组，如[\"1\",\"2\",\"3\"]"},
        {"name": "startDate", "type": "String", "required": True, "description": "开始日期，格式yyyy-MM-dd"},
        {"name": "endDate", "type": "String", "required": True, "description": "结束日期，格式yyyy-MM-dd"},
        {"name": "avgDenomination", "type": "String", "required": True, "description": "券平均面额，单位：元"},
        {"name": "minDenomination", "type": "String", "required": True, "description": "券最小面额，单位：元"},
        {"name": "maxDenomination", "type": "String", "required": True, "description": "券最大面额，单位：元"},
        {"name": "minCharge", "type": "String", "required": True, "description": "最低券门槛，单位：元"},
        {"name": "timeSlot", "type": "TimeSlot", "required": True, "description": "时间段范围，嵌套对象，含 week(List<String>, 1-7 周一到周日) + period(List<String>, 1-5 早餐/午餐/下午茶/晚餐/夜宵) 两个数组字段"},
        {"name": "budget", "type": "String", "required": False, "description": "短信营销预算，单位:元, 有短信渠道时必填，不能小于5元"},
        {"name": "smsContent", "type": "String", "required": False, "description": "短信文案内容，有短信渠道时必填"},
        {"name": "cityIdList", "type": "List<String>", "required": False, "description": "异地出行城市ID列表"},
        {"name": "newItemList", "type": "List<ItemInfo>", "required": False, "description": "新品列表，每项含 label(商品名称) + value(商品ID)"},
        {"name": "crowdUserNum", "type": "Integer", "required": True, "description": "人群数量，预估接口返回的人群数量"},
        {"name": "recoMaxDenomination", "type": "String", "required": False, "description": "算法推荐券最大面额，单位：元"},
        {"name": "recoMinDenomination", "type": "String", "required": False, "description": "算法推荐券最小面额，单位：元"},
        {"name": "recoMinCharge", "type": "String", "required": False, "description": "算法推荐最低券门槛"},
        {"name": "checkRate", "type": "String", "required": False, "description": "算法推荐核销率"},
        {"name": "recoAvgDenomination", "type": "String", "required": False, "description": "推荐平均面额"},
    ],
}

CREATE_ENTRUST_DELIVERY_PLAN_RESPONSE_SCHEMA = {
    "name": "String",
    "description": "创建托管投放计划响应，返回计划ID",
    "fields": [],
}

ENTRUST_DELIVERY_DETAIL_REQUEST_SCHEMA = {
    "name": "EntrustDeliveryDetailCliReq",
    "description": "查询托管投放详情 CLI 请求",
    "fields": [
        {"name": "idStr", "type": "String", "required": True, "description": "投放计划ID"},
    ],
}

ENTRUST_DELIVERY_DETAIL_RESPONSE_SCHEMA = {
    "name": "EntrustDeliveryDetailMInfo",
    "description": "托管投放详情响应",
    "fields": [
        {"name": "name", "type": "String", "required": False, "description": "投放计划名称"},
        {"name": "crowdGroupCode", "type": "String", "required": False, "description": "诊断人群类型code"},
        {"name": "crowdGroupCodeName", "type": "String", "required": False, "description": "诊断人群类型名称"},
        {"name": "crowdGroupUserNum", "type": "Integer", "required": False, "description": "诊断人群人数"},
        {"name": "effectTimeRange", "type": "List<Long>", "required": False, "description": "投放计划生效时间范围"},
        {"name": "shopNum", "type": "Integer", "required": False, "description": "门店数量"},
        {"name": "shopIdList", "type": "List<String>", "required": False, "description": "门店详情"},
        {"name": "avgDenomination", "type": "String", "required": False, "description": "平均券面额"},
        {"name": "minDenomination", "type": "String", "required": False, "description": "最小面额"},
        {"name": "maxDenomination", "type": "String", "required": False, "description": "最大面额"},
        {"name": "recoDenomination", "type": "String", "required": False, "description": "推荐面额"},
        {"name": "minCharge", "type": "String", "required": False, "description": "最小门槛"},
        {"name": "voucherInventory", "type": "Integer", "required": False, "description": "券库存，-1表示无限库存"},
        {"name": "outOfInventory", "type": "Boolean", "required": False, "description": "是否库存不足"},
        {"name": "orderNum", "type": "Long", "required": False, "description": "预估订单"},
        {"name": "checkRate", "type": "String", "required": False, "description": "预估核销率"},
        {"name": "timeSlot", "type": "TimeSlot", "required": False, "description": "所有的时间段范围"},
        {"name": "budget", "type": "String", "required": False, "description": "短信营销预算"},
        {"name": "recoBudget", "type": "String", "required": False, "description": "推荐的短信营销预算"},
    ],
}

QUERY_SHOP_IDS_BY_CROWD_CODE_REQUEST_SCHEMA = {
    "name": "QueryShopIdsByCrowdCodeCliReq",
    "description": "按人群Code查门店ID CLI 请求",
    "fields": [
        {"name": "crowdGroupCode", "type": "String", "required": True, "description": "锦囊策略Code"},
        {"name": "startTime", "type": "String", "required": True, "description": "开始时间，格式yyyy-MM-dd"},
        {"name": "endTime", "type": "String", "required": True, "description": "结束时间，格式yyyy-MM-dd"},
    ],
}

QUERY_SHOP_IDS_BY_CROWD_CODE_RESPONSE_SCHEMA = {
    "name": "List<String>",
    "description": "门店ID列表",
    "fields": [],
}

QUERY_CITY_IDS_BY_CROWD_CODE_REQUEST_SCHEMA = {
    "name": "QueryShopIdsByCrowdCodeCliReq",
    "description": "按人群Code查城市ID CLI 请求（复用门店查询的请求结构）",
    "fields": [
        {"name": "crowdGroupCode", "type": "String", "required": True, "description": "锦囊策略Code"},
        {"name": "startTime", "type": "String", "required": True, "description": "开始时间，格式yyyy-MM-dd"},
        {"name": "endTime", "type": "String", "required": True, "description": "结束时间，格式yyyy-MM-dd"},
    ],
}

QUERY_CITY_IDS_BY_CROWD_CODE_RESPONSE_SCHEMA = {
    "name": "List<String>",
    "description": "城市ID列表",
    "fields": [],
}

ENTRUST_DELIVERY_PRE_BUILD_REQUEST_SCHEMA = {
    "name": "EntrustDeliveryPreBuildCliReq",
    "description": "托管投放计划预生成 CLI 请求",
    "fields": [
        {"name": "crowdGroupCode", "type": "String", "required": True, "description": "人群Code"},
    ],
}

ENTRUST_DELIVERY_PRE_BUILD_RESPONSE_SCHEMA = {
    "name": "EntrustDeliveryPreBuildCliRes",
    "description": "托管投放计划预生成 CLI 响应",
    "fields": [
        {"name": "crowdGroupCode", "type": "String", "required": False, "description": "诊断人群类型code"},
        {"name": "crowdGroupCodeName", "type": "String", "required": False, "description": "诊断人群类型名称"},
        {"name": "channelList", "type": "List<String>", "required": False, "description": "投放渠道（如 ELEME / MESSAGE）列表"},
        {"name": "recoTimeSlot", "type": "TimeSlot", "required": False, "description": "推荐投放时间段选择"},
        {"name": "recoAvgDenomination", "type": "String", "required": False, "description": "推荐平均券面额"},
        {"name": "recoMinDenomination", "type": "String", "required": False, "description": "推荐最小面额"},
        {"name": "recoMaxDenomination", "type": "String", "required": False, "description": "推荐最大面额"},
        {"name": "recoMinCharge", "type": "String", "required": False, "description": "推荐最小门槛"},
    ],
}

QUERY_CROW_GROUP_DETAIL_REQUEST_SCHEMA = {
    "name": "QueryCrowGroupDetailCliReq",
    "description": "查询人群包详情 CLI 请求",
    "fields": [
        {"name": "id", "type": "Long", "required": True, "description": "人群包ID"},
    ],
}

QUERY_CROW_GROUP_DETAIL_RESPONSE_SCHEMA = {
    "name": "CrowdGroupDetailRes",
    "description": "人群包详情响应",
    "fields": [
        {"name": "crowdGroupId", "type": "Long", "required": False, "description": "人群包ID"},
        {"name": "crowdGroupName", "type": "String", "required": False, "description": "人群名称"},
        {"name": "crowdQuantity", "type": "Integer", "required": False, "description": "人群人数"},
        {"name": "filterRuleViewModel", "type": "CrowdGroupFilterRuleViewModel", "required": False, "description": "人群规则"},
        {"name": "unitPriceEx", "type": "String", "required": False, "description": "预估短信投放单价(可选)"},
    ],
}

QUERY_ELE_SPU_INFO_REQUEST_SCHEMA = {
    "name": "QueryEleSpuInfoCliReq",
    "description": "模糊查询菜品列表 CLI 请求",
    "fields": [
        {"name": "searchKey", "type": "String", "required": True, "description": "搜索关键字"},
    ],
}

QUERY_ELE_SPU_INFO_RESPONSE_SCHEMA = {
    "name": "List<EleSpuInfo>",
    "description": "菜品信息列表",
    "fields": [],
}

CREATE_DELIVERY_PLAN_REQUEST_SCHEMA = {
    "name": "CreateDeliveryPlanCliReq",
    "description": "创建投放计划 CLI 请求",
    "fields": [
        {"name": "name", "type": "String", "required": True, "description": "投放计划名称"},
        {"name": "crowdGroupId", "type": "Long", "required": True, "description": "人群包ID"},
        {"name": "exeDateType", "type": "String", "required": True, "description": "投放计划类型, FIXED:固定时间, WEEK_CYCLE:按周周期"},
        {"name": "exeDate", "type": "String", "required": True, "description": "执行时间, FIXED时传yyyy/MM/dd HH:mm, WEEK_CYCLE时传Quartz cron表达式"},
        {"name": "startDate", "type": "String", "required": True, "description": "开始日期，格式yyyy-MM-dd, WEEK_CYCLE时必传"},
        {"name": "endDate", "type": "String", "required": True, "description": "结束日期，格式yyyy-MM-dd, WEEK_CYCLE时必传"},
        {"name": "channelList", "type": "List<ChannelInfo>", "required": False, "description": "触达渠道配置"},
        {"name": "voucherTemplateIdList", "type": "List<String>", "required": False, "description": "券模版Id列表"},
        {"name": "budget", "type": "String", "required": False, "description": "短信投放预算，单位:元, 有短信渠道时必填，不能小于5元"},
    ],
}

CREATE_DELIVERY_PLAN_RESPONSE_SCHEMA = {
    "name": "String",
    "description": "创建投放计划响应，返回计划ID",
    "fields": [],
}

QUERY_DELIVERY_PLAN_DETAIL_REQUEST_SCHEMA = {
    "name": "QueryDeliveryPlanDetailCliReq",
    "description": "查询投放计划详情 CLI 请求",
    "fields": [
        {"name": "idStr", "type": "String", "required": True, "description": "投放计划ID"},
    ],
}

QUERY_DELIVERY_PLAN_DETAIL_RESPONSE_SCHEMA = {
    "name": "DeliveryPlanMInfo",
    "description": "投放计划详情响应",
    "fields": [
        {"name": "idStr", "type": "String", "required": False, "description": "投放计划id String"},
        {"name": "name", "type": "String", "required": False, "description": "计划名称"},
        {"name": "status", "type": "String", "required": False, "description": "状态"},
        {"name": "exeDateType", "type": "String", "required": False, "description": "投放时间类型"},
        {"name": "exeDate", "type": "String", "required": False, "description": "投放时间"},
        {"name": "crowdGroupId", "type": "Long", "required": False, "description": "人群包id"},
        {"name": "channelList", "type": "List<ChannelInfo>", "required": False, "description": "投放渠道"},
        {"name": "budget", "type": "String", "required": False, "description": "预算"},
        {"name": "ruleList", "type": "List<VoucherRuleMInfo>", "required": False, "description": "券规则列表"},
    ],
}

DELIVER_TEST_REQUEST_SCHEMA = {
    "name": "DeliverTestCliReq",
    "description": "投前测试 CLI 请求",
    "fields": [
        {"name": "planIdStr", "type": "String", "required": True, "description": "投放计划ID"},
        {"name": "mobileList", "type": "List<String>", "required": True, "description": "手机号列表，JSON数组，如[\"17700001111\",\"13800002222\"]"},
        {"name": "channel", "type": "String", "required": True, "description": "渠道，ELEME:淘宝闪购APP曝光, MESSAGE: 短信曝光"},
        {"name": "abTestGroup", "type": "String", "required": False, "description": "AB实验组"},
    ],
}

DELIVER_TEST_RESPONSE_SCHEMA = {
    "name": "Void",
    "description": "投前测试响应",
    "fields": [],
}

START_DELIVERY_PLAN_REQUEST_SCHEMA = {
    "name": "StartDeliveryPlanCliReq",
    "description": "启动投放计划 CLI 请求",
    "fields": [
        {"name": "idStr", "type": "String", "required": True, "description": "投放计划ID"},
    ],
}

START_DELIVERY_PLAN_RESPONSE_SCHEMA = {
    "name": "Void",
    "description": "启动投放计划响应",
    "fields": [],
}

CLOSE_DELIVERY_PLAN_REQUEST_SCHEMA = {
    "name": "CloseDeliveryPlanCliReq",
    "description": "终止投放计划 CLI 请求",
    "fields": [
        {"name": "idStr", "type": "String", "required": True, "description": "投放计划ID"},
    ],
}

CLOSE_DELIVERY_PLAN_RESPONSE_SCHEMA = {
    "name": "Void",
    "description": "终止投放计划响应",
    "fields": [],
}

QUERY_CROWD_TAB_REQUEST_SCHEMA = {
    "name": "None",
    "description": "查询锦囊人群策略列表 CLI 请求（无参数）",
    "fields": [],
}

QUERY_CROWD_TAB_RESPONSE_SCHEMA = {
    "name": "List<CrowdStrategyCardCliRes>",
    "description": "锦囊人群策略列表响应",
    "fields": [
        {"name": "strategyCardType", "type": "String", "required": False, "description": "策略卡片类型"},
        {"name": "analysisCardType", "type": "String", "required": False, "description": "分析卡片类型"},
        {"name": "strategyCardTypeDesc", "type": "String", "required": False, "description": "策略卡片类型描述"},
        {"name": "strategyTarget", "type": "String", "required": False, "description": "策略目标"},
        {"name": "subTitle", "type": "String", "required": False, "description": "副标题"},
        {"name": "crowdStrategyList", "type": "List<CrowdTabCliRes>", "required": False, "description": "人群策略列表"},
    ],
}

ASYNC_GENERATE_CROWD_FILTER_RULE_REQUEST_SCHEMA = {
    "name": "AsyncGenerateCrowdFilterRuleCliReq",
    "description": "异步生成人群筛选规则 CLI 请求",
    "fields": [
        {"name": "input", "type": "String", "required": True, "description": "人群描述，自然语言描述目标人群，如：最近30天消费过的老客"},
    ],
}

ASYNC_GENERATE_CROWD_FILTER_RULE_RESPONSE_SCHEMA = {
    "name": "GenerateCrowdFilterRuleRes",
    "description": "异步生成人群筛选规则响应",
    "fields": [
        {"name": "filterRule", "type": "CrowdGroupFilterRuleModel", "required": False, "description": "AI生成结果"},
        {"name": "requestId", "type": "String", "required": False, "description": "记录ID"},
        {"name": "crowdGroupId", "type": "Long", "required": False, "description": "人群Id"},
    ],
}

FETCH_CROWD_FILTER_RULE_WITH_CREATE_REQUEST_SCHEMA = {
    "name": "FetchCrowdFilterRuleCliReq",
    "description": "轮询获取异步人群生成结果 CLI 请求",
    "fields": [
        {"name": "requestId", "type": "String", "required": True, "description": "请求ID，asyncGenerateCrowdFilterRule 返回的 requestId"},
        {"name": "crowdGroupName", "type": "String", "required": True, "description": "人群名称，用于新建人群包,不能超过20字符"},
    ],
}

FETCH_CROWD_FILTER_RULE_WITH_CREATE_RESPONSE_SCHEMA = {
    "name": "CrowdGroupDetailRes",
    "description": "轮询获取异步人群生成结果响应",
    "fields": [
        {"name": "crowdGroupId", "type": "Long", "required": False, "description": "人群包ID"},
        {"name": "crowdGroupName", "type": "String", "required": False, "description": "人群名称"},
        {"name": "crowdQuantity", "type": "Integer", "required": False, "description": "人群人数"},
        {"name": "filterRuleViewModel", "type": "CrowdGroupFilterRuleViewModel", "required": False, "description": "人群规则"},
        {"name": "unitPriceEx", "type": "String", "required": False, "description": "预估短信投放单价(可选)"},
    ],
}


SHOP_DECORATION_CONFIG_REQUEST_SCHEMA = {
    "name": "ShopDecorationConfigCliReq",
    "description": "配置品牌店装修人群包列表 CLI 请求",
    "fields": [
        {"name": "crowdGroupId", "type": "String", "required": True, "description": "要操作的人群包ID"},
        {"name": "operateType", "type": "String", "required": False, "description": "操作类型：ADD-新增，REMOVE-剔除；默认 ADD"},
    ],
}

SHOP_DECORATION_CONFIG_RESPONSE_SCHEMA = {
    "name": "Boolean",
    "description": "配置结果",
    "fields": [],
}

QUERY_CONFIG_CROWD_GROUP_IDS_REQUEST_SCHEMA = {
    "name": "None",
    "description": "查询已配置的品牌店装修人群包列表 CLI 请求（无参数）",
    "fields": [],
}

QUERY_CONFIG_CROWD_GROUP_IDS_RESPONSE_SCHEMA = {
    "name": "List<ShopDecorationCrowdGroupMInfo>",
    "description": "已配置的品牌店装修人群包列表",
    "fields": [
        {"name": "crowdGroupId", "type": "Long", "required": False, "description": "人群包id"},
        {"name": "crowdGroupName", "type": "String", "required": False, "description": "人群包名称"},
        {"name": "quantity", "type": "Integer", "required": False, "description": "人群数量"},
        {"name": "dataVersion", "type": "String", "required": False, "description": "数据时间"},
    ],
}


# ============================================================================
# estimate-entrust-crowd-user-num - 预估托管投放的人群数量
# ============================================================================

@precise_marketing_cli.command("estimate-entrust-crowd-user-num")
@click.option(
    "--crowd-group-code",
    type=str,
    required=False,
    help="锦囊策略Code",
)
@click.option(
    "--shop-id-list",
    type=str,
    required=False,
    help="门店ID列表（JSON数组，如 [\"1\",\"2\"]）",
)
@click.option(
    "--city-id-list",
    type=str,
    required=False,
    help="异地出行城市ID列表（JSON数组，如 [\"330100\",\"310100\"]），可选",
)
@click.option(
    "--new-item-list",
    type=str,
    required=False,
    help="新品列表（JSON数组），每项含 label(商品名称)+value(商品ID)，如 [{\"label\":\"番茄牛肉饭\",\"value\":\"spu001\"}]，可选",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def estimate_entrust_crowd_user_num_cmd(
    crowd_group_code: Optional[str],
    shop_id_list: Optional[str],
    city_id_list: Optional[str],
    new_item_list: Optional[str],
    request_json: Optional[str],
):
    """预估托管投放的人群数量"""
    import json
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_code is not None:
        request["crowdGroupCode"] = crowd_group_code
    if shop_id_list is not None:
        request["shopIdList"] = json.loads(shop_id_list)
    if city_id_list is not None:
        request["cityIdList"] = json.loads(city_id_list)
    if new_item_list is not None:
        request["newItemList"] = json.loads(new_item_list)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="estimateCrowdUserNum",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.EstimateCrowdUserNumCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# estimate-entrust-order - 预估订单量及核销率
# ============================================================================

@precise_marketing_cli.command("estimate-entrust-order")
@click.option(
    "--shop-num",
    type=int,
    required=False,
    help="门店数量",
)
@click.option(
    "--avg-denomination",
    type=float,
    required=False,
    help="平均优惠面额，单位：元",
)
@click.option(
    "--crowd-user-num",
    type=int,
    required=False,
    help="人群用户数",
)
@click.option(
    "--crowd-group-code",
    type=str,
    required=False,
    help="人群Code",
)
@click.option(
    "--effect-time-range",
    type=str,
    required=False,
    help="生效时间范围，毫秒时间戳JSON数组，如[1751368870084,1752368870084]",
)
@click.option(
    "--max-denomination",
    type=str,
    required=False,
    help="券上限，单位：元",
)
@click.option(
    "--min-denomination",
    type=str,
    required=False,
    help="券下限，单位：元",
)
@click.option(
    "--time-slot",
    type=str,
    required=False,
    help="时间段范围，JSON字符串，如{\"period\":[\"1\",\"2\"],\"week\":[\"1\",\"2\"]}",
)
@click.option(
    "--min-charge",
    type=str,
    required=False,
    help="券门槛，单位：元",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def estimate_entrust_order_cmd(
    shop_num: Optional[int],
    avg_denomination: Optional[float],
    crowd_user_num: Optional[int],
    crowd_group_code: Optional[str],
    effect_time_range: Optional[str],
    max_denomination: Optional[str],
    min_denomination: Optional[str],
    time_slot: Optional[str],
    min_charge: Optional[str],
    request_json: Optional[str],
):
    """预估订单量及核销率"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if shop_num is not None:
        request["shopNum"] = shop_num
    if avg_denomination is not None:
        request["avgDenomination"] = avg_denomination
    if crowd_user_num is not None:
        request["crowdUserNum"] = crowd_user_num
    if crowd_group_code is not None:
        request["crowdGroupCode"] = crowd_group_code
    if effect_time_range is not None:
        request["effectTimeRange"] = effect_time_range
    if max_denomination is not None:
        request["maxDenomination"] = max_denomination
    if min_denomination is not None:
        request["minDenomination"] = min_denomination
    if time_slot is not None:
        request["timeSlot"] = time_slot
    if min_charge is not None:
        request["minCharge"] = min_charge

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="estimateOrder",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.EstimateOrderCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# create-entrust-delivery-plan - 创建托管投放计划
# ============================================================================

@precise_marketing_cli.command("create-entrust-delivery-plan")
@click.option(
    "--crowd-group-code",
    type=str,
    required=False,
    help="人群Code",
)
@click.option(
    "--shop-id-list",
    type=str,
    required=False,
    help="门店ID列表，JSON数组，如[\"1\",\"2\",\"3\"]",
)
@click.option(
    "--start-date",
    type=str,
    required=False,
    help="开始日期，格式yyyy-MM-dd",
)
@click.option(
    "--end-date",
    type=str,
    required=False,
    help="结束日期，格式yyyy-MM-dd",
)
@click.option(
    "--avg-denomination",
    type=str,
    required=False,
    help="券平均面额，单位：元",
)
@click.option(
    "--min-denomination",
    type=str,
    required=False,
    help="券最小面额，单位：元",
)
@click.option(
    "--max-denomination",
    type=str,
    required=False,
    help="券最大面额，单位：元",
)
@click.option(
    "--min-charge",
    type=str,
    required=False,
    help="最低券门槛，单位：元",
)
@click.option(
    "--time-slot",
    type=str,
    required=False,
    help="时间段范围 TimeSlot JSON 对象，含 week + period 数组，如 {\"week\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\"],\"period\":[\"2\",\"4\"]}",
)
@click.option(
    "--budget",
    type=str,
    required=False,
    help="短信营销预算，单位:元, 有短信渠道时必填，不能小于5元",
)
@click.option(
    "--sms-content",
    type=str,
    required=False,
    help="短信文案内容，有短信渠道时必填",
)
@click.option(
    "--city-id-list",
    type=str,
    required=False,
    help="异地出行城市ID列表（JSON数组，如 [\"330100\",\"310100\"]）",
)
@click.option(
    "--new-item-list",
    type=str,
    required=False,
    help="新品列表（JSON数组），每项含 label(商品名称)+value(商品ID)，如 [{\"label\":\"番茄牛肉饭\",\"value\":\"spu001\"}]",
)
@click.option(
    "--crowd-user-num",
    type=int,
    required=False,
    help="人群数量，预估接口返回的人群数量",
)
@click.option(
    "--reco-max-denomination",
    type=str,
    required=False,
    help="算法推荐券最大面额，单位：元",
)
@click.option(
    "--reco-min-denomination",
    type=str,
    required=False,
    help="算法推荐券最小面额，单位：元",
)
@click.option(
    "--reco-min-charge",
    type=str,
    required=False,
    help="算法推荐最低券门槛",
)
@click.option(
    "--check-rate",
    type=str,
    required=False,
    help="算法推荐核销率",
)
@click.option(
    "--reco-avg-denomination",
    type=str,
    required=False,
    help="推荐平均面额",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_entrust_delivery_plan_cmd(
    crowd_group_code: Optional[str],
    shop_id_list: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    avg_denomination: Optional[str],
    min_denomination: Optional[str],
    max_denomination: Optional[str],
    min_charge: Optional[str],
    time_slot: Optional[str],
    budget: Optional[str],
    sms_content: Optional[str],
    city_id_list: Optional[str],
    new_item_list: Optional[str],
    crowd_user_num: Optional[int],
    reco_max_denomination: Optional[str],
    reco_min_denomination: Optional[str],
    reco_min_charge: Optional[str],
    check_rate: Optional[str],
    reco_avg_denomination: Optional[str],
    request_json: Optional[str],
):
    """创建托管投放计划"""
    import json
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_code is not None:
        request["crowdGroupCode"] = crowd_group_code
    if shop_id_list is not None:
        request["shopIdList"] = json.loads(shop_id_list)
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    if avg_denomination is not None:
        request["avgDenomination"] = avg_denomination
    if min_denomination is not None:
        request["minDenomination"] = min_denomination
    if max_denomination is not None:
        request["maxDenomination"] = max_denomination
    if min_charge is not None:
        request["minCharge"] = min_charge
    if time_slot is not None:
        request["timeSlot"] = json.loads(time_slot)
    if budget is not None:
        request["budget"] = budget
    if sms_content is not None:
        request["smsContent"] = sms_content
    if city_id_list is not None:
        request["cityIdList"] = json.loads(city_id_list)
    if new_item_list is not None:
        request["newItemList"] = json.loads(new_item_list)
    if crowd_user_num is not None:
        request["crowdUserNum"] = crowd_user_num
    if reco_max_denomination is not None:
        request["recoMaxDenomination"] = reco_max_denomination
    if reco_min_denomination is not None:
        request["recoMinDenomination"] = reco_min_denomination
    if reco_min_charge is not None:
        request["recoMinCharge"] = reco_min_charge
    if check_rate is not None:
        request["checkRate"] = check_rate
    if reco_avg_denomination is not None:
        request["recoAvgDenomination"] = reco_avg_denomination

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="createDeliveryPlan",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.CreateEntrustDeliveryPlanCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# entrust-delivery-detail - 查询托管投放计划的详情
# ============================================================================

@precise_marketing_cli.command("entrust-delivery-detail")
@click.option(
    "--id-str",
    type=str,
    required=False,
    help="投放计划ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def entrust_delivery_detail_cmd(
    id_str: Optional[str],
    request_json: Optional[str],
):
    """查询托管投放计划的详情"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if id_str is not None:
        request["idStr"] = id_str

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="entrustDeliveryDetail",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.EntrustDeliveryDetailCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-shop-ids-has-config-by-crowd-code - 根据人群Code查询已经配置的门店ID列表
# ============================================================================

@precise_marketing_cli.command("query-shop-ids-has-config-by-crowd-code")
@click.option(
    "--crowd-group-code",
    type=str,
    required=False,
    help="锦囊策略Code",
)
@click.option(
    "--start-time",
    type=str,
    required=False,
    help="开始时间，格式yyyy-MM-dd",
)
@click.option(
    "--end-time",
    type=str,
    required=False,
    help="结束时间，格式yyyy-MM-dd",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_shop_ids_has_config_by_crowd_code_cmd(
    crowd_group_code: Optional[str],
    start_time: Optional[str],
    end_time: Optional[str],
    request_json: Optional[str],
):
    """根据人群Code查询已经配置的门店ID列表"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_code is not None:
        request["crowdGroupCode"] = crowd_group_code
    if start_time is not None:
        request["startTime"] = start_time
    if end_time is not None:
        request["endTime"] = end_time

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="queryShopIdListHasConfigByCrowdGroupCode",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryShopIdsByCrowdCodeCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-city-ids-by-crowd-code - 根据人群Code查询已配置的城市ID列表
# ============================================================================

@precise_marketing_cli.command("query-city-ids-by-crowd-code")
@click.option(
    "--crowd-group-code",
    type=str,
    required=False,
    help="锦囊策略Code",
)
@click.option(
    "--start-time",
    type=str,
    required=False,
    help="开始时间，格式yyyy-MM-dd",
)
@click.option(
    "--end-time",
    type=str,
    required=False,
    help="结束时间，格式yyyy-MM-dd",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_city_ids_by_crowd_code_cmd(
    crowd_group_code: Optional[str],
    start_time: Optional[str],
    end_time: Optional[str],
    request_json: Optional[str],
):
    """根据人群Code查询已配置的城市ID列表"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_code is not None:
        request["crowdGroupCode"] = crowd_group_code
    if start_time is not None:
        request["startTime"] = start_time
    if end_time is not None:
        request["endTime"] = end_time

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="queryCityIdListHasConfigByCrowdGroupCode",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryShopIdsByCrowdCodeCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# entrust-delivery-pre-build - 托管投放计划预生成
# ============================================================================

@precise_marketing_cli.command("entrust-delivery-pre-build")
@click.option(
    "--crowd-group-code",
    type=str,
    required=False,
    help="人群Code",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def entrust_delivery_pre_build_cmd(
    crowd_group_code: Optional[str],
    request_json: Optional[str],
):
    """托管投放计划预生成，根据人群Code获取投放计划的推荐配置"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_code is not None:
        request["crowdGroupCode"] = crowd_group_code

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.EntrustDeliveryMtopServiceCliApi",
        method_name="entrustDeliveryPreBuild",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.EntrustDeliveryPreBuildCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-crow-group-detail - 根据人群包ID查询详细信息
# ============================================================================

@precise_marketing_cli.command("query-crow-group-detail")
@click.option(
    "--id",
    "crowd_id",
    type=int,
    required=False,
    help="人群包ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_crow_group_detail_cmd(
    crowd_id: Optional[int],
    request_json: Optional[str],
):
    """根据人群包ID查询详细信息"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_id is not None:
        request["id"] = crowd_id

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdGroupMtopServiceCliApi",
        method_name="queryCrowGroupDetail",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryCrowGroupDetailCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-ele-spu-info - 根据关键字模糊查询菜品列表
# ============================================================================

@precise_marketing_cli.command("query-ele-spu-info")
@click.option(
    "--search-key",
    type=str,
    required=False,
    help="搜索关键字",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_ele_spu_info_cmd(
    search_key: Optional[str],
    request_json: Optional[str],
):
    """根据关键字模糊查询菜品列表"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if search_key is not None:
        request["searchKey"] = search_key

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdTagMtopServiceCliApi",
        method_name="queryEleSpuInfo",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryEleSpuInfoCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# create-delivery-plan - 创建精准投放计划
# ============================================================================

@precise_marketing_cli.command("create-delivery-plan")
@click.option(
    "--name",
    type=str,
    required=False,
    help="投放计划名称",
)
@click.option(
    "--crowd-group-id",
    type=int,
    required=False,
    help="人群包ID",
)
@click.option(
    "--exe-date-type",
    type=click.Choice(["FIXED", "WEEK_CYCLE"], case_sensitive=False),
    required=False,
    help="投放计划类型, FIXED:固定时间, WEEK_CYCLE:按周周期",
)
@click.option(
    "--exe-date",
    type=str,
    required=False,
    help="执行时间, FIXED时传yyyy/MM/dd HH:mm, WEEK_CYCLE时传Quartz cron表达式",
)
@click.option(
    "--start-date",
    type=str,
    required=False,
    help="开始日期，格式yyyy-MM-dd, WEEK_CYCLE时必传",
)
@click.option(
    "--end-date",
    type=str,
    required=False,
    help="结束日期，格式yyyy-MM-dd, WEEK_CYCLE时必传",
)
@click.option(
    "--channel-list",
    type=str,
    required=False,
    help="触达渠道配置（JSON数组）",
)
@click.option(
    "--voucher-template-id-list",
    type=str,
    required=False,
    help="券模版Id列表（JSON数组）",
)
@click.option(
    "--budget",
    type=str,
    required=False,
    help="短信投放预算，单位:元, 有短信渠道时必填，不能小于5元",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_delivery_plan_cmd(
    name: Optional[str],
    crowd_group_id: Optional[int],
    exe_date_type: Optional[str],
    exe_date: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    channel_list: Optional[str],
    voucher_template_id_list: Optional[str],
    budget: Optional[str],
    request_json: Optional[str],
):
    """创建精准投放计划"""
    import json
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if name is not None:
        request["name"] = name
    if crowd_group_id is not None:
        request["crowdGroupId"] = crowd_group_id
    if exe_date_type is not None:
        request["exeDateType"] = exe_date_type
    if exe_date is not None:
        request["exeDate"] = exe_date
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    if channel_list is not None:
        request["channelList"] = json.loads(channel_list)
    if voucher_template_id_list is not None:
        request["voucherTemplateIdList"] = json.loads(voucher_template_id_list)
    if budget is not None:
        request["budget"] = budget

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi",
        method_name="createDeliveryPlan",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.CreateDeliveryPlanCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-delivery-plan-detail - 根据投放计划ID查询详情
# ============================================================================

@precise_marketing_cli.command("query-delivery-plan-detail")
@click.option(
    "--id-str",
    type=str,
    required=False,
    help="投放计划ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_delivery_plan_detail_cmd(
    id_str: Optional[str],
    request_json: Optional[str],
):
    """根据投放计划ID查询详情"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if id_str is not None:
        request["idStr"] = id_str

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi",
        method_name="queryDeliveryPlanDetail",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryDeliveryPlanDetailCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# deliver-test - 执行投放前的预览测试
# ============================================================================

@precise_marketing_cli.command("deliver-test")
@click.option(
    "--plan-id-str",
    type=str,
    required=False,
    help="投放计划ID",
)
@click.option(
    "--mobile-list",
    type=str,
    required=False,
    help="手机号列表，JSON数组，如 [\"17700001111\",\"13800002222\"]",
)
@click.option(
    "--channel",
    type=click.Choice(["ELEME", "MESSAGE"], case_sensitive=False),
    required=False,
    help="渠道，ELEME:淘宝闪购APP曝光, MESSAGE: 短信曝光",
)
@click.option(
    "--ab-test-group",
    type=str,
    required=False,
    help="AB实验组",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def deliver_test_cmd(
    plan_id_str: Optional[str],
    mobile_list: Optional[str],
    channel: Optional[str],
    ab_test_group: Optional[str],
    request_json: Optional[str],
):
    """执行投放前的预览测试"""
    import json
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if plan_id_str is not None:
        request["planIdStr"] = plan_id_str
    if mobile_list is not None:
        request["mobileList"] = json.loads(mobile_list)
    if channel is not None:
        request["channel"] = channel
    if ab_test_group is not None:
        request["abTestGroup"] = ab_test_group

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi",
        method_name="deliverTest",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.DeliverTestCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# start-delivery-plan - 启动品牌自建投放计划
# ============================================================================

@precise_marketing_cli.command("start-delivery-plan")
@click.option(
    "--id-str",
    type=str,
    required=False,
    help="投放计划ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def start_delivery_plan_cmd(
    id_str: Optional[str],
    request_json: Optional[str],
):
    """启动品牌自建投放计划"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if id_str is not None:
        request["idStr"] = id_str

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi",
        method_name="startDeliveryPlan",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.StartDeliveryPlanCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# close-delivery-plan - 终止正在运行或待执行的投放计划
# ============================================================================

@precise_marketing_cli.command("close-delivery-plan")
@click.option(
    "--id-str",
    type=str,
    required=False,
    help="投放计划ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def close_delivery_plan_cmd(
    id_str: Optional[str],
    request_json: Optional[str],
):
    """终止正在运行或待执行的投放计划"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if id_str is not None:
        request["idStr"] = id_str

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi",
        method_name="closeDeliveryPlan",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.CloseDeliveryPlanCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-crowd-tab - 查询锦囊人群策略列表
# ============================================================================

@precise_marketing_cli.command("query-crowd-tab")
@handle_error
def query_crowd_tab_cmd():
    """查询锦囊人群策略列表"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.AiOperationTipsV2MtopServiceCliApi",
        method_name="queryCrowdTab",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)


# ============================================================================
# async-generate-crowd-filter-rule - 异步生成人群筛选规则
# ============================================================================

@precise_marketing_cli.command("async-generate-crowd-filter-rule")
@click.option(
    "--input",
    "input_text",
    type=str,
    required=False,
    help="人群描述，自然语言描述目标人群，如：最近30天消费过的老客",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def async_generate_crowd_filter_rule_cmd(
    input_text: Optional[str],
    request_json: Optional[str],
):
    """异步生成人群筛选规则，返回requestId用于轮询结果"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if input_text is not None:
        request["input"] = input_text

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.AICrowdServiceCliApi",
        method_name="asyncGenerateCrowdFilterRule",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.AsyncGenerateCrowdFilterRuleCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# fetch-crowd-filter-rule-with-create - 轮询获取异步人群生成结果
# ============================================================================

@precise_marketing_cli.command("fetch-crowd-filter-rule-with-create")
@click.option(
    "--request-id",
    type=str,
    required=False,
    help="请求ID，asyncGenerateCrowdFilterRule 返回的 requestId",
)
@click.option(
    "--crowd-group-name",
    type=str,
    required=False,
    help="人群名称，用于新建人群包,不能超过20字符",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def fetch_crowd_filter_rule_with_create_cmd(
    request_id: Optional[str],
    crowd_group_name: Optional[str],
    request_json: Optional[str],
):
    """根据requestId轮询获取异步人群生成结果"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if request_id is not None:
        request["requestId"] = request_id
    if crowd_group_name is not None:
        request["crowdGroupName"] = crowd_group_name

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.AICrowdServiceCliApi",
        method_name="fetchCrowdFilterRuleWithCreate",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.FetchCrowdFilterRuleCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# Schema 定义 - get-template-detail
# ============================================================================

GET_TEMPLATE_DETAIL_REQUEST_SCHEMA = {
    "name": "GetTemplateDetailCliReq",
    "description": "查询短信模板详情请求",
    "fields": [
        {"name": "templateId", "type": "String", "required": True, "description": "短信模板ID"},
    ],
}

GET_TEMPLATE_DETAIL_RESPONSE_SCHEMA = {
    "name": "TemplateDetailCliRes",
    "description": "短信模板详情响应",
    "fields": [
        {"name": "templateId", "type": "String", "required": False, "description": "模板ID"},
        {"name": "templateName", "type": "String", "required": False, "description": "模板名称"},
        {"name": "templateContent", "type": "String", "required": False, "description": "模板内容"},
        {"name": "templatePhrases", "type": "List<String>", "required": False, "description": "模板短语列表"},
    ],
}


# ============================================================================
# get-template-detail - 根据模板ID查询短信模板详情
# ============================================================================

@precise_marketing_cli.command("get-template-detail")
@click.option(
    "--template-id",
    type=str,
    required=False,
    help="短信模板ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def get_template_detail_cmd(
    template_id: Optional[str],
    request_json: Optional[str],
):
    """根据模板ID查询短信模板详情"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if template_id is not None:
        request["templateId"] = template_id

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.GotoneTemplateApiCliApi",
        method_name="getTemplateDetail",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.GetTemplateDetailCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# shop-decoration-config - 配置品牌店装修人群包列表
# ============================================================================

@precise_marketing_cli.command("shop-decoration-config")
@click.option(
    "--crowd-group-id",
    type=str,
    required=False,
    help="要操作的人群包ID",
)
@click.option(
    "--operate-type",
    type=click.Choice(["ADD", "REMOVE"], case_sensitive=False),
    required=False,
    help="操作类型：ADD-新增，REMOVE-剔除；默认 ADD",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def shop_decoration_config_cmd(
    crowd_group_id: Optional[str],
    operate_type: Optional[str],
    request_json: Optional[str],
):
    """配置品牌店装修人群包列表（新增/剔除）"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_id is not None:
        request["crowdGroupId"] = crowd_group_id
    if operate_type is not None:
        request["operateType"] = operate_type

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.ShopDecorationMtopServiceCliApi",
        method_name="shopDecorationConfig",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.ShopDecorationConfigCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)


# ============================================================================
# query-config-crowd-group-ids - 查询已配置的品牌店装修人群包列表
# ============================================================================

@precise_marketing_cli.command("query-config-crowd-group-ids")
@handle_error
def query_config_crowd_group_ids_cmd():
    """查询已配置的品牌店装修人群包列表"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.ShopDecorationMtopServiceCliApi",
        method_name="queryConfigCrowdGroupIds",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)


# === createCrowGroup(1) BEGIN ===
@precise_marketing_cli.command("create-crow-group")
@click.option(
    "--name",
    type=str,
    required=True,
    help="人群包名称",
)
@click.option(
    "--describe-info",
    type=str,
    required=False,
    help="人群包描述",
)
@click.option(
    "--filter-rule-str",
    type=str,
    required=False,
    help="标签过滤规则JSON字符串",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_crow_group_cmd(
    name: Optional[str],
    describe_info: Optional[str],
    filter_rule_str: Optional[str],
    request_json: Optional[str],
):
    """创建人群包"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if name is not None:
        request["name"] = name
    if describe_info is not None:
        request["describeInfo"] = describe_info
    if filter_rule_str is not None:
        request["filterRuleStr"] = filter_rule_str

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdGroupMtopServiceCliApi",
        method_name="createCrowGroup",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.CrowdGroupCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === createCrowGroup(1) END ===


# === estimateCrowUserNumUnitPrice(1) BEGIN ===
@precise_marketing_cli.command("estimate-crow-user-num-unit-price")
@click.option(
    "--filter-rule-str",
    type=str,
    required=False,
    help="标签过滤规则JSON字符串",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def estimate_crow_user_num_unit_price_cmd(
    filter_rule_str: Optional[str],
    request_json: Optional[str],
):
    """预估人群包人数及单价"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if filter_rule_str is not None:
        request["filterRuleStr"] = filter_rule_str

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdGroupMtopServiceCliApi",
        method_name="estimateCrowUserNumUnitPrice",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.EstimateCrowUserCliRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === estimateCrowUserNumUnitPrice(1) END ===


# === creatWanxiangDelivery(1) BEGIN ===
@precise_marketing_cli.command("creat-wanxiang-delivery")
@click.option(
    "--crowd-group-id",
    type=int,
    required=True,
    help="人群包ID",
)
@click.option(
    "--end-date",
    type=str,
    required=False,
    help="结束时间，格式 yyyyMMdd",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def creat_wanxiang_delivery_cmd(
    crowd_group_id: Optional[int],
    end_date: Optional[str],
    request_json: Optional[str],
):
    """创建万象投放计划"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_group_id is not None:
        request["crowdGroupId"] = crowd_group_id
    if end_date is not None:
        request["endDate"] = end_date

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdDeliveryMtopServiceCliApi",
        method_name="creatWanxiangDelivery",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.WanxiangDeliveryCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === creatWanxiangDelivery(1) END ===


# === queryTagList(0) BEGIN ===
@precise_marketing_cli.command("query-tag-list")
@click.option("--request", "request_json", required=False, help="请求 JSON")
@handle_error
def query_tag_list_cmd(
    request_json: Optional[str],
):
    """查询标签元数据列表"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdTagMtopServiceCliApi",
        method_name="queryTagList",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryTagList(0) END ===


# === queryTagEnums(1) BEGIN ===
@precise_marketing_cli.command("query-tag-enums")
@click.option(
    "--tag-codes",
    type=str,
    required=False,
    help="标签编码列表，多个用逗号分隔，如 tag1,tag2,tag3",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_tag_enums_cmd(
    tag_codes: Optional[str],
    request_json: Optional[str],
):
    """根据标签Code批量查询标签枚举值"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段（CSV 风格拆分为列表）
    if tag_codes is not None:
        request["tagCodes"] = [s.strip() for s in tag_codes.split(",")]

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdTagMtopServiceCliApi",
        method_name="queryTagEnums",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryTagEnumsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryTagEnums(1) END ===


# === queryCityList(0) BEGIN ===
@precise_marketing_cli.command("query-city-list")
@click.option("--request", "request_json", required=False, help="请求 JSON")
@handle_error
def query_city_list_cmd(
    request_json: Optional[str],
):
    """查询城市列表"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.precisemarketing.CrowdTagMtopServiceCliApi",
        method_name="queryCityList",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryCityList(0) END ===
