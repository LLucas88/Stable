#!/usr/bin/env python3
# ============================================================================
# 本文件基于 @CrmCli 注解自动生成（增量维护，参考 cli-manifest.yaml）
# Module: shop-deco
# 涉及 Java 接口（多接口聚合）：
#   - com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.DecoTemplateMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.MemberCategoryMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi
#   - com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi
# ============================================================================

from typing import Optional

import click

from crm_base_cli.cli import output, handle_error, parse_optional_request_json
from crm_base_cli.api import CrmAPI


@click.group("shop-deco")
def shop_deco_cli():
    """店铺装修模块（shop-deco）。"""
    pass


# === findShopIdsWithPermissionByChain(1) BEGIN ===
@shop_deco_cli.command("find-shop-ids-with-permission-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def find_shop_ids_with_permission_by_chain_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询有品牌色编辑权限的店铺ID列表"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="findShopIdsWithPermissionByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.FindShopIdsWithPermissionByChainCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === findShopIdsWithPermissionByChain(1) END ===


# === getBrandColorByChain(1) BEGIN ===
@shop_deco_cli.command("get-brand-color-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def get_brand_color_by_chain_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询连锁配置的品牌色"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="getBrandColorByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandColorGetByChainCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === getBrandColorByChain(1) END ===


# === getBrandColorByShop(1) BEGIN ===
@shop_deco_cli.command("get-brand-color-by-shop")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=True, help="门店ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def get_brand_color_by_shop_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    request_json: Optional[str],
):
    """查询门店配置的品牌色"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="getBrandColorByShop",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandColorGetByShopCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === getBrandColorByShop(1) END ===


# === pageQueryBrandColorByChain(1) BEGIN ===
@shop_deco_cli.command("page-query-brand-color-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--page-number", type=int, required=False, help="页码")
@click.option("--page-size", type=int, required=False, help="每页数量")
@click.option("--shop-ids-to-search", type=str, required=False, help="搜索店铺ID列表（逗号分隔）")
@click.option("--include-brand-colors", type=str, required=False, help="包含的品牌色（逗号分隔）")
@click.option("--exclude-brand-colors", type=str, required=False, help="排除的品牌色（逗号分隔）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def page_query_brand_color_by_chain_cmd(
    mock_brand_id: Optional[int],
    page_number: Optional[int],
    page_size: Optional[int],
    shop_ids_to_search: Optional[str],
    include_brand_colors: Optional[str],
    exclude_brand_colors: Optional[str],
    request_json: Optional[str],
):
    """分页查询品牌色"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if page_number is not None:
        request["pageNumber"] = page_number
    if page_size is not None:
        request["pageSize"] = page_size
    if shop_ids_to_search is not None:
        request["shopIdsToSearch"] = [int(x.strip()) for x in shop_ids_to_search.split(",")]
    if include_brand_colors is not None:
        request["includeBrandColors"] = [x.strip() for x in include_brand_colors.split(",")]
    if exclude_brand_colors is not None:
        request["excludeBrandColors"] = [x.strip() for x in exclude_brand_colors.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="pageQueryBrandColorByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandColorPageQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === pageQueryBrandColorByChain(1) END ===


# === queryBrandColorByChain(1) BEGIN ===
@shop_deco_cli.command("query-brand-color-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-ids-to-search", type=str, required=False, help="搜索店铺ID列表（逗号分隔）")
@click.option("--include-brand-colors", type=str, required=False, help="包含的品牌色（逗号分隔）")
@click.option("--exclude-brand-colors", type=str, required=False, help="排除的品牌色（逗号分隔）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_brand_color_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_ids_to_search: Optional[str],
    include_brand_colors: Optional[str],
    exclude_brand_colors: Optional[str],
    request_json: Optional[str],
):
    """搜索品牌色"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_ids_to_search is not None:
        request["shopIdsToSearch"] = [int(x.strip()) for x in shop_ids_to_search.split(",")]
    if include_brand_colors is not None:
        request["includeBrandColors"] = [x.strip() for x in include_brand_colors.split(",")]
    if exclude_brand_colors is not None:
        request["excludeBrandColors"] = [x.strip() for x in exclude_brand_colors.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="queryBrandColorByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandColorQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryBrandColorByChain(1) END ===


# === createBrandColorByChain(1) BEGIN ===
@shop_deco_cli.command("create-brand-color-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id-list", type=str, required=True, help="店铺ID列表（逗号分隔）")
@click.option("--brand-color", type=str, required=True, help="品牌色(16进制)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_brand_color_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id_list: Optional[str],
    brand_color: Optional[str],
    request_json: Optional[str],
):
    """创建品牌色"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id_list is not None:
        request["shopIdList"] = [int(x.strip()) for x in shop_id_list.split(",")]
    if brand_color is not None:
        request["brandColor"] = brand_color
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="createBrandColorByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandColorCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === createBrandColorByChain(1) END ===


# === modifyBrandColorByChain(1) BEGIN ===
@shop_deco_cli.command("modify-brand-color-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id-list", type=str, required=True, help="店铺ID列表（逗号分隔）")
@click.option("--brand-color", type=str, required=True, help="品牌色(16进制)")
@click.option("--resource-id", type=int, required=True, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def modify_brand_color_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id_list: Optional[str],
    brand_color: Optional[str],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """修改品牌色"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id_list is not None:
        request["shopIdList"] = [int(x.strip()) for x in shop_id_list.split(",")]
    if brand_color is not None:
        request["brandColor"] = brand_color
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="modifyBrandColorByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandColorModifyCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === modifyBrandColorByChain(1) END ===


# === preCheckBeforeEditByChain(1) BEGIN ===
@shop_deco_cli.command("pre-check-before-edit-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id-list", type=str, required=True, help="店铺ID列表（逗号分隔）")
@click.option("--brand-color", type=str, required=True, help="品牌色(16进制)")
@click.option("--resource-id", type=int, required=True, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def pre_check_before_edit_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id_list: Optional[str],
    brand_color: Optional[str],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """编辑前预校验"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id_list is not None:
        request["shopIdList"] = [int(x.strip()) for x in shop_id_list.split(",")]
    if brand_color is not None:
        request["brandColor"] = brand_color
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandColorMtopServiceCliApi",
        method_name="preCheckBeforeEditByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PreCheckBeforeEditByChainCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === preCheckBeforeEditByChain(1) END ===


# === BrandWindowMtopServiceCliApi.queryPageByChain(1) BEGIN ===
@shop_deco_cli.command("brand-window-query-page-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--title", type=str, required=False, help="橱窗标题")
@click.option("--brand-window-type", type=str, required=False, help="橱窗类型: NO_BACKGROUND（无背景）、NORMAL_BACKGROUND（常规背景）、ALIEN（异形）")
@click.option("--offset", type=int, required=False, help="分页偏移量")
@click.option("--limit", type=int, required=False, help="每页条数")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已失效）")
@click.option("--channel", type=str, required=False, help="渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_query_page_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    title: Optional[str],
    brand_window_type: Optional[str],
    offset: Optional[int],
    limit: Optional[int],
    effective_status: Optional[str],
    channel: Optional[str],
    request_json: Optional[str],
):
    """连锁维度分页查询品牌橱窗列表"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if title is not None:
        request["title"] = title
    if brand_window_type is not None:
        request["brandWindowType"] = brand_window_type
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if channel is not None:
        request["channel"] = channel
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="queryPageByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowPageQueryByChainCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.queryPageByChain(1) END ===


# === BrandWindowMtopServiceCliApi.queryPageByShop(1) BEGIN ===
@shop_deco_cli.command("brand-window-query-page-by-shop")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--title", type=str, required=False, help="橱窗标题")
@click.option("--brand-window-type", type=str, required=False, help="橱窗类型: NO_BACKGROUND（无背景）、NORMAL_BACKGROUND（常规背景）、ALIEN（异形）")
@click.option("--offset", type=int, required=False, help="分页偏移量")
@click.option("--limit", type=int, required=False, help="每页条数")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已失效）")
@click.option("--channel", type=str, required=False, help="渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_query_page_by_shop_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    title: Optional[str],
    brand_window_type: Optional[str],
    offset: Optional[int],
    limit: Optional[int],
    effective_status: Optional[str],
    channel: Optional[str],
    request_json: Optional[str],
):
    """门店维度分页查询品牌橱窗列表"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if title is not None:
        request["title"] = title
    if brand_window_type is not None:
        request["brandWindowType"] = brand_window_type
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if channel is not None:
        request["channel"] = channel
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="queryPageByShop",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowPageQueryByShopCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.queryPageByShop(1) END ===


# === BrandWindowMtopServiceCliApi.queryByChain(1) BEGIN ===
@shop_deco_cli.command("brand-window-query-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="橱窗资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_query_by_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """连锁维度查询品牌橱窗详情"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="queryByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowDetailQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.queryByChain(1) END ===


# === BrandWindowMtopServiceCliApi.queryBindShopRealTime(1) BEGIN ===
@shop_deco_cli.command("brand-window-query-bind-shop-real-time")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="橱窗资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_query_bind_shop_real_time_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """实时查询品牌橱窗绑定门店信息"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="queryBindShopRealTime",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowBindShopQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.queryBindShopRealTime(1) END ===


# === BrandWindowMtopServiceCliApi.createForChain(1) BEGIN ===
@shop_deco_cli.command("brand-window-create-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource", "resource_str", type=str, required=False, help="橱窗资源配置(JSON)")
@click.option("--bind-shop-list", type=str, required=False, help="绑定门店列表(JSON)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_create_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_str: Optional[str],
    bind_shop_list: Optional[str],
    request_json: Optional[str],
):
    """连锁维度创建品牌橱窗"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_str is not None:
        request["resource"] = json.loads(resource_str)
    if bind_shop_list is not None:
        request["bindShopList"] = json.loads(bind_shop_list)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="createForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.createForChain(1) END ===


# === BrandWindowMtopServiceCliApi.editForChain(1) BEGIN ===
@shop_deco_cli.command("brand-window-edit-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="橱窗资源ID")
@click.option("--resource", "resource_str", type=str, required=False, help="橱窗资源配置(JSON)")
@click.option("--bind-shop-list", type=str, required=False, help="绑定门店列表(JSON)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_edit_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    resource_str: Optional[str],
    bind_shop_list: Optional[str],
    request_json: Optional[str],
):
    """连锁维度编辑品牌橱窗"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    if resource_str is not None:
        request["resource"] = json.loads(resource_str)
    if bind_shop_list is not None:
        request["bindShopList"] = json.loads(bind_shop_list)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="editForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowEditCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.editForChain(1) END ===


# === BrandWindowMtopServiceCliApi.delete(1) BEGIN ===
@shop_deco_cli.command("brand-window-delete")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="橱窗资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def brand_window_delete_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """删除品牌橱窗"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.BrandWindowMtopServiceCliApi",
        method_name="delete",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.BrandWindowDeleteCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === BrandWindowMtopServiceCliApi.delete(1) END ===


# === queryAllDecoTemplate(1) BEGIN ===
@shop_deco_cli.command("deco-template-query-all")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def deco_template_query_all_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询所有装修模版"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.DecoTemplateMtopServiceCliApi",
        method_name="queryAllDecoTemplate",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryAllDecoTemplateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryAllDecoTemplate(1) END ===


# === preCheckForSaveDecoTemplate(1) BEGIN ===
@shop_deco_cli.command("deco-template-pre-check-for-save")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-ids", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--deco-template", type=str, required=False, help="装修模版: EXTREME_SCREEN_EFFICIENCY_CHAIN_STYLE（极致坪效）、WAIMAI_COMMON_CHAIN_STYLE（行业通用）、EXCELLENT_CHAIN_STYLE（匠心品质）、CRM_CHAIN_STYLE（品牌专属连锁）、FAMILY_BANQUET_CHAIN_STYLE（家宴）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def deco_template_pre_check_for_save_cmd(
    mock_brand_id: Optional[int],
    shop_ids: Optional[str],
    deco_template: Optional[str],
    request_json: Optional[str],
):
    """保存装修模版前校验"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if deco_template is not None:
        request["decoTemplate"] = deco_template
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.DecoTemplateMtopServiceCliApi",
        method_name="preCheckForSaveDecoTemplate",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PreCheckForSaveDecoTemplateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === preCheckForSaveDecoTemplate(1) END ===


# === saveDecoTemplate(1) BEGIN ===
@shop_deco_cli.command("deco-template-save")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-ids", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--deco-template", type=str, required=False, help="装修模版: EXTREME_SCREEN_EFFICIENCY_CHAIN_STYLE（极致坪效）、WAIMAI_COMMON_CHAIN_STYLE（行业通用）、EXCELLENT_CHAIN_STYLE（匠心品质）、CRM_CHAIN_STYLE（品牌专属连锁）、FAMILY_BANQUET_CHAIN_STYLE（家宴）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def deco_template_save_cmd(
    mock_brand_id: Optional[int],
    shop_ids: Optional[str],
    deco_template: Optional[str],
    request_json: Optional[str],
):
    """保存装修模版"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if deco_template is not None:
        request["decoTemplate"] = deco_template
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.DecoTemplateMtopServiceCliApi",
        method_name="saveDecoTemplate",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.SaveDecoTemplateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === saveDecoTemplate(1) END ===


# === queryHeadBannerPageByChain(1) BEGIN ===
@shop_deco_cli.command("query-head-banner-page-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--offset", type=int, required=False, help="偏移量")
@click.option("--limit", type=int, required=False, help="每页数量")
@click.option("--head-banner-type", type=str, required=False, help="招牌类型: ALL（全部）、IMAGE（图片）、VIDEO（视频）")
@click.option("--bind-type", type=str, required=False, help="跳转方式")
@click.option("--channel", type=str, required=False, help="渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--start-date", type=str, required=False, help="起始日期")
@click.option("--end-date", type=str, required=False, help="结束日期")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已失效）")
@click.option("--single-user-group-id", type=str, required=False, help="人群标签ID")
@click.option("--related-shop-ids", type=str, required=False, help="关联店铺ID列表（逗号分隔）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_head_banner_page_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    offset: Optional[int],
    limit: Optional[int],
    head_banner_type: Optional[str],
    bind_type: Optional[str],
    channel: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    effective_status: Optional[str],
    single_user_group_id: Optional[str],
    related_shop_ids: Optional[str],
    request_json: Optional[str],
):
    """按连锁分页查询品牌连专享"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if head_banner_type is not None:
        request["headBannerType"] = head_banner_type
    if bind_type is not None:
        request["bindType"] = bind_type
    if channel is not None:
        request["channel"] = channel
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if single_user_group_id is not None:
        request["singleUserGroupId"] = single_user_group_id
    if related_shop_ids is not None:
        request["relatedShopIds"] = [int(x.strip()) for x in related_shop_ids.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="queryHeadBannerPageByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.HeadBannerPageQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryHeadBannerPageByChain(1) END ===


# === queryHeadBannerPageByShop(1) BEGIN ===
@shop_deco_cli.command("query-head-banner-page-by-shop")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--offset", type=int, required=False, help="偏移量")
@click.option("--limit", type=int, required=False, help="每页数量")
@click.option("--head-banner-type", type=str, required=False, help="招牌类型: ALL（全部）、IMAGE（图片）、VIDEO（视频）")
@click.option("--bind-type", type=str, required=False, help="跳转方式")
@click.option("--channel", type=str, required=False, help="渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--start-date", type=str, required=False, help="起始日期")
@click.option("--end-date", type=str, required=False, help="结束日期")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已失效）")
@click.option("--single-user-group-id", type=str, required=False, help="人群标签ID")
@click.option("--related-shop-ids", type=str, required=False, help="关联店铺ID列表（逗号分隔）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_head_banner_page_by_shop_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    offset: Optional[int],
    limit: Optional[int],
    head_banner_type: Optional[str],
    bind_type: Optional[str],
    channel: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    effective_status: Optional[str],
    single_user_group_id: Optional[str],
    related_shop_ids: Optional[str],
    request_json: Optional[str],
):
    """按门店分页查询品牌连专享"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if head_banner_type is not None:
        request["headBannerType"] = head_banner_type
    if bind_type is not None:
        request["bindType"] = bind_type
    if channel is not None:
        request["channel"] = channel
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if single_user_group_id is not None:
        request["singleUserGroupId"] = single_user_group_id
    if related_shop_ids is not None:
        request["relatedShopIds"] = [int(x.strip()) for x in related_shop_ids.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="queryHeadBannerPageByShop",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryHeadBannerPageByShopCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryHeadBannerPageByShop(1) END ===


# === queryHeadBannerByChain(1) BEGIN ===
@shop_deco_cli.command("query-head-banner-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--resource-id", type=int, required=True, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_head_banner_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """按连锁查询品牌连专享详情"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="queryHeadBannerByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.HeadBannerDetailQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryHeadBannerByChain(1) END ===


# === queryHeadBannerByShop(1) BEGIN ===
@shop_deco_cli.command("query-head-banner-by-shop")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--resource-id", type=int, required=True, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_head_banner_by_shop_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """按门店查询品牌连专享详情"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="queryHeadBannerByShop",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryHeadBannerByShopCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryHeadBannerByShop(1) END ===


# === createHeadBannerForChain(1) BEGIN ===
@shop_deco_cli.command("create-head-banner-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-detail", type=str, required=True, help="配置详情(JSON)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_head_banner_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_detail: Optional[str],
    request_json: Optional[str],
):
    """按连锁创建品牌连专享"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_detail is not None:
        request["resourceDetail"] = json.loads(resource_detail)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="createHeadBannerForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.HeadBannerCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === createHeadBannerForChain(1) END ===


# === editHeadBannerForChain(1) BEGIN ===
@shop_deco_cli.command("edit-head-banner-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-detail", type=str, required=True, help="配置详情(JSON)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def edit_head_banner_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_detail: Optional[str],
    request_json: Optional[str],
):
    """按连锁编辑品牌连专享"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_detail is not None:
        request["resourceDetail"] = json.loads(resource_detail)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="editHeadBannerForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.HeadBannerEditCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === editHeadBannerForChain(1) END ===


# === deleteHeadBanner(1) BEGIN ===
@shop_deco_cli.command("delete-head-banner")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=True, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def delete_head_banner_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """删除品牌连专享"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="deleteHeadBanner",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.HeadBannerDeleteCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === deleteHeadBanner(1) END ===


# === editPriority(1) BEGIN ===
@shop_deco_cli.command("edit-priority")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--priorities", type=str, required=True, help="优先级配置(JSON)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def edit_priority_cmd(
    mock_brand_id: Optional[int],
    priorities: Optional[str],
    request_json: Optional[str],
):
    """编辑品牌连专享优先级"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if priorities is not None:
        request["priorities"] = json.loads(priorities)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.HeadBannerMtopServiceCliApi",
        method_name="editPriority",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.HeadBannerEditPriorityCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === editPriority(1) END ===


# === saveMemberCategory(1) BEGIN ===
@shop_deco_cli.command("member-category-save")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--category-name", type=str, required=False, help="分类名称")
@click.option("--category-desc", type=str, required=False, help="分类描述")
@click.option("--sort-type", type=int, required=False, help="排序方式: 4（销量从高到低）、6（折扣力度从大到小）")
@click.option("--category-status", type=int, required=False, help="分类状态: 1（显示）、2（隐藏）")
@click.option("--sticky", is_flag=True, default=False, help="是否置顶")
@click.option("--shop-ids", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def member_category_save_cmd(
    mock_brand_id: Optional[int],
    category_name: Optional[str],
    category_desc: Optional[str],
    sort_type: Optional[int],
    category_status: Optional[int],
    sticky: bool,
    shop_ids: Optional[str],
    request_json: Optional[str],
):
    """保存会员特色分类"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if category_name is not None:
        request["categoryName"] = category_name
    if category_desc is not None:
        request["categoryDesc"] = category_desc
    if sort_type is not None:
        request["sortType"] = sort_type
    if category_status is not None:
        request["categoryStatus"] = category_status
    if sticky:
        request["sticky"] = True
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.MemberCategoryMtopServiceCliApi",
        method_name="saveMemberCategory",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.SaveMemberCategoryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === saveMemberCategory(1) END ===


# === getMemberCategoryByShop(1) BEGIN ===
@shop_deco_cli.command("member-category-get-by-shop")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def member_category_get_by_shop_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    request_json: Optional[str],
):
    """查询单店会员特色分类"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.MemberCategoryMtopServiceCliApi",
        method_name="getMemberCategoryByShop",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.GetMemberCategoryByShopCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === getMemberCategoryByShop(1) END ===


# === mgetMemberCategoryByShops(1) BEGIN ===
@shop_deco_cli.command("member-category-mget-by-shops")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-ids", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--keyword", type=str, required=False, help="搜索关键词")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def member_category_mget_by_shops_cmd(
    mock_brand_id: Optional[int],
    shop_ids: Optional[str],
    keyword: Optional[str],
    request_json: Optional[str],
):
    """批量查询多店会员特色分类"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if keyword is not None:
        request["keyword"] = keyword
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.MemberCategoryMtopServiceCliApi",
        method_name="mgetMemberCategoryByShops",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.MgetMemberCategoryByShopsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === mgetMemberCategoryByShops(1) END ===


# === ParticularMenuMtopServiceCliApi.queryPageByChain(1) BEGIN ===
@shop_deco_cli.command("query-page-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--offset", type=int, required=False, help="偏移量")
@click.option("--limit", type=int, required=False, help="每页数量")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已失效）")
@click.option("--single-user-group-id", type=str, required=False, help="人群标签ID")
@click.option("--channel", type=str, required=False, help="渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--start-date", type=str, required=False, help="起始日期")
@click.option("--end-date", type=str, required=False, help="结束日期")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_page_by_chain_cmd(
    mock_brand_id: Optional[int],
    offset: Optional[int],
    limit: Optional[int],
    effective_status: Optional[str],
    single_user_group_id: Optional[str],
    channel: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    request_json: Optional[str],
):
    """分页查询特型菜单（连锁）"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if single_user_group_id is not None:
        request["singleUserGroupId"] = single_user_group_id
    if channel is not None:
        request["channel"] = channel
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="queryPageByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryPageByChainCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === ParticularMenuMtopServiceCliApi.queryPageByChain(1) END ===


# === queryPageOfHistory(1) BEGIN ===
@shop_deco_cli.command("query-page-of-history")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--offset", type=int, required=False, help="偏移量")
@click.option("--limit", type=int, required=False, help="每页数量")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已失效）")
@click.option("--single-user-group-id", type=str, required=False, help="人群标签ID")
@click.option("--channel", type=str, required=False, help="渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--start-date", type=str, required=False, help="起始日期")
@click.option("--end-date", type=str, required=False, help="结束日期")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_page_of_history_cmd(
    mock_brand_id: Optional[int],
    offset: Optional[int],
    limit: Optional[int],
    effective_status: Optional[str],
    single_user_group_id: Optional[str],
    channel: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    request_json: Optional[str],
):
    """分页查询历史特型菜单"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if single_user_group_id is not None:
        request["singleUserGroupId"] = single_user_group_id
    if channel is not None:
        request["channel"] = channel
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="queryPageOfHistory",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryPageOfHistoryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryPageOfHistory(1) END ===


# === ParticularMenuMtopServiceCliApi.queryByChain(1) BEGIN ===
@shop_deco_cli.command("query-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_by_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """查询特型菜单详情"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="queryByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryParticularMenuDetailCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === ParticularMenuMtopServiceCliApi.queryByChain(1) END ===


# === ParticularMenuMtopServiceCliApi.queryEntryV2(1) BEGIN ===
@shop_deco_cli.command("query-entry-v2")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_entry_v2_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询特型菜单入口V2"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="queryEntryV2",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryEntryV2CliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === ParticularMenuMtopServiceCliApi.queryEntryV2(1) END ===


# === ParticularMenuMtopServiceCliApi.createForChain(1) BEGIN ===
@shop_deco_cli.command("create-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--title", type=str, required=False, help="标题")
@click.option("--desc", type=str, required=False, help="描述")
@click.option("--channel-list", type=str, required=False, help="渠道列表（逗号分隔）")
@click.option("--channel-limit", is_flag=True, default=False, help="是否限制渠道")
@click.option("--effect-week", type=str, required=False, help="生效星期")
@click.option("--date-unlimited", is_flag=True, default=False, help="日期不限")
@click.option("--all-day", is_flag=True, default=False, help="全天")
@click.option("--effect-time-list", type=str, required=False, help="生效时间段列表(JSON)")
@click.option("--user-groups", type=str, required=False, help="人群列表(JSON)")
@click.option("--enable-user-group", is_flag=True, default=False, help="是否启用人群")
@click.option("--item-list", type=str, required=False, help="商品列表(JSON)")
@click.option("--shop-ids", type=str, required=False, help="店铺ID列表（逗号分隔）")
@click.option("--crow-group-id-name-map", type=str, required=False, help="人群ID名称映射(JSON)")
@click.option("--start-date", type=str, required=False, help="生效开始日期（yyyy-MM-dd）")
@click.option("--end-date", type=str, required=False, help="生效结束日期（yyyy-MM-dd）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_for_chain_cmd(
    mock_brand_id: Optional[int],
    title: Optional[str],
    desc: Optional[str],
    channel_list: Optional[str],
    channel_limit: bool,
    effect_week: Optional[str],
    date_unlimited: bool,
    all_day: bool,
    effect_time_list: Optional[str],
    user_groups: Optional[str],
    enable_user_group: bool,
    item_list: Optional[str],
    shop_ids: Optional[str],
    crow_group_id_name_map: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    request_json: Optional[str],
):
    """创建特型菜单（连锁）"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if title is not None:
        request["title"] = title
    if desc is not None:
        request["desc"] = desc
    if channel_list is not None:
        request["channelList"] = [x.strip() for x in channel_list.split(",")]
    if channel_limit:
        request["channelLimit"] = True
    if effect_week is not None:
        request["effectWeek"] = effect_week
    request["dateUnlimited"] = date_unlimited
    request["allDay"] = all_day
    if effect_time_list is not None:
        request["effectTimeList"] = json.loads(effect_time_list)
    if user_groups is not None:
        request["userGroups"] = json.loads(user_groups)
    request["enableUserGroup"] = enable_user_group
    if item_list is not None:
        request["itemList"] = json.loads(item_list)
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if crow_group_id_name_map is not None:
        request["crowGroupIdNameMap"] = json.loads(crow_group_id_name_map)
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="createForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.CreateParticularMenuCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === ParticularMenuMtopServiceCliApi.createForChain(1) END ===


# === ParticularMenuMtopServiceCliApi.editForChain(1) BEGIN ===
@shop_deco_cli.command("edit-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="资源ID")
@click.option("--title", type=str, required=False, help="标题")
@click.option("--desc", type=str, required=False, help="描述")
@click.option("--channel-list", type=str, required=False, help="渠道列表（逗号分隔）")
@click.option("--channel-limit", is_flag=True, default=False, help="是否限制渠道")
@click.option("--effect-week", type=str, required=False, help="生效星期")
@click.option("--date-unlimited", is_flag=True, default=False, help="日期不限")
@click.option("--all-day", is_flag=True, default=False, help="全天")
@click.option("--effect-time-list", type=str, required=False, help="生效时间段列表(JSON)")
@click.option("--user-groups", type=str, required=False, help="人群列表(JSON)")
@click.option("--enable-user-group", is_flag=True, default=False, help="是否启用人群")
@click.option("--item-list", type=str, required=False, help="商品列表(JSON)")
@click.option("--shop-ids", type=str, required=False, help="店铺ID列表（逗号分隔）")
@click.option("--crow-group-id-name-map", type=str, required=False, help="人群ID名称映射(JSON)")
@click.option("--start-date", type=str, required=False, help="生效开始日期（yyyy-MM-dd）")
@click.option("--end-date", type=str, required=False, help="生效结束日期（yyyy-MM-dd）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def edit_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    title: Optional[str],
    desc: Optional[str],
    channel_list: Optional[str],
    channel_limit: bool,
    effect_week: Optional[str],
    date_unlimited: bool,
    all_day: bool,
    effect_time_list: Optional[str],
    user_groups: Optional[str],
    enable_user_group: bool,
    item_list: Optional[str],
    shop_ids: Optional[str],
    crow_group_id_name_map: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
    request_json: Optional[str],
):
    """编辑特型菜单（连锁）"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    if title is not None:
        request["title"] = title
    if desc is not None:
        request["desc"] = desc
    if channel_list is not None:
        request["channelList"] = [x.strip() for x in channel_list.split(",")]
    if channel_limit:
        request["channelLimit"] = True
    if effect_week is not None:
        request["effectWeek"] = effect_week
    request["dateUnlimited"] = date_unlimited
    request["allDay"] = all_day
    if effect_time_list is not None:
        request["effectTimeList"] = json.loads(effect_time_list)
    if user_groups is not None:
        request["userGroups"] = json.loads(user_groups)
    request["enableUserGroup"] = enable_user_group
    if item_list is not None:
        request["itemList"] = json.loads(item_list)
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if crow_group_id_name_map is not None:
        request["crowGroupIdNameMap"] = json.loads(crow_group_id_name_map)
    if start_date is not None:
        request["startDate"] = start_date
    if end_date is not None:
        request["endDate"] = end_date
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="editForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.EditParticularMenuCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === ParticularMenuMtopServiceCliApi.editForChain(1) END ===


# === ParticularMenuMtopServiceCliApi.delete(1) BEGIN ===
@shop_deco_cli.command("delete")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="资源ID")
@click.option("--remove-type", type=str, required=False, help="删除类型")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def delete_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    remove_type: Optional[str],
    request_json: Optional[str],
):
    """删除特型菜单"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    if remove_type is not None:
        request["removeType"] = remove_type
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="delete",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.DeleteParticularMenuCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === ParticularMenuMtopServiceCliApi.delete(1) END ===


# === isFirstScreenMenuUpgrade(1) BEGIN ===
@shop_deco_cli.command("is-first-screen-menu-upgrade")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def is_first_screen_menu_upgrade_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询首屏菜单灰度状态"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="isFirstScreenMenuUpgrade",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.FirstScreenMenuUpgradeCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === isFirstScreenMenuUpgrade(1) END ===


# === upgradeFirstScreenMenu(1) BEGIN ===
@shop_deco_cli.command("upgrade-first-screen-menu")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def upgrade_first_screen_menu_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """升级首屏菜单"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ParticularMenuMtopServiceCliApi",
        method_name="upgradeFirstScreenMenu",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.UpgradeFirstScreenMenuCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === upgradeFirstScreenMenu(1) END ===


# === PopupWindowMtopServiceCliApi.queryPageByChain(1) BEGIN ===
@shop_deco_cli.command("popup-window-query-page-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--popup-window-type", type=str, required=False, help="弹窗类型: ITEM（商品弹窗）、COUPON（领券弹窗）、URL（链接弹窗）")
@click.option("--offset", type=int, required=False, help="分页偏移量")
@click.option("--limit", type=int, required=False, help="每页条数")
@click.option("--effective-status", type=str, required=False, help="生效状态: WAITING（待生效）、USING（生效中）、INVALID（已过期）、DELETED（已删除）")
@click.option("--channel", type=str, required=False, help="投放渠道: ELEME（饿了么）、ALIPAY（支付宝）、TAOBAO（淘宝）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_query_page_by_chain_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    popup_window_type: Optional[str],
    offset: Optional[int],
    limit: Optional[int],
    effective_status: Optional[str],
    channel: Optional[str],
    request_json: Optional[str],
):
    """连锁店分页查询弹窗"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if popup_window_type is not None:
        request["popupWindowType"] = popup_window_type
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if effective_status is not None:
        request["effectiveStatus"] = effective_status
    if channel is not None:
        request["channel"] = channel
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="queryPageByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowPageQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PopupWindowMtopServiceCliApi.queryPageByChain(1) END ===


# === PopupWindowMtopServiceCliApi.queryByChain(1) BEGIN ===
@shop_deco_cli.command("popup-window-query-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="弹窗资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_query_by_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """连锁店查询弹窗详情"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="queryByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowDetailQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PopupWindowMtopServiceCliApi.queryByChain(1) END ===


# === PopupWindowMtopServiceCliApi.queryEntryV2(1) BEGIN ===
@shop_deco_cli.command("popup-window-query-entry-v2")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-biz-type", type=str, required=True, help="店铺业务类型: BRAND_SHOP（品牌门店）、PLATFORM_SHOP（平台门店）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_query_entry_v2_cmd(
    mock_brand_id: Optional[int],
    shop_biz_type: Optional[str],
    request_json: Optional[str],
):
    """弹窗入口开启状态查询"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_biz_type is not None:
        request["shopBizType"] = shop_biz_type
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="queryEntryV2",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowEntryQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PopupWindowMtopServiceCliApi.queryEntryV2(1) END ===


# === querySupport(1) BEGIN ===
@shop_deco_cli.command("popup-window-query-support")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_query_support_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询弹窗类型支持"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="querySupport",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowSupportQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === querySupport(1) END ===


# === queryActivitySupport(1) BEGIN ===
@shop_deco_cli.command("popup-window-query-activity-support")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--activity-id", type=str, required=False, help="活动ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_query_activity_support_cmd(
    mock_brand_id: Optional[int],
    activity_id: Optional[str],
    request_json: Optional[str],
):
    """查询领券活动关联店铺"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if activity_id is not None:
        request["activityId"] = activity_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="queryActivitySupport",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowActivitySupportQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryActivitySupport(1) END ===


# === PopupWindowMtopServiceCliApi.queryBindShopRealTime(1) BEGIN ===
@shop_deco_cli.command("popup-window-query-bind-shop-real-time")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="弹窗资源ID")
@click.option("--shop-id", type=int, required=False, help="门店ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_query_bind_shop_real_time_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    shop_id: Optional[int],
    request_json: Optional[str],
):
    """查询弹窗绑定店铺实时数据"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    if shop_id is not None:
        request["shopId"] = shop_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="queryBindShopRealTime",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowBindShopQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PopupWindowMtopServiceCliApi.queryBindShopRealTime(1) END ===


# === PopupWindowMtopServiceCliApi.createForChain(1) BEGIN ===
@shop_deco_cli.command("popup-window-create-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource", "resource_str", type=str, required=False, help="弹窗资源配置(JSON)")
@click.option("--bind-shop-list", type=str, required=False, help="绑定门店列表(JSON)")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_create_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_str: Optional[str],
    bind_shop_list: Optional[str],
    request_json: Optional[str],
):
    """连锁店创建弹窗"""
    import json
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_str is not None:
        request["resource"] = json.loads(resource_str)
    if bind_shop_list is not None:
        request["bindShopList"] = json.loads(bind_shop_list)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="createForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PopupWindowMtopServiceCliApi.createForChain(1) END ===


# === PopupWindowMtopServiceCliApi.delete(1) BEGIN ===
@shop_deco_cli.command("popup-window-delete")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="弹窗资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def popup_window_delete_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    request_json: Optional[str],
):
    """删除弹窗"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.PopupWindowMtopServiceCliApi",
        method_name="delete",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.PopupWindowDeleteCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PopupWindowMtopServiceCliApi.delete(1) END ===


# === findEffectiveStatusByChainId(1) BEGIN ===
@shop_deco_cli.command("find-effective-status-by-chain-id")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-ids", type=str, required=True, help="门店ID列表（逗号分隔）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def find_effective_status_by_chain_id_cmd(
    mock_brand_id: Optional[int],
    shop_ids: Optional[str],
    request_json: Optional[str],
):
    """查询生效状态"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="findEffectiveStatusByChainId",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.FindEffectiveStatusCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === findEffectiveStatusByChainId(1) END ===


# === queryDecoConfigByShopIdAndType(1) BEGIN ===
@shop_deco_cli.command("query-deco-config-by-shop-id-and-type")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id", type=int, required=True, help="门店ID")
@click.option("--shop-biz-type", type=str, required=False, help="店铺业务类型")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_deco_config_by_shop_id_and_type_cmd(
    mock_brand_id: Optional[int],
    shop_id: Optional[int],
    shop_biz_type: Optional[str],
    request_json: Optional[str],
):
    """查询装修配置"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id is not None:
        request["shopId"] = shop_id
    if shop_biz_type is not None:
        request["shopBizType"] = shop_biz_type
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="queryDecoConfigByShopIdAndType",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryDecoConfigCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryDecoConfigByShopIdAndType(1) END ===


# === uploadImage(1) BEGIN ===
@shop_deco_cli.command("upload-image")
@click.option("--image-base64", type=str, required=True, help="图片Base64")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def upload_image_cmd(
    image_base64: Optional[str],
    request_json: Optional[str],
):
    """上传图片"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if image_base64 is not None:
        request["imageBase64"] = image_base64
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="uploadImage",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.UploadImageCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === uploadImage(1) END ===


# === queryCrowGroupConfig(1) BEGIN ===
@shop_deco_cli.command("query-crow-group-config")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-biz-type", type=str, required=False, help="店铺业务类型")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_crow_group_config_cmd(
    mock_brand_id: Optional[int],
    shop_biz_type: Optional[str],
    request_json: Optional[str],
):
    """查询人群配置"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_biz_type is not None:
        request["shopBizType"] = shop_biz_type
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="queryCrowGroupConfig",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.QueryCrowGroupConfigCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryCrowGroupConfig(1) END ===


# === searchFoods(1) BEGIN ===
@shop_deco_cli.command("search-foods")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--food-name", type=str, required=False, help="商品名称")
@click.option("--shop-ids", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--item-name-term-query", is_flag=True, default=False, help="是否使用term查询")
@click.option("--tag", type=str, required=False, help="商品标签")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def search_foods_cmd(
    mock_brand_id: Optional[int],
    food_name: Optional[str],
    shop_ids: Optional[str],
    item_name_term_query: bool,
    tag: Optional[str],
    request_json: Optional[str],
):
    """搜索商品"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if food_name is not None:
        request["foodName"] = food_name
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if item_name_term_query:
        request["itemNameTermQuery"] = True
    if tag is not None:
        request["tag"] = tag
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="searchFoods",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.SearchFoodsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === searchFoods(1) END ===


# === getItemHasTags(1) BEGIN ===
@shop_deco_cli.command("get-item-has-tags")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-id-list", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--tag", type=str, required=False, help="商品标签")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def get_item_has_tags_cmd(
    mock_brand_id: Optional[int],
    shop_id_list: Optional[str],
    tag: Optional[str],
    request_json: Optional[str],
):
    """查询商品是否有标签"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_id_list is not None:
        request["shopIdList"] = [int(x.strip()) for x in shop_id_list.split(",")]
    if tag is not None:
        request["tag"] = tag
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="getItemHasTags",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.GetItemHasTagsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === getItemHasTags(1) END ===


# === findUserGroups(1) BEGIN ===
@shop_deco_cli.command("find-user-groups")
@click.option("--request", "request_json", required=False, help="请求 JSON（可选，调试用）")
@handle_error
def find_user_groups_cmd(
    request_json: Optional[str],
):
    """查询人群列表（chainId 从登录态自动获取，无需传参）"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="findUserGroups",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.FindUserGroupsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === findUserGroups(1) END ===


# === findDecoUserGroup(1) BEGIN ===
@shop_deco_cli.command("find-deco-user-group")
@click.option("--request", "request_json", required=False, help="请求 JSON（可选，调试用）")
@handle_error
def find_deco_user_group_cmd(
    request_json: Optional[str],
):
    """查询装修人群列表（chainId 从登录态自动获取，无需传参）"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="findDecoUserGroup",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.FindDecoUserGroupCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === findDecoUserGroup(1) END ===


# === findDecoUserGroupForFilter(1) BEGIN ===
@shop_deco_cli.command("find-deco-user-group-for-filter")
@click.option("--request", "request_json", required=False, help="请求 JSON（可选，调试用）")
@handle_error
def find_deco_user_group_for_filter_cmd(
    request_json: Optional[str],
):
    """查询装修人群过滤信息（chainId 从登录态自动获取，无需传参）"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="findDecoUserGroupForFilter",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.FindDecoUserGroupForFilterCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === findDecoUserGroupForFilter(1) END ===


# === searchItemsByShopIds(1) BEGIN ===
@shop_deco_cli.command("search-items-by-shop-ids")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--shop-ids", type=str, required=False, help="门店ID列表（逗号分隔）")
@click.option("--keyword", type=str, required=False, help="搜索关键词")
@click.option("--offset", type=int, required=False, help="分页偏移量")
@click.option("--limit", type=int, required=False, help="每页条数")
@click.option("--theme", type=str, required=False, help="主题")
@click.option("--contain-invalid-sku", is_flag=True, default=False, help="是否包含无效SKU")
@click.option("--item-name-term-query", is_flag=True, default=False, help="是否商品名精确匹配")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def search_items_by_shop_ids_cmd(
    mock_brand_id: Optional[int],
    shop_ids: Optional[str],
    keyword: Optional[str],
    offset: Optional[int],
    limit: Optional[int],
    theme: Optional[str],
    contain_invalid_sku: bool,
    item_name_term_query: bool,
    request_json: Optional[str],
):
    """按店铺搜索商品"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if shop_ids is not None:
        request["shopIds"] = [int(x.strip()) for x in shop_ids.split(",")]
    if keyword is not None:
        request["keyword"] = keyword
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    if theme is not None:
        request["theme"] = theme
    request["containInvalidSku"] = contain_invalid_sku
    request["itemNameTermQuery"] = item_name_term_query
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.ShopDecoCommonMtopServiceCliApi",
        method_name="searchItemsByShopIds",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.SearchItemsByShopIdsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === searchItemsByShopIds(1) END ===


# === queryStoreLogoPageByChain(1) BEGIN ===
@shop_deco_cli.command("query-store-logo-page-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--title", type=str, required=False, help="标题（模糊搜索）")
@click.option("--offset", type=int, required=False, help="偏移量")
@click.option("--limit", type=int, required=False, help="每页数量")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_store_logo_page_by_chain_cmd(
    mock_brand_id: Optional[int],
    title: Optional[str],
    offset: Optional[int],
    limit: Optional[int],
    request_json: Optional[str],
):
    """按品牌分页查询门店头像"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if title is not None:
        request["title"] = title
    if offset is not None:
        request["offset"] = offset
    if limit is not None:
        request["limit"] = limit
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi",
        method_name="queryStoreLogoPageByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.StoreLogoPageQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryStoreLogoPageByChain(1) END ===


# === queryStoreLogoByChain(1) BEGIN ===
@shop_deco_cli.command("query-store-logo-by-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=True, help="资源ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_store_logo_by_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: int,
    request_json: Optional[str],
):
    """按品牌查询门店头像详情"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    request["resourceId"] = resource_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi",
        method_name="queryStoreLogoByChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.StoreLogoDetailQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryStoreLogoByChain(1) END ===


# === queryStoreLogoEntry(1) BEGIN ===
@shop_deco_cli.command("query-store-logo-entry")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_store_logo_entry_cmd(
    mock_brand_id: Optional[int],
    request_json: Optional[str],
):
    """查询门店头像入口开启状态"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi",
        method_name="queryStoreLogoEntry",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.StoreLogoEntryQueryCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryStoreLogoEntry(1) END ===


# === createStoreLogoForChain(1) BEGIN ===
@shop_deco_cli.command("create-store-logo-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-detail", type=str, required=True, help="配置详情JSON（StoreActivityLogoDetailMInfo 的 JSON 字符串）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def create_store_logo_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_detail: str,
    request_json: Optional[str],
):
    """为品牌创建门店头像"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    request["resourceDetail"] = resource_detail
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi",
        method_name="createStoreLogoForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.StoreLogoCreateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === createStoreLogoForChain(1) END ===


# === updateStoreLogoForChain(1) BEGIN ===
@shop_deco_cli.command("update-store-logo-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-detail", type=str, required=True, help="配置详情JSON（StoreActivityLogoDetailMInfo 的 JSON 字符串）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def update_store_logo_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_detail: str,
    request_json: Optional[str],
):
    """为品牌更新门店头像"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    request["resourceDetail"] = resource_detail
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi",
        method_name="updateStoreLogoForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.StoreLogoUpdateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === updateStoreLogoForChain(1) END ===


# === removeStoreLogoForChain(1) BEGIN ===
@shop_deco_cli.command("remove-store-logo-for-chain")
@click.option("--mock-brand-id", type=int, required=False, help="品牌ID")
@click.option("--resource-id", type=int, required=False, help="资源ID（单个删除时传，与资源ID列表二选一）")
@click.option("--resource-id-list", type=str, required=False, help="资源ID列表（逗号分隔，批量删除时传，与资源ID二选一）")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def remove_store_logo_for_chain_cmd(
    mock_brand_id: Optional[int],
    resource_id: Optional[int],
    resource_id_list: Optional[str],
    request_json: Optional[str],
):
    """为品牌删除门店头像"""
    api = CrmAPI()
    request = parse_optional_request_json(request_json)
    if mock_brand_id is not None:
        request["mockBrandId"] = mock_brand_id
    if resource_id is not None:
        request["resourceId"] = resource_id
    if resource_id_list is not None:
        request["resourceIdList"] = [int(x.strip()) for x in resource_id_list.split(",")]
    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.shopdeco.StoreLogoMtopServiceCliApi",
        method_name="removeStoreLogoForChain",
        method_signature=["com.alsc.crm.bench.cli.shopdeco.request.StoreLogoRemoveCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === removeStoreLogoForChain(1) END ===
