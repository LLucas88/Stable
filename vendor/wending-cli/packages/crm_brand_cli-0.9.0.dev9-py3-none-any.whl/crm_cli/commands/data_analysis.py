#!/usr/bin/env python3
# ============================================================================
# 本文件基于 @CrmCli 注解自动生成（增量维护，参考 cli-manifest.yaml）
# Module: data-analysis
# 涉及 Java 接口（多接口聚合）：
#   - com.alsc.crm.bench.mtop.gongyu.trust.TrustAnalysisMtopService
#   - com.alsc.crm.bench.cli.dataanalysis.KdtDataQueryForClawCliApi
# ============================================================================

import json
import time
from datetime import datetime, timedelta
from typing import Optional

import click

from crm_base_cli.cli import output, handle_error, parse_optional_request_json
from crm_base_cli.api import CrmAPI


DATA_QUERY_INTERFACE = "com.alsc.crm.bench.cli.dataanalysis.KdtDataQueryForClawCliApi"
QUERY_DATA_REQUEST_TYPE = "com.alsc.crm.bench.cli.dataanalysis.request.QueryDataCliReq"
QUERY_ASYNC_DATA_RESULT_REQUEST_TYPE = (
    "com.alsc.crm.bench.cli.dataanalysis.request.QueryAsyncDataResultCliReq"
)
ASYNC_QUERY_POLL_INTERVAL_SECONDS = 2
ASYNC_QUERY_MAX_POLL_TIMES = 30
ASYNC_QUERY_BUSY_CODE = "FAIL_BIZ_03"  # 后端限流：“人气大爆发，一会接待您”

_ASYNC_BUSY = object()


def _unwrap_base_response(resp, allow_busy=False):
    """CLI 经泛化网关返回的是 BaseResponse 的 JSON 字符串，解析并返回其中的 result。

    success=false 时报错；限流(FAIL_BIZ_03)在 allow_busy 时返回哨兵交由上层重试。
    """
    if isinstance(resp, str):
        try:
            resp = json.loads(resp)
        except (ValueError, TypeError):
            return resp
    if isinstance(resp, dict) and "status" not in resp and ("msgCode" in resp or "success" in resp):
        if not resp.get("success", True):
            code = resp.get("msgCode") or "UNKNOWN"
            msg = resp.get("msgInfo") or "未知错误"
            if allow_busy and code == ASYNC_QUERY_BUSY_CODE:
                return _ASYNC_BUSY
            raise RuntimeError("接口调用失败 [%s]: %s" % (code, msg))
        return resp.get("result")
    return resp


def _query_data_async(api, request, async_query_method="asyncQueryData"):
    # 1) 提交异步查询任务，遇后端限流(FAIL_BIZ_03)自动重试
    credential_id = None
    for _ in range(ASYNC_QUERY_MAX_POLL_TIMES):
        submitted = _unwrap_base_response(
            api._hsf_request(
                interface_name=DATA_QUERY_INTERFACE,
                method_name=async_query_method,
                method_signature=[QUERY_DATA_REQUEST_TYPE],
                args=[request],
                require_auth=True,
            ),
            allow_busy=True,
        )
        if submitted is _ASYNC_BUSY:
            time.sleep(ASYNC_QUERY_POLL_INTERVAL_SECONDS)
            continue
        credential_id = submitted
        break
    if not credential_id:
        raise RuntimeError("提交异步查询任务失败：后端持续限流(FAIL_BIZ_03)，请稍后重试")

    # 2) 轮询查询结果
    for _ in range(ASYNC_QUERY_MAX_POLL_TIMES):
        time.sleep(ASYNC_QUERY_POLL_INTERVAL_SECONDS)
        async_result = _unwrap_base_response(
            api._hsf_request(
                interface_name=DATA_QUERY_INTERFACE,
                method_name="queryAsyncDataResult",
                method_signature=[QUERY_ASYNC_DATA_RESULT_REQUEST_TYPE],
                args=[{"credentialId": credential_id}],
                require_auth=True,
            ),
            allow_busy=True,
        )
        if async_result is _ASYNC_BUSY:
            continue
        status = async_result.get("status") if isinstance(async_result, dict) else None
        if status == "SUCCESS":
            return async_result.get("data")
        if status == "FAILED":
            error_code = async_result.get("errorCode")
            error_message = async_result.get("errorMessage") or "未知错误"
            if error_code:
                raise RuntimeError(f"查询数据失败 [{error_code}]: {error_message}")
            raise RuntimeError(f"查询数据失败: {error_message}")
        if status != "QUERYING":
            raise RuntimeError(f"异步查询状态异常: {async_result}")

    raise RuntimeError("查询数据超时")


@click.group("data-analysis")
def data_analysis_cli():
    """数据分析模块（data-analysis）。"""
    pass


# === queryCustomerData(1) BEGIN ===
@data_analysis_cli.command("query-customer-data")
@click.option(
    "--crowd-type",
    type=click.Choice(["NEW_CUSTOMER", "OLD_CUSTOMER", "MEMBER"], case_sensitive=False),
    required=False,
    help="人群类型（NEW_CUSTOMER 新客、OLD_CUSTOMER 老客、MEMBER 会员）",
)
@click.option(
    "--date-type",
    type=str,
    required=False,
    help="时间类型（MONTH 月、WEEK 周）",
)
@click.option(
    "--end-date",
    type=str,
    required=False,
    help="结束日期，格式 yyyyMMdd",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_customer_data_cmd(
    crowd_type: Optional[str],
    date_type: Optional[str],
    end_date: Optional[str],
    request_json: Optional[str],
):
    """查询品牌客户分析数据

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    参数说明：
      crowdType  : 人群类型，NEW_CUSTOMER(新客) | OLD_CUSTOMER(老客) | MEMBER(会员)
      dateType   : 时间类型，MONTH(月) | WEEK(周)
      endDate    : 结束日期，格式 yyyyMMdd
    """
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if crowd_type is not None:
        request["crowdType"] = crowd_type
    if date_type is not None:
        request["dateType"] = date_type
    if end_date is not None:
        request["endDate"] = end_date

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.trust.TrustAnalysisMtopService",
        method_name="queryCustomerData",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.ai.request.CustomerAnalysisReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryCustomerData(1) END ===


# === KdtDataQueryForClawCliApi.recallSemantics(1) BEGIN ===
RECALL_SEMANTICS_REQUEST_SCHEMA = {
    "name": "RecallSemanticsCliReq",
    "description": "语义召回请求",
    "fields": [
        {"name": "datasetId", "type": "Long", "required": True, "description": "数据集ID"},
        {"name": "query", "type": "String", "required": True, "description": "查询语句"},
        {"name": "topK", "type": "Integer", "required": False, "description": "返回结果数量"},
        {"name": "scoreThreshold", "type": "Float", "required": False, "description": "分数阈值"},
        {"name": "env", "type": "String", "required": False, "description": "环境"},
        {"name": "filter", "type": "RecallSemanticReqVO.Filter", "required": False, "description": "过滤条件"},
    ],
}

RECALL_SEMANTICS_RESPONSE_SCHEMA = {
    "name": "RecallSemanticRespVO",
    "description": "语义召回响应",
    "fields": [
        {"name": "totalCount", "type": "int", "required": True, "description": "总记录数"},
        {"name": "wordSegment", "type": "List<String>", "required": False, "description": "分词结果"},
        {"name": "result", "type": "List<Entity>", "required": False, "description": "召回结果列表（每项含 score、entityType、entityStandardName）"},
    ],
}


@data_analysis_cli.command("recall-semantics")
@click.option(
    "--dataset-id",
    type=int,
    required=False,
    help="数据集ID",
)
@click.option(
    "--query",
    type=str,
    required=False,
    help="查询语句",
)
@click.option(
    "--top-k",
    type=int,
    required=False,
    help="返回结果数量",
)
@click.option(
    "--score-threshold",
    type=float,
    required=False,
    help="分数阈值",
)
@click.option(
    "--env",
    type=str,
    required=False,
    help="环境",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def recall_semantics_cmd(
    dataset_id: Optional[int],
    query: Optional[str],
    top_k: Optional[int],
    score_threshold: Optional[float],
    env: Optional[str],
    request_json: Optional[str],
):
    """语义召回

    \b
    参数说明：
      datasetId      : (必填) 数据集ID
      query          : (必填) 查询语句
      topK           : (可选) 返回结果数量
      scoreThreshold : (可选) 分数阈值
      env            : (可选) 环境
      filter         : (可选) 过滤条件，通过 --request JSON 传入

    \b
    filter 结构：
    {
      "filter": {"entityType": "实体类型", "entityTypes": ["类型1", "类型2"]}
    }
    """
    api = CrmAPI()

    request = parse_optional_request_json(request_json)

    if dataset_id is not None:
        request["datasetId"] = dataset_id
    if query is not None:
        request["query"] = query
    if top_k is not None:
        request["topK"] = top_k
    if score_threshold is not None:
        request["scoreThreshold"] = score_threshold
    if env is not None:
        request["env"] = env

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.dataanalysis.KdtDataQueryForClawCliApi",
        method_name="recallSemantics",
        method_signature=["com.alsc.crm.bench.cli.dataanalysis.request.RecallSemanticsCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === KdtDataQueryForClawCliApi.recallSemantics(1) END ===


# === KdtDataQueryForClawCliApi.queryData(1) BEGIN ===
QUERY_DATA_REQUEST_SCHEMA = {
    "name": "QueryDataCliReq",
    "description": "数据查询请求",
    "fields": [
        {"name": "select", "type": "List<DataQuerySelectParam>", "required": True, "description": "查询字段"},
        {"name": "filter", "type": "DataQueryFilterParam", "required": True, "description": "过滤条件"},
        {"name": "ds", "type": "DataQueryDsParam", "required": True, "description": "数据集参数"},
        {"name": "group", "type": "List<DataQuerySelectParam>", "required": False, "description": "分组字段"},
        {"name": "compare", "type": "List<String>", "required": False, "description": "对比维度（逗号分隔）"},
        {"name": "customCycleConfig", "type": "List<DataQueryCycleConfig>", "required": False, "description": "自定义周期配置"},
        {"name": "orderBy", "type": "List<DataQueryOrderByParam>", "required": False, "description": "排序字段"},
        {"name": "statisticType", "type": "String", "required": False, "description": "统计类型"},
        {"name": "semanticDataSetId", "type": "Long", "required": True, "description": "语义数据集ID"},
        {"name": "page", "type": "Integer", "required": False, "description": "页码，从1开始，默认1"},
        {"name": "pageSize", "type": "Integer", "required": False, "description": "每页条数，默认100"},
        {"name": "queryCount", "type": "Boolean", "required": False, "description": "是否查询总量，默认false"},
    ],
}

QUERY_DATA_RESPONSE_SCHEMA = {
    "name": "DataQueryRespVO",
    "description": "数据查询响应",
    "fields": [
        {"name": "totalCount", "type": "long", "required": True, "description": "总记录数"},
        {"name": "result", "type": "Object", "required": False, "description": "查询结果"},
    ],
}


@data_analysis_cli.command("query-data")
@click.option(
    "--semantic-data-set-id",
    type=int,
    required=False,
    help="语义数据集ID",
)
@click.option(
    "--compare",
    type=str,
    required=False,
    help="对比维度（逗号分隔，如 dim1,dim2）",
)
@click.option(
    "--statistic-type",
    type=str,
    required=False,
    help="统计类型",
)
@click.option(
    "--page",
    type=int,
    required=False,
    help="页码，从1开始，默认1",
)
@click.option(
    "--page-size",
    type=int,
    required=False,
    help="每页条数，默认100",
)
@click.option(
    "--query-count",
    is_flag=True,
    default=False,
    help="是否查询总量，默认false",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_data_cmd(
    semantic_data_set_id: Optional[int],
    compare: Optional[str],
    statistic_type: Optional[str],
    page: Optional[int],
    page_size: Optional[int],
    query_count: bool,
    request_json: Optional[str],
):
    """数据查询

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    复杂结构参数通过 --request JSON 传入，结构如下：

    \b
    {
      "select": [{"columnEName": "字段英文名"}],
      "filter": {
        "relation": "and",
        "conditions": [
          {"columnEName": "字段英文名", "queryRule": "in|between|eq|gt|lt", "params": ["值1","值2"], "disabled": false}
        ]
      },
      "ds": {"type": "between", "values": ["开始日期", "结束日期"]},
      "group": [{"columnEName": "字段英文名"}],
      "orderBy": [{"columnEName": "字段英文名", "orderType": "asc|desc"}],
      "customCycleConfig": [{"cycleType": "...", "startDate": "...", "endDate": "..."}],
      "semanticDataSetId": 10002381,
      "compare": ["维度1", "维度2"],
      "statisticType": "统计类型",
      "page": 1,
      "pageSize": 100,
      "queryCount": true
    }
    """
    api = CrmAPI()

    request = parse_optional_request_json(request_json)

    if semantic_data_set_id is not None:
        request["semanticDataSetId"] = semantic_data_set_id
    if compare is not None:
        request["compare"] = [c.strip() for c in compare.split(",") if c.strip()]
    if statistic_type is not None:
        request["statisticType"] = statistic_type
    if page is not None:
        request["page"] = page
    if page_size is not None:
        request["pageSize"] = page_size
    if query_count:
        request["queryCount"] = query_count

    result = _query_data_async(api, request)
    output(result)
# === KdtDataQueryForClawCliApi.queryData(1) END ===


# === query-activity-effect（封装异步数据查询, dataset 10002381）BEGIN ===
# 活动效果查询专用命令：固定 dataset 10002381，字段集为场景3已验证的 6 维度 + 16 指标
# 底层复用 asyncQueryData + queryAsyncDataResult（QueryDataCliReq）
ACTIVITY_EFFECT_DATASET_ID = 10002381

# 展示维度（group，一行一活动；不含业务日期——业务日期仅作 ds 过滤）
ACTIVITY_EFFECT_DIMENSIONS = [
    "CRM活动id",
    "CRM活动名称",
    "活动类型名称",
    "活动状态",
    "CRM活动创建时间",
    "CRM活动结束时间",
]

# 效果指标（select，16 个，场景3 2026-06-18 已验证）
ACTIVITY_EFFECT_METRICS = [
    "净GMV",
    "店均活动订单净G",
    "总订单数",
    "店均订单数",
    "补贴金额",
    "店均活动优惠金额",
    "当日发券量",
    "店均发券量",
    "当日核销券量",
    "店均核销券量",
    "当日券核销率",
    "店均券核销率",
    "活动适用门店数",
    "商户活动覆盖率",
    "CRM活动ROI",
    "店均ROI",
]

# 活动状态默认过滤（有效状态）
ACTIVITY_EFFECT_DEFAULT_STATUS = ["IN_ENABLED", "STARTING", "ENABLED"]


@data_analysis_cli.command("query-activity-effect")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="效果统计开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="效果统计结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部16个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="desc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_activity_effect_cmd(
    dimensions: Optional[str],
    filters,
    start_date: Optional[str],
    end_date: Optional[str],
    metrics: Optional[str],
    order_by_field: str,
    sort_order: str,
    page: int,
    page_size: int,
    query_count: bool,
):
    """查询 CRM 营销活动效果（dataset 10002381，一行一活动，ds 范围内指标汇总）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选聚合维度（group，可用 --dimensions 选子集）：
      CRM活动id / CRM活动名称 / 活动类型名称 / 活动状态 / CRM活动创建时间 / CRM活动结束时间

    \b
    可查询指标（16 个，默认全部，可用 --metrics 逗号分隔选子集）：
      净GMV / 店均活动订单净G / 总订单数 / 店均订单数 / 补贴金额 / 店均活动优惠金额 /
      当日发券量 / 店均发券量 / 当日核销券量 / 店均核销券量 / 当日券核销率 / 店均券核销率 /
      活动适用门店数 / 商户活动覆盖率 / CRM活动ROI / 店均ROI

    \b
    可用查询条件：
      --filter（任意可分组维度，格式 维度名=值1,值2；如 "活动状态=ENABLED"）
      --start-date / --end-date（ds 时间范围，默认近 7 天 [T-7, T-1]） / --dimensions
      未指定 活动状态/CRM活动id/CRM活动名称 筛选时，默认按有效状态 IN_ENABLED,STARTING,ENABLED 过滤

    \b
    注：品牌隔离字段（crm品牌id 等）由后端自动注入，无需传入。
    """
    api = CrmAPI()

    # ds 默认近 7 天 [T-7, T-1]（数据 T+1，今天只能查到昨天）
    if not end_date:
        end_date = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    if not start_date:
        start_date = (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")

    # 指标 select（默认全部 16 个，支持逗号选子集）
    if metrics:
        metric_names = [m.strip() for m in metrics.split(",") if m.strip()]
        invalid = [m for m in metric_names if m not in ACTIVITY_EFFECT_METRICS]
        if invalid:
            raise click.BadParameter(
                "不支持的指标: %s；可选: %s"
                % (", ".join(invalid), ", ".join(ACTIVITY_EFFECT_METRICS))
            )
    else:
        metric_names = list(ACTIVITY_EFFECT_METRICS)

    if dimensions:
        dimension_names = [d.strip() for d in dimensions.split(",") if d.strip()]
        invalid_dims = [d for d in dimension_names if d not in ACTIVITY_EFFECT_DIMENSIONS]
        if invalid_dims:
            raise click.BadParameter(
                "不支持的维度: %s；可选: %s"
                % (", ".join(invalid_dims), ", ".join(ACTIVITY_EFFECT_DIMENSIONS))
            )
    else:
        dimension_names = list(ACTIVITY_EFFECT_DIMENSIONS)

    select = [{"columnEName": m} for m in metric_names]
    group = [{"columnEName": d} for d in dimension_names]

    # filter 构建（任意可分组维度均可筛选，queryRule=in）
    conditions = _build_filter_conditions(filters, ACTIVITY_EFFECT_DIMENSIONS)
    filtered_names = {c["columnEName"] for c in conditions}

    # 活动状态：显式指定优先；否则仅当未按 活动状态/活动id/活动名称 筛选时加默认有效状态
    if not {"活动状态", "CRM活动id", "CRM活动名称"} & filtered_names:
        conditions.append({"columnEName": "活动状态", "queryRule": "in", "params": list(ACTIVITY_EFFECT_DEFAULT_STATUS), "disabled": False})

    request = {
        "semanticDataSetId": ACTIVITY_EFFECT_DATASET_ID,
        "ds": {"type": "between", "values": [start_date, end_date]},
        "select": select,
        "group": group,
        "filter": {"relation": "and", "conditions": conditions},
        "page": page,
        "pageSize": page_size,
    }
    if order_by_field:
        request["orderBy"] = [{"columnEName": order_by_field, "orderType": sort_order.lower()}]
    if query_count:
        request["queryCount"] = True

    result = _query_data_async(api, request)
    output(result)
# === query-activity-effect（封装异步数据查询, dataset 10002381）END ===


# === 通用数据集查询命令（固化字段, 封装异步数据查询）BEGIN ===
def _build_filter_conditions(filters, all_dimensions):
    """将 --filter 传入的 "维度名=值1,值2" 列表解析为 queryRule=in 的过滤条件。

    维度名须在 all_dimensions 白名单内，否则报错；任意可分组维度均可作为筛选条件。
    """
    conditions = []
    for item in filters or ():
        if "=" not in item:
            raise click.BadParameter("筛选格式错误: %s；应为 维度名=值1,值2" % item)
        name, _, raw = item.partition("=")
        name = name.strip()
        if name not in all_dimensions:
            raise click.BadParameter(
                "不支持的筛选维度: %s；可选: %s" % (name, ", ".join(all_dimensions))
            )
        values = [v.strip() for v in raw.split(",") if v.strip()]
        if not values:
            raise click.BadParameter("筛选维度 %s 缺少取值" % name)
        conditions.append({"columnEName": name, "queryRule": "in", "params": values, "disabled": False})
    return conditions


def _run_semantic_dataset_query(dataset_id, all_metrics, metrics, all_dimensions, dimensions,
                                filters, ds_values, order_by_field, sort_order,
                                page, page_size, query_count,
                                async_query_method="asyncQueryData"):
    """按固化维度(group)/指标(select)构建 QueryDataCliReq 并发起异步数据查询。

    filters：--filter 传入的 "维度名=值1,值2" 列表，按 all_dimensions 白名单校验后转为 in 过滤条件。
    """
    conditions = _build_filter_conditions(filters, all_dimensions)
    if metrics:
        metric_names = [m.strip() for m in metrics.split(",") if m.strip()]
        invalid = [m for m in metric_names if m not in all_metrics]
        if invalid:
            raise click.BadParameter(
                "不支持的指标: %s；可选: %s" % (", ".join(invalid), ", ".join(all_metrics))
            )
    else:
        metric_names = list(all_metrics)
    if dimensions:
        dimension_names = [d.strip() for d in dimensions.split(",") if d.strip()]
        invalid_dims = [d for d in dimension_names if d not in all_dimensions]
        if invalid_dims:
            raise click.BadParameter(
                "不支持的维度: %s；可选: %s" % (", ".join(invalid_dims), ", ".join(all_dimensions))
            )
    else:
        dimension_names = list(all_dimensions)
    request = {
        "semanticDataSetId": dataset_id,
        "ds": {"type": "between", "values": ds_values},
        "select": [{"columnEName": m} for m in metric_names],
        "group": [{"columnEName": d} for d in dimension_names],
        "filter": {"relation": "and", "conditions": conditions},
        "page": page,
        "pageSize": page_size,
    }
    if order_by_field:
        request["orderBy"] = [{"columnEName": order_by_field, "orderType": sort_order.lower()}]
    if query_count:
        request["queryCount"] = True
    api = CrmAPI()
    result = _query_data_async(api, request, async_query_method)
    output(result)


# --- 10002365 品牌CRM门店活动配置明细 ---
SHOP_ACTIVITY_CONFIG_DATASET_ID = 10002365
SHOP_ACTIVITY_CONFIG_DIMENSIONS = ["crm门店id", "crm门店名称"]
SHOP_ACTIVITY_CONFIG_METRICS = [
    "是否开通会员卡", "是否开通开卡礼", "是否开通会员特价菜", "是否开通新会员特价菜",
    "是否开通等级礼", "是否开通会员粉丝群", "是否开通累计消费次数送券活动",
    "是否开通累计金额送券活动", "是否开通畅享金", "是否有生效的会员日活动",
    "是否有生效的会员日领券活动", "是否有生效的会员日专享菜活动",
]


@data_analysis_cli.command("query-shop-activity-config")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部12个")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=35000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_shop_activity_config_cmd(dimensions, filters, date_, metrics, page, page_size, query_count):
    """查询 CRM 门店活动配置明细（dataset 10002365，一行一门店，单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，可用 --dimensions 选子集）：crm门店id / crm门店名称

    \b
    可查询指标（12 个 0/1 标志位，默认全部）：
      是否开通会员卡 / 是否开通开卡礼 / 是否开通会员特价菜 / 是否开通新会员特价菜 /
      是否开通等级礼 / 是否开通会员粉丝群 / 是否开通累计消费次数送券活动 /
      是否开通累计金额送券活动 / 是否开通畅享金 / 是否有生效的会员日活动 /
      是否有生效的会员日领券活动 / 是否有生效的会员日专享菜活动

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions

    \b
    注：本数据集为配置快照，ds 固定单日；品牌隔离字段由后端自动注入。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        SHOP_ACTIVITY_CONFIG_DATASET_ID, SHOP_ACTIVITY_CONFIG_METRICS, metrics,
        SHOP_ACTIVITY_CONFIG_DIMENSIONS, dimensions, filters, [day, day],
        "crm门店id", "asc", page, page_size, query_count,
    )


# --- 10002383 品牌CRM活动商品 ---
ACTIVITY_PRODUCT_DATASET_ID = 10002383
ACTIVITY_PRODUCT_DIMENSIONS = [
    "CRM活动id", "CRM活动名称", "CRM活动类型名称", "活动状态",
    "商品规格id", "商品名称", "商品优惠类型",
]
ACTIVITY_PRODUCT_METRICS = [
    "净GMV", "活动商品订单数", "活动商品购买份数", "活动商品优惠金额",
    "活动商品核销金额", "活动商品ROI", "商品原价", "商品核销价格",
]


@data_analysis_cli.command("query-activity-product")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部8个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_activity_product_cmd(dimensions, filters, start_date, end_date, metrics, order_by_field, sort_order,
                               page, page_size, query_count):
    """查询 CRM 活动商品（dataset 10002383，一行一 活动×商品规格）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，可用 --dimensions 选子集）：
      CRM活动id / CRM活动名称 / CRM活动类型名称 / 活动状态 / 商品规格id / 商品名称 / 商品优惠类型

    \b
    可查询指标（8 个，默认全部）：
      净GMV / 活动商品订单数 / 活动商品购买份数 / 活动商品优惠金额 / 活动商品核销金额 /
      活动商品ROI / 商品原价 / 商品核销价格

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称）禁止作为查询/分组条件，由后端自动注入。
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        ACTIVITY_PRODUCT_DATASET_ID, ACTIVITY_PRODUCT_METRICS, metrics,
        ACTIVITY_PRODUCT_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002373 品牌CRM券效果 ---
COUPON_EFFECT_DATASET_ID = 10002373
COUPON_EFFECT_DIMENSIONS = ["券模版id", "券模板名称", "CRM活动id", "活动状态", "crm活动类型id"]
COUPON_EFFECT_METRICS = [
    "CRM券面额", "发券券门槛", "当日发券量", "当日核销券量",
    "当日失效券量", "当日券核销率", "剩余可发券量",
]


@data_analysis_cli.command("query-coupon-effect")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部7个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_coupon_effect_cmd(dimensions, filters, start_date, end_date,
                            metrics, order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 券效果（dataset 10002373，一行一 券模版×活动）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，可用 --dimensions 选子集）：券模版id / 券模板名称 / CRM活动id / 活动状态 / crm活动类型id

    \b
    可查询指标（7 个，默认全部）：
      CRM券面额 / 发券券门槛 / 当日发券量 / 当日核销券量 / 当日失效券量 / 当日券核销率 / 剩余可发券量

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions

    \b
    注：品牌隔离字段由后端自动注入。
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        COUPON_EFFECT_DATASET_ID, COUPON_EFFECT_METRICS, metrics,
        COUPON_EFFECT_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002353 品牌crm精准营销 ---
PRECISION_MARKETING_DATASET_ID = 10002353
PRECISION_MARKETING_DIMENSIONS = [
    "触达活动id", "触达活动名称（三级场景）", "投放计划id", "投放计划名称",
    "投放渠道名称", "投放人群类型", "投放场景",
]
PRECISION_MARKETING_METRICS = [
    "近1日触达人数", "触达率", "触达后当日下单量", "触达后当日下单净G", "当日进店人数",
    "近1日进店转化率",
    "触达后3日进店人数", "触达后3日内进店率", "触达后3日内下单量", "触达后3日内下单人数",
    "触达后3日内下单净G", "触达后3日内入会人数", "触达后3天内ROI",
    "触达后7日进店人数", "触达后7日内进店率", "触达后7日内下单量", "触达后7日内下单人数",
    "触达后7日内下单净G", "触达后7日内入会人数", "触达后7天内ROI",
    "近1天投放人数", "近1天投放成功人数", "近1天投放消耗金额", "近1日投放ROI",
    "近1日精准营销活动发券数", "近1日精准营销核销券数", "近1日精准营销核销订单数",
    "精准营销核销券订单净G", "精准营销券核销率", "精准营销剩余券量", "精准营销失效券量",
    "精准营销平均发券门槛", "精准营销平均核销券门槛",
    "平均发券面额", "核销券均面额", "券面额上限", "券面额下限", "券门槛下限",
    "CRM券ROI", "入会人数",
]


@data_analysis_cli.command("query-precision-marketing")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部40个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_precision_marketing_cmd(dimensions, filters,
                                  start_date, end_date, metrics, order_by_field, sort_order,
                                  page, page_size, query_count):
    """查询 CRM 精准营销效果（dataset 10002353，一行一 投放计划×触达活动）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，可用 --dimensions 选子集）：
      触达活动id / 触达活动名称（三级场景） / 投放计划id / 投放计划名称 /
      投放渠道名称 / 投放人群类型 / 投放场景

    \b
    可查询指标（40 个，默认全部）：触达/进店/下单/入会/ROI/发券/核销/券面额门槛 等

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称）禁止作为查询/分组条件，由后端自动注入。
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        PRECISION_MARKETING_DATASET_ID, PRECISION_MARKETING_METRICS, metrics,
        PRECISION_MARKETING_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002435 品牌CRM商品×商户交易/流向数据 ---
PRODUCT_DIAGNOSIS_DATASET_ID = 10002435
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
PRODUCT_DIAGNOSIS_DIMENSIONS = [
    # 商品
    "商品id", "商品名称", "商品152类目叶子类目完整路径", "商品299类目叶子类目完整路径",
    "口味", "食材", "主食", "是否套餐",
    # 商户/门店
    "商户ID", "门店名称", "商户所属城市id", "商户所属的地理城市",
    "商圈名称", "AOI标签类型", "是否crm签约门店", "是否新店期", "是否卫星店",
    # 用户
    "用户ID", "是否会员",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
]
PRODUCT_DIAGNOSIS_METRICS = [
    "净GMV", "有效订单数", "购买商品份数", "近1天商品用户实付金额",
    "近一天_搭售订单数", "店均净G", "店均订单数", "商品原价", "下单用户数",
]


@data_analysis_cli.command("query-product-diagnosis")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部9个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_product_diagnosis_cmd(dimensions, filters,
                                date_, metrics, order_by_field, sort_order,
                                page, page_size, query_count):
    """查询 CRM 商品×商户 交易/流向数据（dataset 10002435，单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 25 个，可用 --dimensions 选子集）：
      商品：商品id / 商品名称 / 商品152类目叶子类目完整路径 / 商品299类目叶子类目完整路径 /
            口味 / 食材 / 主食 / 是否套餐
      商户：商户ID / 门店名称 / 商户所属城市id / 商户所属的地理城市 /
            商圈名称 / AOI标签类型 / 是否crm签约门店 / 是否新店期 / 是否卫星店
      用户：用户ID / 是否会员
      TRUST分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层

    \b
    可查询指标（9 个，默认全部）：
      净GMV / 有效订单数 / 购买商品份数 / 近1天商品用户实付金额 /
      近一天_搭售订单数 / 店均净G / 店均订单数 / 商品原价 / 下单用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --date / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，
        禁止作为查询/分组条件，由后端自动注入。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        PRODUCT_DIAGNOSIS_DATASET_ID, PRODUCT_DIAGNOSIS_METRICS, metrics,
        PRODUCT_DIAGNOSIS_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002435 品牌所属品类 商品交易数据（同数据集，含品类品牌TOP5排名维度） ---
CATEGORY_PRODUCT_DIAGNOSIS_DIMENSIONS = [
    # 商品
    "商品id", "商品名称", "商品152类目叶子类目完整路径", "商品299类目叶子类目完整路径",
    "口味", "食材", "主食", "是否套餐",
    # 商户/门店（不含 商户1.5级品类）
    "商户ID", "门店名称", "商户所属城市id", "商户所属的地理城市",
    "商圈名称", "AOI标签类型", "是否crm签约门店", "是否新店期", "是否卫星店",
    # 用户
    "用户ID", "是否会员",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
    # 品类品牌 TOP5 排名
    "品类累计净G品牌TOP5排名", "品类累计单量品牌TOP5排名", "品类店均净G品牌TOP5排名",
    "城市品类累计净G品牌TOP5排名", "城市品类累计单量品牌TOP5排名", "城市品类店均净G品牌TOP5排名",
    "商圈品类累计净G品牌TOP5排名", "商圈品类累计单量品牌TOP5排名", "商圈品类店均净G品牌TOP5排名",
]
CATEGORY_PRODUCT_DIAGNOSIS_METRICS = [
    "净GMV", "有效订单数", "购买商品份数", "近1天商品用户实付金额",
    "近一天_搭售订单数", "店均净G", "店均订单数", "商品原价", "下单用户数",
]


@data_analysis_cli.command("query-category-product-diagnosis")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部9个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_category_product_diagnosis_cmd(dimensions, filters,
                                         date_, metrics, order_by_field, sort_order,
                                         page, page_size, query_count):
    """查询 品牌所属品类 商品交易数据（dataset 10002435，含品类品牌TOP5排名维度，单日快照）

    注：本命令查询当前登录品牌所属品类的数据（品牌隔离由后端自动注入）。
        指标与维度不含 crm品牌id / crm品牌名称 / 商户1.5级品类。

    \b
    可选分组维度（group，默认全部 34 个，可用 --dimensions 选子集）：
      商品：商品id / 商品名称 / 商品152类目叶子类目完整路径 / 商品299类目叶子类目完整路径 /
            口味 / 食材 / 主食 / 是否套餐
      商户：商户ID / 门店名称 / 商户所属城市id / 商户所属的地理城市 /
            商圈名称 / AOI标签类型 / 是否crm签约门店 / 是否新店期 / 是否卫星店
      用户：用户ID / 是否会员
      TRUST分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层
      品类TOP5排名：品类累计净G品牌TOP5排名 / 品类累计单量品牌TOP5排名 / 品类店均净G品牌TOP5排名 /
            城市品类累计净G品牌TOP5排名 / 城市品类累计单量品牌TOP5排名 / 城市品类店均净G品牌TOP5排名 /
            商圈品类累计净G品牌TOP5排名 / 商圈品类累计单量品牌TOP5排名 / 商圈品类店均净G品牌TOP5排名

    \b
    可查询指标（9 个，默认全部）：
      净GMV / 有效订单数 / 购买商品份数 / 近1天商品用户实付金额 /
      近一天_搭售订单数 / 店均净G / 店均订单数 / 商品原价 / 下单用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --date / --dimensions
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        PRODUCT_DIAGNOSIS_DATASET_ID, CATEGORY_PRODUCT_DIAGNOSIS_METRICS, metrics,
        CATEGORY_PRODUCT_DIAGNOSIS_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
        async_query_method="asyncQueryDataByMerchantCategory",
    )


# --- 10002439 品牌CRM品牌开关店情况 ---
SHOP_OPEN_CLOSE_DATASET_ID = 10002439
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
SHOP_OPEN_CLOSE_DIMENSIONS = [
    "周期类型", "城市", "城市id",
]
SHOP_OPEN_CLOSE_METRICS = [
    "新开门店数", "门店闭店数", "营业门店净增数", "存续率", "闭店率",
]


@data_analysis_cli.command("query-shop-open-close")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部5个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_shop_open_close_cmd(dimensions, filters, date_, metrics,
                              order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 品牌开关店情况（dataset 10002439，单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 3 个，可用 --dimensions 选子集）：周期类型 / 城市 / 城市id

    \b
    可查询指标（5 个，默认全部）：新开门店数 / 门店闭店数 / 营业门店净增数 / 存续率 / 闭店率

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，
        禁止作为查询/分组条件，由后端自动注入。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        SHOP_OPEN_CLOSE_DATASET_ID, SHOP_OPEN_CLOSE_METRICS, metrics,
        SHOP_OPEN_CLOSE_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002427 品牌CRM入会资产 ---
MEMBER_ASSET_DATASET_ID = 10002427
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
MEMBER_ASSET_DIMENSIONS = [
    # 会员/顾客
    "入会日", "入会日期", "等级序号", "顾客类型", "年龄区间", "性别",
    # 商户/门店
    "商户ID", "门店名称", "商圈名称", "商户所属城市id", "商户所属的地理城市",
    "AOI标签类型", "是否新店期", "是否卫星店",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
]
MEMBER_ASSET_METRICS = [
    "店均拉新人数", "淘宝闪购用户数", "有效商户数", "新入会人数",
]


@data_analysis_cli.command("query-member-asset")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部4个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_member_asset_cmd(dimensions, filters,
                           date_, metrics, order_by_field, sort_order,
                           page, page_size, query_count):
    """查询 CRM 入会资产（dataset 10002427，单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 20 个，可用 --dimensions 选子集）：
      会员/顾客：入会日 / 入会日期 / 等级序号 / 顾客类型 / 年龄区间 / 性别
      商户：商户ID / 门店名称 / 商圈名称 / 商户所属城市id /
            商户所属的地理城市 / AOI标签类型 / 是否新店期 / 是否卫星店
      TRUST分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层

    \b
    可查询指标（4 个，默认全部）：店均拉新人数 / 淘宝闪购用户数 / 有效商户数 / 新入会人数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --date / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，
        禁止作为查询/分组条件，由后端自动注入。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        MEMBER_ASSET_DATASET_ID, MEMBER_ASSET_METRICS, metrics,
        MEMBER_ASSET_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002427 品牌所属品类 入会资产（同数据集，含品类品牌TOP5排名维度） ---
CATEGORY_MEMBER_ASSET_DIMENSIONS = [
    # 会员/顾客
    "入会日", "入会日期", "等级序号", "顾客类型", "年龄区间", "性别",
    # 商户/门店（不含 品牌1.5级品类名称）
    "商户ID", "门店名称", "商圈名称", "商户所属城市id", "商户所属的地理城市",
    "AOI标签类型", "是否新店期", "是否卫星店",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
    # 品类品牌 TOP5 排名
    "品类累计净G品牌TOP5排名", "品类累计单量品牌TOP5排名", "品类店均净G品牌TOP5排名",
    "城市品类累计净G品牌TOP5排名", "城市品类累计单量品牌TOP5排名", "城市品类店均净G品牌TOP5排名",
    "商圈品类累计净G品牌TOP5排名", "商圈品类累计单量品牌TOP5排名", "商圈品类店均净G品牌TOP5排名",
]
CATEGORY_MEMBER_ASSET_METRICS = [
    "店均拉新人数", "淘宝闪购用户数", "有效商户数", "新入会人数",
]


@data_analysis_cli.command("query-category-member-asset")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部4个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_category_member_asset_cmd(dimensions, filters,
                                    date_, metrics, order_by_field, sort_order,
                                    page, page_size, query_count):
    """查询 品牌所属品类 入会资产（dataset 10002427，含品类品牌TOP5排名维度，单日快照）

    注：本命令查询当前登录品牌所属品类的数据（品牌隔离由后端自动注入）。
        指标与维度不含 crm品牌id / crm品牌名称 / 品牌1.5级品类名称。

    \b
    可选分组维度（group，默认全部 29 个，可用 --dimensions 选子集）：
      会员/顾客：入会日 / 入会日期 / 等级序号 / 顾客类型 / 年龄区间 / 性别
      商户：商户ID / 门店名称 / 商圈名称 / 商户所属城市id /
            商户所属的地理城市 / AOI标签类型 / 是否新店期 / 是否卫星店
      TRUST分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层
      品类TOP5排名：品类累计净G品牌TOP5排名 / 品类累计单量品牌TOP5排名 / 品类店均净G品牌TOP5排名 /
            城市品类累计净G品牌TOP5排名 / 城市品类累计单量品牌TOP5排名 / 城市品类店均净G品牌TOP5排名 /
            商圈品类累计净G品牌TOP5排名 / 商圈品类累计单量品牌TOP5排名 / 商圈品类店均净G品牌TOP5排名

    \b
    可查询指标（4 个，默认全部）：店均拉新人数 / 淘宝闪购用户数 / 有效商户数 / 新入会人数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --date / --dimensions
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        MEMBER_ASSET_DATASET_ID, CATEGORY_MEMBER_ASSET_METRICS, metrics,
        CATEGORY_MEMBER_ASSET_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
        async_query_method="asyncQueryDataByMerchantCategory",
    )


# --- 10002417 品牌CRM交易数据 ---
TRADE_DATA_DATASET_ID = 10002417
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
TRADE_DATA_DIMENSIONS = [
    # 会员/顾客
    "顾客类型", "等级序号", "年龄区间", "性别", "消费日", "订单价格带", "下单时段",
    # 商户/门店
    "商户ID", "门店名称", "商圈名称", "商户所属城市id", "商户所属的地理城市",
    "AOI标签类型", "是否crm签约门店", "是否新店期", "是否卫星店",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
]
TRADE_DATA_METRICS = [
    "净GMV", "有效订单数", "店均净G", "店均订单数", "人均净交易额", "净笔单价",
    "日购频", "品牌复购用户数", "门店用户复购数", "商户补贴金额", "下单用户数",
]


@data_analysis_cli.command("query-trade-data")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部11个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_trade_data_cmd(dimensions, filters,
                         start_date, end_date, metrics,
                         order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 交易数据（dataset 10002417，商户/门店×用户分层交易宽表）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 22 个，可用 --dimensions 选子集）：
      会员/顾客：顾客类型/等级序号/年龄区间/性别/消费日/订单价格带/下单时段
      商户/门店：商户ID / 门店名称 / 商圈名称 / 商户所属城市id / 商户所属的地理城市 / AOI标签类型 / 是否crm签约门店 / 是否新店期 / 是否卫星店
      TRUST 分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层

    \b
    可查询指标（11 个，默认全部）：
      净GMV/有效订单数/店均净G/店均订单数/人均净交易额/净笔单价/
      日购频/品牌复购用户数/门店用户复购数/商户补贴金额/下单用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，
        禁止作为查询/分组条件，由后端自动注入。
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        TRADE_DATA_DATASET_ID, TRADE_DATA_METRICS, metrics,
        TRADE_DATA_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002417 品牌所属品类 交易数据（同数据集，含品类品牌TOP5排名维度） ---
CATEGORY_TRADE_DATA_DIMENSIONS = [
    # 会员/顾客
    "顾客类型", "等级序号", "年龄区间", "性别", "消费日", "订单价格带", "下单时段",
    # 商户/门店（不含 商户1.5级品类）
    "商户ID", "门店名称", "商圈名称", "商户所属城市id", "商户所属的地理城市",
    "AOI标签类型", "是否crm签约门店", "是否新店期", "是否卫星店",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
    # 品类品牌 TOP5 排名
    "品类累计净G品牌TOP5排名", "品类累计单量品牌TOP5排名", "品类店均净G品牌TOP5排名",
    "城市品类累计净G品牌TOP5排名", "城市品类累计单量品牌TOP5排名", "城市品类店均净G品牌TOP5排名",
    "商圈品类累计净G品牌TOP5排名", "商圈品类累计单量品牌TOP5排名", "商圈品类店均净G品牌TOP5排名",
]
CATEGORY_TRADE_DATA_METRICS = [
    "净GMV", "有效订单数", "店均净G", "店均订单数", "人均净交易额", "净笔单价",
    "日购频", "品牌复购用户数", "门店用户复购数", "商户补贴金额", "下单用户数",
]


@data_analysis_cli.command("query-category-trade-data")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部11个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_category_trade_data_cmd(dimensions, filters,
                                  start_date, end_date, metrics,
                                  order_by_field, sort_order, page, page_size, query_count):
    """查询 品牌所属品类 交易数据（dataset 10002417，含品类品牌TOP5排名维度，交易宽表）

    注：本命令查询当前登录品牌所属品类的数据（品牌隔离由后端自动注入）。
        指标与维度不含 crm品牌id / crm品牌名称 / 商户1.5级品类。

    \b
    可选分组维度（group，默认全部 31 个，可用 --dimensions 选子集）：
      会员/顾客：顾客类型/等级序号/年龄区间/性别/消费日/订单价格带/下单时段
      商户/门店：商户ID / 门店名称 / 商圈名称 / 商户所属城市id / 商户所属的地理城市 / AOI标签类型 / 是否crm签约门店 / 是否新店期 / 是否卫星店
      TRUST 分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层
      品类TOP5：品类累计净G品牌TOP5排名 / 品类累计单量品牌TOP5排名 / 品类店均净G品牌TOP5排名 /
            城市品类累计净G品牌TOP5排名 / 城市品类累计单量品牌TOP5排名 / 城市品类店均净G品牌TOP5排名 /
            商圈品类累计净G品牌TOP5排名 / 商圈品类累计单量品牌TOP5排名 / 商圈品类店均净G品牌TOP5排名

    \b
    可查询指标（11 个，默认全部）：
      净GMV/有效订单数/店均净G/店均订单数/人均净交易额/净笔单价/
      日购频/品牌复购用户数/门店用户复购数/商户补贴金额/下单用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        TRADE_DATA_DATASET_ID, CATEGORY_TRADE_DATA_METRICS, metrics,
        CATEGORY_TRADE_DATA_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
        async_query_method="asyncQueryDataByMerchantCategory",
    )


# --- 10002421 品牌CRM交易漏斗 ---
TRADE_FUNNEL_DATASET_ID = 10002421
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
TRADE_FUNNEL_DIMENSIONS = [
    # 会员/顾客
    "顾客类型", "年龄区间", "性别", "消费日", "下单时段",
    # 商户/门店
    "商户ID", "门店名称", "商圈名称", "商户所属城市id", "商户所属的地理城市",
    "AOI标签类型", "是否新店期", "是否卫星店",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
]
TRADE_FUNNEL_METRICS = [
    "曝光人数", "当日进店人数", "下单用户数", "淘宝闪购用户数",
]


@data_analysis_cli.command("query-trade-funnel")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部4个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_trade_funnel_cmd(dimensions, filters,
                           start_date, end_date, metrics,
                           order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 交易漏斗（dataset 10002421，商户/门店×用户分层漏斗宽表）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 19 个，可用 --dimensions 选子集）：
      会员/顾客：顾客类型/年龄区间/性别/消费日/下单时段
      商户/门店：商户ID / 门店名称 / 商圈名称 / 商户所属城市id / 商户所属的地理城市 / AOI标签类型 / 是否新店期 / 是否卫星店
      TRUST 分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层

    \b
    可查询指标（4 个，默认全部）：曝光人数 / 当日进店人数 / 下单用户数 / 淘宝闪购用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，
        禁止作为查询/分组条件，由后端自动注入。
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        TRADE_FUNNEL_DATASET_ID, TRADE_FUNNEL_METRICS, metrics,
        TRADE_FUNNEL_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002421 品牌所属品类 交易漏斗（同数据集，含品类品牌TOP5排名维度） ---
CATEGORY_TRADE_FUNNEL_DIMENSIONS = [
    # 会员/顾客
    "顾客类型", "年龄区间", "性别", "消费日", "下单时段",
    # 商户/门店（不含 商户1.5级品类）
    "商户ID", "门店名称", "商圈名称", "商户所属城市id", "商户所属的地理城市",
    "AOI标签类型", "是否新店期", "是否卫星店",
    # 门店/品牌 TRUST 分层
    "上一天_门店TRUST分层", "上自然周末_门店TRUST分层", "上月月底_门店TRUST分层",
    "上一日_品牌TRUST分层", "上自然周末_品牌TRUST分层", "上月月底_品牌TRUST分层",
    # 品类品牌 TOP5 排名
    "品类累计净G品牌TOP5排名", "品类累计单量品牌TOP5排名", "品类店均净G品牌TOP5排名",
    "城市品类累计净G品牌TOP5排名", "城市品类累计单量品牌TOP5排名", "城市品类店均净G品牌TOP5排名",
    "商圈品类累计净G品牌TOP5排名", "商圈品类累计单量品牌TOP5排名", "商圈品类店均净G品牌TOP5排名",
]
CATEGORY_TRADE_FUNNEL_METRICS = [
    "曝光人数", "当日进店人数", "下单用户数", "淘宝闪购用户数",
]


@data_analysis_cli.command("query-category-trade-funnel")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--start-date", type=str, required=False, help="开始日期 yyyyMMdd（默认 T-7）")
@click.option("--end-date", type=str, required=False, help="结束日期 yyyyMMdd（默认 T-1）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部4个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_category_trade_funnel_cmd(dimensions, filters,
                                    start_date, end_date, metrics,
                                    order_by_field, sort_order, page, page_size, query_count):
    """查询 品牌所属品类 交易漏斗（dataset 10002421，含品类品牌TOP5排名维度，漏斗宽表）

    注：本命令查询当前登录品牌所属品类的数据（品牌隔离由后端自动注入）。
        指标与维度不含 crm品牌id / crm品牌名称 / 商户1.5级品类。

    \b
    可选分组维度（group，默认全部 28 个，可用 --dimensions 选子集）：
      会员/顾客：顾客类型/年龄区间/性别/消费日/下单时段
      商户/门店：商户ID / 门店名称 / 商圈名称 / 商户所属城市id / 商户所属的地理城市 / AOI标签类型 / 是否新店期 / 是否卫星店
      TRUST 分层：上一天_门店TRUST分层 / 上自然周末_门店TRUST分层 / 上月月底_门店TRUST分层 /
            上一日_品牌TRUST分层 / 上自然周末_品牌TRUST分层 / 上月月底_品牌TRUST分层
      品类TOP5：品类累计净G品牌TOP5排名 / 品类累计单量品牌TOP5排名 / 品类店均净G品牌TOP5排名 /
            城市品类累计净G品牌TOP5排名 / 城市品类累计单量品牌TOP5排名 / 城市品类店均净G品牌TOP5排名 /
            商圈品类累计净G品牌TOP5排名 / 商圈品类累计单量品牌TOP5排名 / 商圈品类店均净G品牌TOP5排名

    \b
    可查询指标（4 个，默认全部）：曝光人数 / 当日进店人数 / 下单用户数 / 淘宝闪购用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2）
      --start-date / --end-date（默认近 7 天） / --dimensions
    """
    end = end_date or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    start = start_date or (datetime.now() - timedelta(days=7)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        TRADE_FUNNEL_DATASET_ID, CATEGORY_TRADE_FUNNEL_METRICS, metrics,
        CATEGORY_TRADE_FUNNEL_DIMENSIONS, dimensions, filters, [start, end],
        order_by_field, sort_order, page, page_size, query_count,
        async_query_method="asyncQueryDataByMerchantCategory",
    )


# --- 10002423 品牌CRM门店/商户粒度用户流向竞品 ---
# 字段依据 recallSemantics 召回结果修正（2026-07-15）：
#   原字段（同品类交易用户数/购买率/流入流出金额/渗透率等）均非标准语义，已废弃。
#   本数据集实为 10002425 的门店/商户粒度版（用户流向竞品，近30天口径单日快照）。
# 竞品流向商户/品牌为“流向目标竞品”，是本数据集核心输出维度（非调用方自身），予以保留。
# 品牌隔离字段（crm品牌id/crm品牌名称）不对外暴露，由后端自动注入。
SHOP_CATEGORY_FLOW_DATASET_ID = 10002423
SHOP_CATEGORY_FLOW_DIMENSIONS = [
    "商户ID", "门店名称", "城市", "城市id", "AOI标签类型",
    "是否闪购", "用户类型", "周期类型",
    "竞品流向商户id", "竞品流向商户名称", "竞品去向品牌ID", "竞品流向品牌名称", "竞品门店AOI点位",
]
SHOP_CATEGORY_FLOW_METRICS = [
    "近30天净交易额", "近30天有效订单数", "近30天购买商品份数", "订单量排行", "top订单量标准菜列表",
]


@data_analysis_cli.command("query-shop-category-flow")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部5个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_shop_category_flow_cmd(dimensions, filters, date_, metrics,
                                 order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 门店/商户粒度用户流向竞品（dataset 10002423，近30天口径单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 13 个，可用 --dimensions 选子集）：
      自身门店：商户ID / 门店名称 / 城市 / 城市id / AOI标签类型
      用户/交易：是否闪购 / 用户类型 / 周期类型
      竞品流向目标：竞品流向商户id / 竞品流向商户名称 / 竞品去向品牌ID / 竞品流向品牌名称 / 竞品门店AOI点位

    \b
    可查询指标（5 个，默认全部）：
      近30天净交易额 / 近30天有效订单数 / 近30天购买商品份数 / 订单量排行 / top订单量标准菜列表

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称）不对外暴露，由后端自动注入。
        竞品流向商户/品牌为“流向目标竞品”，是本数据集核心输出维度，予以保留。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        SHOP_CATEGORY_FLOW_DATASET_ID, SHOP_CATEGORY_FLOW_METRICS, metrics,
        SHOP_CATEGORY_FLOW_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002429 品牌CRM人群画像（EAV 键值对画像，品牌/城市粒度）---
# 字段依据 recallSemantics 召回结果修正（2026-07-15）
# 品牌隔离字段（crm品牌id）不对外暴露，由后端自动注入
# 线上为 EAV 键值对画像表：画像维度类型（如“性别”）+ 画像维度值（如“男”）
CROWD_PROFILE_DATASET_ID = 10002429
CROWD_PROFILE_DIMENSIONS = [
    "城市id", "交易类型", "周期类型", "投放人群类型", "画像维度类型", "画像维度值",
]
CROWD_PROFILE_METRICS = ["人数占比", "淘宝闪购用户数"]


@data_analysis_cli.command("query-crowd-profile")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部2个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_crowd_profile_cmd(dimensions, filters, date_, metrics,
                            order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 人群画像（dataset 10002429，EAV 键值对画像，品牌/城市粒度单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 6 个，可用 --dimensions 选子集）：
      城市id / 交易类型 / 周期类型 / 投放人群类型 / 画像维度类型 / 画像维度值

    \b
    可查询指标（2 个，默认全部）：人数占比 / 淘宝闪购用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id）不对外暴露，由后端自动注入。
        画像为“维度类型+维度值”键值对（如性别=男），需用 --filter "画像维度类型=性别" 选定画像维度。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        CROWD_PROFILE_DATASET_ID, CROWD_PROFILE_METRICS, metrics,
        CROWD_PROFILE_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002431 品牌CRM门店人群画像 ---
SHOP_CROWD_PROFILE_DATASET_ID = 10002431
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
# 线上为 EAV 键值对画像表：画像维度类型（如“性别”）+ 画像维度值（如“男”）
SHOP_CROWD_PROFILE_DIMENSIONS = [
    "商户ID", "城市id", "交易类型", "周期类型", "投放人群类型", "画像维度类型", "画像维度值",
]
SHOP_CROWD_PROFILE_METRICS = ["人数占比", "淘宝闪购用户数"]


@data_analysis_cli.command("query-shop-crowd-profile")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部2个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_shop_crowd_profile_cmd(dimensions, filters, date_, metrics,
                                 order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 门店人群画像（dataset 10002431，EAV 键值对画像，单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 7 个，可用 --dimensions 选子集）：
      商户ID / 城市id / 交易类型 / 周期类型 / 投放人群类型 / 画像维度类型 / 画像维度值

    \b
    可查询指标（2 个，默认全部）：人数占比 / 淘宝闪购用户数

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，
        禁止作为查询/分组条件，由后端自动注入。
        画像为“维度类型+维度值”键值对（如性别=男），需用 --filter "画像维度类型=性别" 选定画像维度。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        SHOP_CROWD_PROFILE_DATASET_ID, SHOP_CROWD_PROFILE_METRICS, metrics,
        SHOP_CROWD_PROFILE_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# --- 10002425 品牌CRM品牌粒度同品类商品流向购买（用户流向竞品）---
BRAND_CATEGORY_FLOW_DATASET_ID = 10002425
# 品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入
# 竞品去向品牌ID/竞品流向品牌名称为“流向目标竞品”，是本数据集核心输出维度（非调用方自身品牌），予以保留
BRAND_CATEGORY_FLOW_DIMENSIONS = [
    "城市", "城市id", "是否闪购", "用户类型", "竞品去向品牌ID", "竞品流向品牌名称",
]
BRAND_CATEGORY_FLOW_METRICS = [
    "近30天净交易额", "近30天有效订单数", "近30天购买商品数量", "订单量排行", "top订单量标准菜列表",
]


@data_analysis_cli.command("query-brand-category-flow")
@click.option("--filter", "filters", multiple=True, help="维度筛选，格式 维度名=值1,值2，可重复；维度名须在可分组维度内（queryRule=in）")
@click.option("--date", "date_", type=str, required=False, help="业务日期 yyyyMMdd 单日快照（默认昨天）")
@click.option("--metrics", type=str, required=False, help="需要查询的指标标准名，逗号分隔；默认全部5个")
@click.option("--order-by-field", type=str, required=False, help="排序字段，不传则不排序")
@click.option("--sort-order", type=click.Choice(["asc", "desc"], case_sensitive=False), default="asc", show_default=True, help="排序方向")
@click.option("--page", type=int, default=1, show_default=True, help="页码")
@click.option("--page-size", type=int, default=1000, show_default=True, help="每页条数")
@click.option("--query-count/--no-query-count", default=True, show_default=True, help="是否返回总行数")
@click.option("--dimensions", type=str, required=False, help="需要分组的维度标准名，逗号分隔；默认全部维度")
@handle_error
def query_brand_category_flow_cmd(dimensions, filters, date_, metrics,
                                  order_by_field, sort_order, page, page_size, query_count):
    """查询 CRM 品牌粒度同品类商品流向购买（dataset 10002425，用户流向竞品，近30天口径单日快照）

    注：本命令查询当前登录品牌的数据（品牌隔离由后端自动注入）。

    \b
    可选分组维度（group，默认全部 6 个，可用 --dimensions 选子集）：
      城市 / 城市id / 是否闪购 / 用户类型 / 竞品去向品牌ID / 竞品流向品牌名称

    \b
    可查询指标（5 个，默认全部）：
      近30天净交易额 / 近30天有效订单数 / 近30天购买商品数量 / 订单量排行 / top订单量标准菜列表

    \b
    可用查询条件：--filter（任意可分组维度，格式 维度名=值1,值2） / --date（单日快照，默认昨天） / --dimensions

    \b
    注：品牌隔离字段（crm品牌id/crm品牌名称/品牌id/品牌名称）不对外暴露，由后端自动注入。
        竞品去向品牌ID/竞品流向品牌名称为“流向目标竞品”，是本数据集核心输出维度，予以保留。
    """
    day = date_ or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    _run_semantic_dataset_query(
        BRAND_CATEGORY_FLOW_DATASET_ID, BRAND_CATEGORY_FLOW_METRICS, metrics,
        BRAND_CATEGORY_FLOW_DIMENSIONS, dimensions, filters, [day, day],
        order_by_field, sort_order, page, page_size, query_count,
    )


# === 通用数据集查询命令（固化字段, 封装异步数据查询）END ===


# === KdtDataQueryForClawCliApi.getToday(0) BEGIN ===
@data_analysis_cli.command("get-today")
@handle_error
def get_today_cmd():
    """获取当天日期，格式yyyyMMdd"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.dataanalysis.KdtDataQueryForClawCliApi",
        method_name="getToday",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === KdtDataQueryForClawCliApi.getToday(0) END ===


# === KdtDataQueryForClawCliApi.getYesterday(0) BEGIN ===
@data_analysis_cli.command("get-yesterday")
@handle_error
def get_yesterday_cmd():
    """获取昨天日期，格式yyyyMMdd"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.dataanalysis.KdtDataQueryForClawCliApi",
        method_name="getYesterday",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === KdtDataQueryForClawCliApi.getYesterday(0) END ===
