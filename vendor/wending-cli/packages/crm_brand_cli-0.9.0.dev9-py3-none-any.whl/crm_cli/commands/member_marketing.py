#!/usr/bin/env python3
# ============================================================================
# 本文件基于 @CrmCli 注解自动生成（增量维护，参考 cli-manifest.yaml）
# Module: member-marketing
# 对应 Java 接口: com.alsc.crm.bench.cli.membermarketing.CardTemplateMtopServiceCliApi,
#               com.alsc.crm.bench.cli.membermarketing.VoucherTemplateMTopServiceCliApi
# ============================================================================

from typing import Optional

import click

from crm_base_cli.cli import output, handle_error, parse_optional_request_json
from crm_base_cli.api import CrmAPI


@click.group("member-marketing")
def member_marketing_cli():
    """会员营销模块（member-marketing）。"""
    pass


# === queryMemberCardTemplate(0) BEGIN ===
@member_marketing_cli.command("query-member-card-template")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_member_card_template_cmd(
    request_json: Optional[str],
):
    """查询会员卡模板"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.membermarketing.CardTemplateMtopServiceCliApi",
        method_name="queryMemberCardTemplate",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryMemberCardTemplate(0) END ===


# === updateMemberCardTemplate(1) BEGIN ===
@member_marketing_cli.command("update-member-card-template")
@click.option("--request", "request_json", required=True, help="请求 JSON，需传入 cardTemplateInfo 对象（完整的卡模板信息）")
@handle_error
def update_member_card_template_cmd(
    request_json: Optional[str],
):
    """更新会员卡模板

    通过 --request 传入完整的 JSON 请求体，包含 cardTemplateInfo 字段。
    示例：--request '{"cardTemplateInfo": {...}}'
    """
    api = CrmAPI()

    # 解析 --request JSON
    request = parse_optional_request_json(request_json)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.membermarketing.CardTemplateMtopServiceCliApi",
        method_name="updateMemberCardTemplate",
        method_signature=["com.alsc.crm.bench.cli.membermarketing.request.UpdateMemberCardTemplateCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === updateMemberCardTemplate(1) END ===


# ============================================================================
# Schema 定义 - VoucherTemplateMTopServiceCliApi
# ============================================================================

QUERY_VOUCHER_TEMPLATE_DETAIL_REQUEST_SCHEMA = {
    "name": "QueryVoucherTemplateDetailCliReq",
    "description": "查询券模版详情 CLI 请求",
    "fields": [
        {"name": "templateIdList", "type": "List<String>", "required": True, "description": "券模板ID"},
    ],
}

QUERY_VOUCHER_TEMPLATE_DETAIL_RESPONSE_SCHEMA = {
    "name": "List<SimpleVoucherTemplate4AIMInfo>",
    "description": "券模版详情响应",
    "fields": [
        {"name": "templateId", "type": "String", "required": False, "description": "券模版Id"},
        {"name": "content", "type": "String", "required": False, "description": "券内容"},
        {"name": "benefitType", "type": "String", "required": False, "description": "券类型枚举"},
        {"name": "benefitTypeDesc", "type": "String", "required": False, "description": "券类型描述"},
        {"name": "inventory", "type": "Integer", "required": False, "description": "库存"},
        {"name": "validTimeDesc", "type": "String", "required": False, "description": "券有效期描述"},
    ],
}

QUERY_VOUCHER_TEMPLATE_LIST_REQUEST_SCHEMA = {
    "name": "QueryVoucherTemplateListCliReq",
    "description": "查询券模版列表 CLI 请求",
    "fields": [
        {"name": "pageNo", "type": "Integer", "required": True, "description": "页码"},
        {"name": "pageSize", "type": "Integer", "required": True, "description": "每页条数"},
    ],
}

QUERY_VOUCHER_TEMPLATE_LIST_RESPONSE_SCHEMA = {
    "name": "PageResponse<List<SimpleVoucherTemplate4AIMInfo>>",
    "description": "券模版列表分页响应",
    "fields": [
        {"name": "templateId", "type": "String", "required": False, "description": "券模版Id"},
        {"name": "content", "type": "String", "required": False, "description": "券内容"},
        {"name": "benefitType", "type": "String", "required": False, "description": "券类型枚举"},
        {"name": "benefitTypeDesc", "type": "String", "required": False, "description": "券类型描述"},
        {"name": "inventory", "type": "Integer", "required": False, "description": "库存"},
        {"name": "validTimeDesc", "type": "String", "required": False, "description": "券有效期描述"},
    ],
}


# ============================================================================
# query-voucher-template-detail - 根据券模板ID查询详情
# ============================================================================

# === queryDetailById(1) BEGIN ===
@member_marketing_cli.command("query-voucher-template-detail")
@click.option(
    "--template-id-list",
    type=str,
    required=False,
    help="券模板ID（JSON数组，如 [\"id1\",\"id2\"]）",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_voucher_template_detail_cmd(
    template_id_list: Optional[str],
    request_json: Optional[str],
):
    """根据券模板ID查询详情"""
    import json
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if template_id_list is not None:
        request["templateIdList"] = json.loads(template_id_list)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.membermarketing.VoucherTemplateMTopServiceCliApi",
        method_name="queryDetailById",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryVoucherTemplateDetailCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryDetailById(1) END ===


# ============================================================================
# query-voucher-template-list - 查询券模版列表
# ============================================================================

# === queryList(1) BEGIN ===
@member_marketing_cli.command("query-voucher-template-list")
@click.option(
    "--page-no",
    type=int,
    required=False,
    help="页码",
)
@click.option(
    "--page-size",
    type=int,
    required=False,
    help="每页条数",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_voucher_template_list_cmd(
    page_no: Optional[int],
    page_size: Optional[int],
    request_json: Optional[str],
):
    """查询券模版列表"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if page_no is not None:
        request["pageNo"] = page_no
    if page_size is not None:
        request["pageSize"] = page_size

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.membermarketing.VoucherTemplateMTopServiceCliApi",
        method_name="queryList",
        method_signature=["com.alsc.crm.bench.cli.precisemarketing.request.QueryVoucherTemplateListCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryList(1) END ===
