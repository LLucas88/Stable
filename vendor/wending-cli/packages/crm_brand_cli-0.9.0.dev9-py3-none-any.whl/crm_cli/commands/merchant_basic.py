#!/usr/bin/env python3
# ============================================================================
# 本文件基于 @CrmCli 注解自动生成（增量维护，参考 cli-manifest.yaml）
# Module: merchant-basic
# 涉及 Java 接口（多接口聚合）：
#   - com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw
#   - com.alsc.crm.bench.mtop.gongyu.auth.AuthMtopService
#   - com.alsc.crm.bench.mtop.dataopt.PrecisionDataBroadMtopApi
#   - com.alsc.crm.bench.mtop.gongyu.marketing.service.activity.PublicActivityMtopService
#   - com.alsc.crm.bench.mtop.gongyu.homepage.service.HomePageMtopApi
#   - com.alsc.crm.bench.mtop.orgpublic.NewStoreBindMtopService
#   - com.alsc.crm.bench.cli.merchantbasic.OrganizationStoreTreeMtopServiceCliApi
#   - com.alsc.crm.bench.cli.merchantbasic.CrmAgentMtopServiceCliApi
# ============================================================================

from typing import Optional

import click

from crm_base_cli.cli import output, handle_error, parse_optional_request_json
from crm_base_cli.api import CrmAPI


@click.group("merchant-basic")
def merchant_basic_cli():
    """商家基础模块（merchant-basic）。"""
    pass


# === commitStoreBindTask(1) BEGIN ===
@merchant_basic_cli.command("commit-store-bind-task")
@click.option(
    "--ele-shop-ids",
    type=str,
    required=False,
    help="签约的饿了么门店id（JSON 数组，如 [\"123\",\"456\"]）",
)
@click.option(
    "--contact-no",
    type=str,
    required=False,
    help="合约号",
)
@click.option(
    "--biz-type",
    type=click.Choice(["BIND_TASK", "UN_BIND_TASK"], case_sensitive=False),
    required=False,
    help="业务类型: BIND_TASK(批量签约任务), UN_BIND_TASK(批量解约任务)",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def commit_store_bind_task_cmd(
    ele_shop_ids: Optional[str],
    contact_no: Optional[str],
    biz_type: Optional[str],
    request_json: Optional[str],
):
    """提交签约/解约任务"""
    import json
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if ele_shop_ids is not None:
        request["eleShopIds"] = json.loads(ele_shop_ids)
    if contact_no is not None:
        request["contactNo"] = contact_no
    if biz_type is not None:
        request["bizType"] = biz_type

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw",
        method_name="commitStoreBindTask",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.sign.request.StoreSignTaskRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === commitStoreBindTask(1) END ===


# === queryTaskDetail(1) BEGIN ===
@merchant_basic_cli.command("query-task-detail")
@click.option(
    "--parent-task-no",
    type=str,
    required=False,
    help="父任务",
)
@click.option(
    "--task-no",
    type=str,
    required=False,
    help="子任务",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_task_detail_cmd(
    parent_task_no: Optional[str],
    task_no: Optional[str],
    request_json: Optional[str],
):
    """查询任务详情"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if parent_task_no is not None:
        request["parentTaskNo"] = parent_task_no
    if task_no is not None:
        request["taskNo"] = task_no

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw",
        method_name="queryTaskDetail",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.sign.request.StoreSignTaskQueryRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === queryTaskDetail(1) END ===


# === retryTask(1) BEGIN ===
@merchant_basic_cli.command("retry-task")
@click.option(
    "--parent-task-no",
    type=str,
    required=False,
    help="父任务",
)
@click.option(
    "--task-no",
    type=str,
    required=False,
    help="子任务",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def retry_task_cmd(
    parent_task_no: Optional[str],
    task_no: Optional[str],
    request_json: Optional[str],
):
    """重试任务"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if parent_task_no is not None:
        request["parentTaskNo"] = parent_task_no
    if task_no is not None:
        request["taskNo"] = task_no

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw",
        method_name="retryTask",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.sign.request.StoreSignTaskQueryRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === retryTask(1) END ===


# === exportOutStoreTree(1) BEGIN ===
@merchant_basic_cli.command("export-out-store-tree")
@click.option(
    "--down-type",
    type=click.Choice(["SIGN_STORE", "UNSIGN_STORE"], case_sensitive=False),
    required=False,
    help="导出类型: SIGN_STORE(签约门店), UNSIGN_STORE(未签约门店)",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def export_out_store_tree_cmd(
    down_type: Optional[str],
    request_json: Optional[str],
):
    """异步导出签约/未签约门店"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的参数覆盖 JSON 中的同名字段
    if down_type is not None:
        request["downType"] = down_type

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw",
        method_name="exportOutStoreTree",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.sign.request.ExportStoreRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === exportOutStoreTree(1) END ===


# === checkFunctionCodes(1) BEGIN ===
@merchant_basic_cli.command("check-function-codes")
@click.option(
    "--codes",
    type=str,
    required=False,
    help="功能码列表，多个用逗号分隔（如 code1,code2）",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def check_function_codes_cmd(
    codes: Optional[str],
    request_json: Optional[str],
):
    """功能码鉴权

    通过 --codes 传入逗号分隔的功能码，或通过 --request 传入 JSON。
    """
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的 --codes 覆盖 JSON 中的 functionCodes 字段
    if codes is not None:
        request["functionCodes"] = [c.strip() for c in codes.split(",") if c.strip()]

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.auth.AuthMtopService",
        method_name="checkFunctionCodes",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.auth.request.FunctionRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === checkFunctionCodes(1) END ===


# === checkPermissions(1) BEGIN ===
@merchant_basic_cli.command("check-permission-codes")
@click.option(
    "--codes",
    type=str,
    required=False,
    help="权限码列表，多个用逗号分隔（如 code1,code2）",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def check_permission_codes_cmd(
    codes: Optional[str],
    request_json: Optional[str],
):
    """权限码鉴权

    通过 --codes 传入逗号分隔的权限码，或通过 --request 传入 JSON。
    """
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    # 单独传入的 --codes 覆盖 JSON 中的 permissionCodes 字段
    if codes is not None:
        request["permissionCodes"] = [c.strip() for c in codes.split(",") if c.strip()]

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.auth.AuthMtopService",
        method_name="checkPermissions",
        method_signature=["com.alsc.crm.bench.mtop.gongyu.auth.request.PermissionRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === checkPermissions(1) END ===


# === PrecisionDataBroadMtopApi.getAsyncQueryResult(1) BEGIN ===
# 注意：本 module 下 getAsyncQueryResult 来自两个不同接口，锚点带 interface 简短名以区分
@merchant_basic_cli.command("get-async-query-result-dataopt")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def get_async_query_result_dataopt_cmd(
    request_json: Optional[str],
):
    """获取异步任务结果"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.dataopt.PrecisionDataBroadMtopApi",
        method_name="getAsyncQueryResult",
        method_signature=["com.alsc.saas.crm.pub.dataopt.client.request.GetAsyncQueryResultRequest"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === PrecisionDataBroadMtopApi.getAsyncQueryResult(1) END ===


# === downloadBindStoreData(0) BEGIN ===
@merchant_basic_cli.command("download-bind-store-data")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def download_bind_store_data_cmd(
    request_json: Optional[str],
):
    """门店绑签数据下载"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.dataopt.PrecisionDataBroadMtopApi",
        method_name="downloadBindStoreData",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === downloadBindStoreData(0) END ===


# === queryActivityShopCheckInfo(0) BEGIN ===
@merchant_basic_cli.command("query-activity-shop-check-info")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_activity_shop_check_info_cmd(
    request_json: Optional[str],
):
    """门店巡检"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.marketing.service.activity.PublicActivityMtopService",
        method_name="queryActivityShopCheckInfo",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryActivityShopCheckInfo(0) END ===


# === queryStoreSummary(0) BEGIN ===
@merchant_basic_cli.command("query-store-summary")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_store_summary_cmd(
    request_json: Optional[str],
):
    """查询门店覆盖情况"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.homepage.service.HomePageMtopApi",
        method_name="queryStoreSummary",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryStoreSummary(0) END ===


# === queryEffectContractWithShopSignSelect(0) BEGIN ===
@merchant_basic_cli.command("query-effect-contract-with-shop-sign-select")
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def query_effect_contract_with_shop_sign_select_cmd(
    request_json: Optional[str],
):
    """查询有效公域合约列表，并附带是否可签约"""
    api = CrmAPI()

    # 解析 --request JSON，如果有的话
    request = parse_optional_request_json(request_json)

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.orgpublic.NewStoreBindMtopService",
        method_name="queryEffectContractWithShopSignSelect",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryEffectContractWithShopSignSelect(0) END ===


# === queryStoreBindSignSummary(0) BEGIN ===
QUERY_STORE_BIND_SIGN_SUMMARY_REQUEST_SCHEMA = {
    "name": "None",
    "description": "无请求参数",
    "fields": [],
}

QUERY_STORE_BIND_SIGN_SUMMARY_RESPONSE_SCHEMA = {
    "name": "StoreBindSignSummaryVO",
    "description": "门店绑签概要",
    "fields": [
        {"name": "purchaseQty", "type": "Integer", "required": False, "description": "购买门店数"},
        {"name": "signedQty", "type": "Integer", "required": False, "description": "已签约门店数"},
        {"name": "signedRatio", "type": "String", "required": False, "description": "门店签约率"},
        {"name": "cardCfgQty", "type": "Integer", "required": False, "description": "会员卡配置门店数"},
        {"name": "cardCfgRatio", "type": "String", "required": False, "description": "会员卡门店覆盖率"},
    ],
}


@merchant_basic_cli.command("query-store-bind-sign-summary")
@handle_error
def query_store_bind_sign_summary_cmd():
    """门店绑签概要"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw",
        method_name="queryStoreBindSignSummary",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === queryStoreBindSignSummary(0) END ===


# === exportStoreBind(0) BEGIN ===
EXPORT_STORE_BIND_REQUEST_SCHEMA = {
    "name": "None",
    "description": "无请求参数",
    "fields": [],
}

EXPORT_STORE_BIND_RESPONSE_SCHEMA = {
    "name": "AsyncTaskSubmitResultDTO",
    "description": "异步任务提交结果（外部依赖类型，字段未解析）",
    "fields": [],
}


@merchant_basic_cli.command("export-store-bind")
@handle_error
def export_store_bind_cmd():
    """导出所有绑定门店"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.mtop.gongyu.sign.CrmSignForClaw",
        method_name="exportStoreBind",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === exportStoreBind(0) END ===


# === OrganizationStoreTreeMtopServiceCliApi.newAsyncQueryOutStoreTree(1) BEGIN ===
@merchant_basic_cli.command("new-async-query-out-store-tree")
@click.option(
    "--biz-channel",
    type=str,
    required=False,
    help="外部渠道: SPECIAL_DISH, MEMEBER_DAY_DISH, DISH_VOUCHER, MEMBER_CARD, MEMBER_GIFT, MEMBER_DAY, PAYMENT_TIMES, PAYMENT_TOTAL, ELE_DELIVERY_VOUCHER, ELE_PAY_SCENE_VOUCHER, SAAS_REPORT, CITY_STORE_TREE",
)
@click.option(
    "--available-shop-ids",
    type=str,
    required=False,
    help="可用门店ID列表（逗号分隔，如 123,456）",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def new_async_query_out_store_tree_cmd(
    biz_channel: Optional[str],
    available_shop_ids: Optional[str],
    request_json: Optional[str],
):
    """新-异步批量查询外部门店，返回异步任务提交结果"""
    api = CrmAPI()

    request = parse_optional_request_json(request_json)

    if biz_channel is not None:
        request["bizChannel"] = biz_channel
    if available_shop_ids is not None:
        request["availableShopIds"] = [s.strip() for s in available_shop_ids.split(",") if s.strip()]

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.merchantbasic.OrganizationStoreTreeMtopServiceCliApi",
        method_name="newAsyncQueryOutStoreTree",
        method_signature=["com.alsc.crm.bench.cli.merchantbasic.request.NewAsyncQueryOutStoreTreeCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === OrganizationStoreTreeMtopServiceCliApi.newAsyncQueryOutStoreTree(1) END ===


# === OrganizationStoreTreeMtopServiceCliApi.getAsyncQueryResult(1) BEGIN ===
@merchant_basic_cli.command("get-async-query-result")
@click.option(
    "--scene-code",
    type=str,
    required=False,
    help="场景编码",
)
@click.option(
    "--scene-id",
    type=str,
    required=False,
    help="场景ID",
)
@click.option("--request", "request_json", required=False, help="请求 JSON（单独传入的参数会覆盖 JSON 中的同名字段）")
@handle_error
def get_async_query_result_cmd(
    scene_code: Optional[str],
    scene_id: Optional[str],
    request_json: Optional[str],
):
    """根据sceneCode和sceneId获取异步查询结果"""
    api = CrmAPI()

    request = parse_optional_request_json(request_json)

    if scene_code is not None:
        request["sceneCode"] = scene_code
    if scene_id is not None:
        request["sceneId"] = scene_id

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.merchantbasic.OrganizationStoreTreeMtopServiceCliApi",
        method_name="getAsyncQueryResult",
        method_signature=["com.alsc.crm.bench.cli.merchantbasic.request.GetAsyncQueryResultCliReq"],
        args=[request],
        require_auth=True,
    )
    output(result)
# === OrganizationStoreTreeMtopServiceCliApi.getAsyncQueryResult(1) END ===


# === CrmAgentMtopServiceCliApi.queryAgentBrands(0) BEGIN ===
QUERY_AGENT_BRANDS_REQUEST_SCHEMA = {
    "name": "None",
    "description": "无请求参数",
    "fields": [],
}

QUERY_AGENT_BRANDS_RESPONSE_SCHEMA = {
    "name": "List<BrandDTO>",
    "description": "当前（xy）登录人可管理的品牌列表",
    "fields": [
        {"name": "brandId", "type": "Long", "required": False, "description": "品牌ID"},
        {"name": "brandName", "type": "String", "required": False, "description": "品牌名称"},
    ],
}


@merchant_basic_cli.command("query-agent-brands")
@handle_error
def query_agent_brands_cmd():
    """获取当前（xy）登录人可管理的品牌列表"""
    api = CrmAPI()

    result = api._hsf_request(
        interface_name="com.alsc.crm.bench.cli.merchantbasic.CrmAgentMtopServiceCliApi",
        method_name="queryAgentBrands",
        method_signature=[],
        args=[],
        require_auth=True,
    )
    output(result)
# === CrmAgentMtopServiceCliApi.queryAgentBrands(0) END ===
