#!/usr/bin/env python3
"""CRM CLI — 基于 @CrmCli 注解自动生成的命令行工具"""

import click
from importlib.metadata import version as get_version

from crm_base_cli.cli import output, handle_error, parse_request_json, parse_optional_request_json, get_open_api
from crm_base_cli.cli import third_cli
from crm_base_cli.api import CrmAPI

# 导入各 module 命令组
from crm_cli.commands.data_analysis import data_analysis_cli
from crm_cli.commands.member_marketing import member_marketing_cli
from crm_cli.commands.merchant_basic import merchant_basic_cli
from crm_cli.commands.shop_deco import shop_deco_cli
from crm_cli.commands.precise_marketing import precise_marketing_cli


@click.group()
@click.version_option(version=get_version("crm-brand-cli"), prog_name="crm-brand-cli")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def cli(json_mode):
    """CRM CLI - 业务模块命令行工具（含三方登录 + 业务命令）"""
    from crm_base_cli import cli as base_cli
    base_cli._json_output = json_mode


# 注册各 module 命令组
cli.add_command(merchant_basic_cli)
cli.add_command(member_marketing_cli)
cli.add_command(data_analysis_cli)
cli.add_command(shop_deco_cli)
cli.add_command(precise_marketing_cli)
cli.add_command(third_cli)


if __name__ == "__main__":
    cli()
