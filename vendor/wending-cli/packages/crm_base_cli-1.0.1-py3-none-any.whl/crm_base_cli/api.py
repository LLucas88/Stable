"""CRM API client.

包含:
- 三方登录 (xtop 协议): 临时授权码、验证码、账号验证、授权
- 业务查询 (HSF 协议): 登录记录、品牌列表、切换品牌
"""

import json
import base64
import hashlib

from crm_base_cli.api_base import NaposAPIBase


class CrmAPI(NaposAPIBase):
    """CRM 平台 API 客户端。"""

    THIRD_LOGIN_BASE_URL = "https://ppe-app-api.shop.ele.me"

    THIRD_LOGIN_AUTH_SOURCES = {
        "0": 0,
        "1": 1,
    }

    def __init__(self, wnToken: str = None, require_auth: bool = True):
        super().__init__(wnToken)
        from crm_base_cli import config as config_mod
        self._load_config_if_needed(config_mod, require_auth=require_auth)

    # =========================================================================
    # 三方登录 - 内部方法
    # =========================================================================

    def _third_login_auth_source(self, channel: str) -> int:
        """将 channel 参数转换为 authSource 数值并校验合法性。"""
        normalized_channel = str(channel).strip()
        if normalized_channel not in self.THIRD_LOGIN_AUTH_SOURCES:
            raise ValueError(f"不支持的 channel: {channel}，当前支持 0（悟空）、1（云claw）")
        return self.THIRD_LOGIN_AUTH_SOURCES[normalized_channel]

    def _third_login_pkce_challenge(self, code_verifier: str) -> str:
        """根据 code_verifier 生成 PKCE code_challenge (SHA256 + Base64URL)。"""
        digest = hashlib.sha256(code_verifier.encode("utf-8")).digest()
        return base64.urlsafe_b64encode(digest).decode("utf-8").rstrip("=")

    def _third_login_resolve_ext_info(self, request: dict) -> str:
        """解析或构建 extInfo JSON 字符串（包含 userAgent、WDID 等）。"""
        ext_info = request.get("extInfo")
        if isinstance(ext_info, dict):
            ext_info = json.dumps(ext_info, ensure_ascii=False)
        if ext_info:
            return ext_info
        ext_info_dict = {
            "userAgent": request.get("userAgent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"),
        }
        wdid = request.get("wdid")
        if wdid:
            ext_info_dict["WDID"] = str(wdid)
        return json.dumps(ext_info_dict, ensure_ascii=False)

    # =========================================================================
    # 三方登录 - xtop 协议接口
    # =========================================================================

    def third_login_gen_temp_auth(self, channel: str, request: dict) -> dict:
        """生成临时授权码 (PKCE 流程第一步)。

        Args:
            channel: 渠道(authSource)
            request: 请求参数，必须包含 codeVerifier

        Returns:
            包含 authTempCode 的字典
        """
        code_verifier = request.get("codeVerifier")
        if not code_verifier:
            raise ValueError("request.codeVerifier 不能为空")
        auth_source = self._third_login_auth_source(channel)
        ext_info = self._third_login_resolve_ext_info(request)

        body = {
            "metas": {"ksid": "", "appName": "melody"},
            "params": {
                "request": {
                    "authSource": auth_source,
                    "codeChallenge": self._third_login_pkce_challenge(code_verifier),
                    "codeEncryption": request.get("codeEncryption", "S256"),
                    "extInfo": ext_info,
                }
            },
        }
        return self._xtop_request(
            f"{self.THIRD_LOGIN_BASE_URL}/xtop/xtop.isv.center.largeModelAuth.generateTempAuthCode/1.0",
            body=body,
            require_auth=False,
        )

    def third_login_send_verify_code(self, channel: str, mobile: str, is_by_voice: bool = False) -> dict:
        """发送短信验证码。

        Args:
            channel: 渠道(authSource)
            mobile: 手机号
            is_by_voice: 是否语音验证码

        Returns:
            包含 token 的字典
        """
        if not mobile:
            raise ValueError("mobile 不能为空")
        self._third_login_auth_source(channel)
        return self._xtop_request(
            f"{self.THIRD_LOGIN_BASE_URL}/xtop/xtop.napos.keeper.melody.wukong.sendVerifyCode/1.0",
            body={
                "metas": {
                    "appName": "Universal-Auth",
                    "appVersion": "1.0.0",
                },
                "params": {
                    "request": {
                        "mobile": mobile,
                        "isByVoice": is_by_voice,
                        "type":"1"
                    }
                },
            },
            require_auth=False,
        )

    def third_login_verify_code(self, channel: str, request: dict) -> dict:
        """验证短信并查询账号列表。

        Args:
            channel: 渠道(authSource)
            request: 请求参数，必须包含 authOpenRequest

        Returns:
            账号列表信息字典
        """
        if not isinstance(request, dict):
            raise ValueError("request 必须是对象")
        auth_source = self._third_login_auth_source(channel)
        auth_open_request = request.get("authOpenRequest")
        if not isinstance(auth_open_request, dict):
            raise ValueError("request.authOpenRequest 必须是对象")
        request = dict(request)
        auth_open_request = dict(auth_open_request)
        auth_open_request["authSource"] = str(auth_source)
        request["authOpenRequest"] = auth_open_request
        return self._xtop_request(
            f"{self.THIRD_LOGIN_BASE_URL}/xtop/xtop.napos.keeper.melody.wukong.verifyMobileAndQueryAccounts/1.0",
            body={
                "metas": {
                    "appName": "Universal-Auth",
                    "appVersion": "1.0.0",
                },
                "params": {
                    "request": request,
                },
            },
            require_auth=False,
        )

    def third_login_auth(self, channel: str, request: dict) -> dict:
        """最终授权，获取 authCode/wnToken。

        Args:
            channel: 渠道(authSource)
            request: 授权请求参数

        Returns:
            包含 authCode/wnToken 的字典
        """
        if not isinstance(request, dict):
            raise ValueError("request 必须是对象")
        self._third_login_auth_source(channel)
        return self._xtop_request(
            f"{self.THIRD_LOGIN_BASE_URL}/xtop/xtop.isv.center.largeModelAuth.generateAuthCode/1.0",
            body={
                "metas": {
                    "appName": "Universal-Auth",
                    "appVersion": "1.0.0",
                },
                "params": {
                    "request": request,
                },
            },
            require_auth=False,
        )

    # =========================================================================
    # 业务查询 - HSF 协议接口
    # =========================================================================

    def third_login_login_record(self, channel: str, request: dict = None) -> dict:
        """查询账号最近的登录记录。

        Args:
            channel: 渠道(authSource)
            request: 可选的请求参数

        Returns:
            登录记录信息字典
        """
        if request is None:
            request = {}
        self._third_login_auth_source(channel)
        return self._hsf_request(
            interface_name="com.alsc.crm.bench.api.org.CrmOrganizationReadService",
            method_name="getLoginRecord",
            method_signature=[],
            args=[],
            require_auth=True,
        )

    def third_login_query_brand_list(self, channel: str, request: dict = None) -> dict:
        """查询品牌列表。

        Args:
            channel: 渠道(authSource)
            request: 可选的请求参数

        Returns:
            品牌列表信息字典
        """
        if request is None:
            request = {}
        self._third_login_auth_source(channel)
        return self._hsf_request(
            interface_name="com.alsc.crm.bench.api.org.CrmOrganizationReadService",
            method_name="queryBrandNodes",
            method_signature=[],
            args=[],
            require_auth=True,
        )

    def third_login_switch_brand(self, channel: str, brandId: str) -> dict:
        """切换品牌。

        Args:
            channel: 渠道(authSource)
            brandId: 品牌/组织 ID

        Returns:
            切换结果字典
        """
        self._third_login_auth_source(channel)
        return self._hsf_request(
            interface_name="com.alsc.crm.bench.api.org.CrmOrganizationReadService",
            method_name="switchOrganization",
            method_signature=["java.lang.Long"],
            args=[int(brandId)],
            require_auth=True,
        )
