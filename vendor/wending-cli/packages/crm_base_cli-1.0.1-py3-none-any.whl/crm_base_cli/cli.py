#!/usr/bin/env python3
"""CRM CLI — 三方登录命令行工具

Usage:
    # 三方登录
    crm-base-cli third login gen-temp-auth --channel 0
    crm-base-cli third login send-verify-code --channel 0 --mobile 13800138000
    crm-base-cli third login verify-code --channel 0 --request '{...}'
    crm-base-cli third login auth --channel 0 --request '{...}'
    crm-base-cli third login login-record --channel 0
    crm-base-cli third login list-brand --channel 0
    crm-base-cli third login switch-brand --channel 0 --brand-id 1203473
    crm-base-cli third login logout
"""

import sys
import json
import secrets
import click
from typing import Optional
from importlib.metadata import version as get_version

from crm_base_cli.api import CrmAPI
from crm_base_cli import config as config_mod

_json_output = False


def get_open_api() -> CrmAPI:
    """Get unauthenticated API client."""
    return CrmAPI(require_auth=False)


def parse_request_json(request_json: str) -> dict:
    """Parse request JSON string into dict."""
    try:
        request = json.loads(request_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"--request 不是合法 JSON: {e}")
    if not isinstance(request, dict):
        raise ValueError("--request 必须是 JSON 对象")
    return request


def parse_optional_request_json(request_json: Optional[str]) -> dict:
    """Parse optional request JSON string into dict."""
    if request_json is None or request_json == "":
        return {}
    return parse_request_json(request_json)


# ============================================================================
# Third login helper functions
# ============================================================================

def _generate_third_login_code_verifier(length: int = 128) -> str:
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _get_third_login_context() -> dict:
    return config_mod.get_third_login_context()


def _update_third_login_context(context: dict):
    config_mod.update_third_login_context(context)


def _require_third_login_context(*fields: str) -> dict:
    context = _get_third_login_context()
    missing = [field for field in fields if not context.get(field)]
    if missing:
        missing_text = ", ".join(missing)
        raise RuntimeError(f"缺少三方登录上下文: {missing_text}，请先执行: crm-base-cli third login gen-temp-auth")
    return context


def _resolve_third_login_ext_info(request: dict, context: dict) -> Optional[str]:
    ext_info = request.get("extInfo")
    if ext_info is None:
        ext_info = context.get("extInfo")
    if isinstance(ext_info, dict):
        return json.dumps(ext_info, ensure_ascii=False)
    return ext_info


def _build_third_login_auth_open_request(request: dict, context: dict) -> dict:
    auth_open_request = request.get("authOpenRequest")
    if auth_open_request is None:
        auth_open_request = {}
    if not isinstance(auth_open_request, dict):
        raise ValueError("request.authOpenRequest 必须是对象")
    auth_open_request = dict(auth_open_request)
    auth_open_request.setdefault("type", "1")
    auth_open_request.setdefault("authTempCode", context["authTempCode"])
    auth_open_request.setdefault("codeVerifier", context["codeVerifier"])
    ext_info = _resolve_third_login_ext_info(auth_open_request, context)
    if ext_info:
        auth_open_request["extInfo"] = ext_info
    return auth_open_request


def _extract_third_login_auth_token(result: dict) -> Optional[str]:
    auth_token = result.get("authToken") or result.get("authCode")
    if auth_token:
        return auth_token

    for session_key in ("eleSessionInfo", "retailSessionInfo"):
        session_info = result.get(session_key)
        if not isinstance(session_info, dict):
            continue
        auth_token = session_info.get("wnToken") or session_info.get("authToken") or session_info.get("authCode")
        if auth_token:
            return auth_token
    return None


def _resolve_third_login_account_type(request: dict, context: dict) -> int:
    if "accountType" in request:
        return request["accountType"]

    selected_channel = context.get("selectedChannel")
    channel_to_account_type = {
        1: 0, "1": 0,
        2: 1, "2": 1,
    }
    if selected_channel in channel_to_account_type:
        return channel_to_account_type[selected_channel]
    return 0


def _run_third_login_auth(api: CrmAPI, channel: str, request: dict, context: dict) -> dict:
    request = dict(request)
    request.setdefault("authType", "登录授权")
    request.setdefault("authTempCode", context["authTempCode"])
    request.setdefault("codeVerifier", context["codeVerifier"])
    request.setdefault("accountType", _resolve_third_login_account_type(request, context))
    ext_info = _resolve_third_login_ext_info(request, context)
    if ext_info:
        request["extInfo"] = ext_info
    result = api.third_login_auth(channel=channel, request=request)
    auth_token = _extract_third_login_auth_token(result)
    if not auth_token:
        raise RuntimeError("三方登录授权成功但未返回 authToken/authCode")
    # 保存 wnToken 到本地配置
    config_mod.set_auth(auth_data={"wnToken": auth_token})
    result = dict(result)
    result["wnToken"] = auth_token
    return result


def _handle_third_login_verify_result(request: dict, result: dict, context: dict) -> dict:
    account_list = result.get("accountList") or []
    updated_context = {
        "token": result.get("token") or request.get("token") or context.get("token"),
        "accountList": account_list,
        "selectedAccountId": None,
        "selectedChannel": None,
    }

    if len(account_list) <= 1:
        if account_list:
            updated_context["selectedAccountId"] = account_list[0].get("accountId")
            updated_context["selectedChannel"] = account_list[0].get("channel")
        _update_third_login_context(updated_context)
        return result

    _update_third_login_context(updated_context)
    return result


# ============================================================================
# Output helpers
# ============================================================================

def output(data, message: str = ""):
    """Output result data."""
    if _json_output:
        click.echo(json.dumps(data, indent=2, ensure_ascii=False, default=str))
    else:
        if message:
            click.echo(message)
        if data is None:
            return
        if isinstance(data, dict):
            _print_dict(data)
        elif isinstance(data, list):
            _print_list(data)
        else:
            click.echo(str(data))


def _print_dict(d: dict, indent: int = 0):
    prefix = "  " * indent
    for k, v in d.items():
        if isinstance(v, dict):
            click.echo(f"{prefix}{k}:")
            _print_dict(v, indent + 1)
        elif isinstance(v, list):
            if len(v) > 10:
                click.echo(f"{prefix}{k}: [{len(v)} items]")
            else:
                click.echo(f"{prefix}{k}:")
                _print_list(v, indent + 1)
        else:
            click.echo(f"{prefix}{k}: {v}")


def _print_list(items: list, indent: int = 0):
    prefix = "  " * indent
    for i, item in enumerate(items):
        if isinstance(item, dict):
            click.echo(f"{prefix}[{i}]")
            _print_dict(item, indent + 1)
        else:
            click.echo(f"{prefix}- {item}")


def handle_error(func):
    """Decorator to handle errors consistently."""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (ValueError, RuntimeError) as e:
            if _json_output:
                click.echo(json.dumps({"error": str(e)}, ensure_ascii=False))
            else:
                click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        except Exception as e:
            if _json_output:
                click.echo(json.dumps({"error": str(e)}, ensure_ascii=False))
            else:
                click.echo(f"Unexpected error: {e}", err=True)
            sys.exit(1)
    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper


# ============================================================================
# Main CLI group
# ============================================================================

@click.group()
@click.version_option(version=get_version("crm-base-cli"), prog_name="crm-base-cli")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def cli(json_mode):
    """CRM CLI 基础模块 - 三方登录"""
    global _json_output
    _json_output = json_mode


# ============================================================================
# Third login commands (三方登录)
# ============================================================================

@cli.group("third")
def third_cli():
    """三方能力。"""
    pass


@third_cli.group("login")
def third_login_cli():
    """三方登录能力。"""
    pass


@third_login_cli.command("gen-temp-auth")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--request", "request_json", required=False, help="请求 JSON")
@handle_error
def third_login_gen_temp_auth_cmd(channel: str, request_json: Optional[str]):
    """三方登录-临时授权码。"""
    api = get_open_api()
    request = parse_optional_request_json(request_json)
    code_verifier = _generate_third_login_code_verifier()
    request["codeVerifier"] = code_verifier
    result = api.third_login_gen_temp_auth(channel=channel, request=request)
    ext_info = api._third_login_resolve_ext_info(request)
    stored_context = {
        "channel": channel,
        "codeVerifier": code_verifier,
        "authTempCode": result.get("authTempCode"),
        "wdid": request.get("wdid"),
        "extInfo": ext_info,
        "token": None,
        "mobile": None,
    }
    _update_third_login_context(stored_context)
    output(result)


@third_login_cli.command("send-verify-code")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--mobile", required=True, help="手机号")
@handle_error
def third_login_send_verify_code_cmd(channel: str, mobile: str):
    """三方登录-发送验证码。"""
    api = get_open_api()
    result = api.third_login_send_verify_code(channel=channel, mobile=mobile)
    _update_third_login_context({
        "channel": channel,
        "mobile": mobile,
        "token": result.get("token"),
    })
    output(result)


@third_login_cli.command("verify-code")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--request", "request_json", required=True, help="请求 JSON")
@handle_error
def third_login_verify_code_cmd(channel: str, request_json: str):
    """三方登录-验证码。"""
    api = get_open_api()
    context = _require_third_login_context("codeVerifier", "authTempCode")
    request = parse_request_json(request_json)
    request.setdefault("token", context.get("token"))
    if not request.get("token"):
        raise RuntimeError("缺少短信校验 token，请先执行: crm-base-cli third login send-verify-code")
    request["authOpenRequest"] = _build_third_login_auth_open_request(request, context)
    result = api.third_login_verify_code(channel=channel, request=request)
    result = _handle_third_login_verify_result(request=request, result=result, context=context)
    output(result)


@third_login_cli.command("auth")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--request", "request_json", required=True, help="请求 JSON")
@handle_error
def third_login_auth_cmd(channel: str, request_json: str):
    """三方登录-授权。"""
    api = get_open_api()
    context = _require_third_login_context("codeVerifier", "authTempCode")
    request = parse_request_json(request_json)
    result = _run_third_login_auth(api=api, channel=channel, request=request, context=context)
    output(result)


@third_login_cli.command("login-record")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--request", "request_json", required=False, help="请求 JSON")
@handle_error
def third_login_login_record_cmd(channel: str, request_json: Optional[str]):
    """三方登录-查询登录记录。"""
    api = get_open_api()
    request = parse_optional_request_json(request_json)
    result = api.third_login_login_record(channel=channel, request=request)
    output(result)


@third_login_cli.command("list-brand")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--request", "request_json", required=False, help="请求 JSON")
@handle_error
def third_login_query_brand_list_cmd(channel: str, request_json: Optional[str]):
    """三方登录-查询品牌列表。"""
    api = get_open_api()
    request = parse_optional_request_json(request_json)
    result = api.third_login_query_brand_list(channel=channel, request=request)
    output(result)


@third_login_cli.command("switch-brand")
@click.option("--channel", type=click.Choice(["0", "1"], case_sensitive=False), required=True, help="渠道(authSource): 0=悟空, 1=云claw")
@click.option("--brand-id", required=True, help="品牌 ID")
@handle_error
def third_login_switch_brand_cmd(channel: str, brand_id: str):
    """三方登录-切换品牌。"""
    api = get_open_api()
    result = api.third_login_switch_brand(channel=channel, brandId=brand_id)
    output(result)


@third_login_cli.command("logout")
@handle_error
def third_login_logout_cmd():
    """三方登录-退出登录，清理本地所有授权信息。"""
    config_mod.clear_config()
    output({"success": True}, message="已退出登录，本地配置已清空")


if __name__ == "__main__":
    cli()
