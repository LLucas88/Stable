"""Configuration management for CRM CLI - Base module."""

import json
import base64
from pathlib import Path


CONFIG_DIR = Path.cwd() / ".crm-cli"
CONFIG_FILE = CONFIG_DIR / "config.json"
THIRD_LOGIN_CONTEXT_PREFIX = "third_login_"
THIRD_LOGIN_CONTEXT_FIELDS = (
    "channel",
    "codeVerifier",
    "authTempCode",
    "token",
    "mobile",
    "wdid",
    "extInfo",
    "accountList",
    "selectedAccountId",
    "selectedChannel",
)

def ensure_config_dir():
    """Ensure config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _encode_value(value: str) -> str:
    """Base64 encode a string value."""
    return base64.b64encode(value.encode("utf-8")).decode("utf-8")


def _decode_value(value: str) -> str:
    """Base64 decode a string value."""
    return base64.b64decode(value.encode("utf-8")).decode("utf-8")


def load_config() -> dict:
    """Load configuration from disk and decode values."""
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        raw_config = json.load(f)

    config = {}
    for key, value in raw_config.items():
        if isinstance(value, str):
            try:
                config[key] = _decode_value(value)
            except Exception:
                # 兼容未加密的旧配置
                config[key] = value
        else:
            config[key] = value
    return config


def save_config(config: dict):
    """Save configuration to disk with encoded values."""
    ensure_config_dir()

    encoded_config = {}
    for key, value in config.items():
        if isinstance(value, str):
            encoded_config[key] = _encode_value(value)
        else:
            # 非字符串类型（如 dict, int, list）不加密
            encoded_config[key] = value

    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(encoded_config, f, indent=2)


def set_auth(auth_data: dict):
    """Store auth credentials from login response.

    Args:
        auth_data: Complete auth data dict from login response
    """
    config = load_config()

    for key, value in auth_data.items():
        if value is not None:
            config[key] = value

    save_config(config)


def get_third_login_context() -> dict:
    """Load stored third login context from disk."""
    config = load_config()
    context = {}
    for field in THIRD_LOGIN_CONTEXT_FIELDS:
        key = f"{THIRD_LOGIN_CONTEXT_PREFIX}{field}"
        value = config.get(key)
        if value is not None and value != "":
            context[field] = value
    return context


def update_third_login_context(context: dict):
    """Merge third login context into local config."""
    config = load_config()
    for field in THIRD_LOGIN_CONTEXT_FIELDS:
        if field not in context:
            continue
        key = f"{THIRD_LOGIN_CONTEXT_PREFIX}{field}"
        value = context[field]
        if value is None:
            config.pop(key, None)
        else:
            config[key] = value
    save_config(config)


def clear_third_login_context():
    """Clear stored third login context."""
    config = load_config()
    for field in THIRD_LOGIN_CONTEXT_FIELDS:
        config.pop(f"{THIRD_LOGIN_CONTEXT_PREFIX}{field}", None)
    save_config(config)


def clear_config():
    """Clear stored configuration."""
    save_config({})
