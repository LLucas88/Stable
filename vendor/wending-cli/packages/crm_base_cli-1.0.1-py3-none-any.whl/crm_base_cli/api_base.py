"""CRM API Base Client.

提供所有子模块共用的 API 基础能力:
- HTTP 请求构建
- 认证检查
- 响应处理
- xtop/HSF 协议支持
"""

import hashlib
import json
import time
import uuid
import urllib.parse
import urllib.request
import urllib.error
from typing import Optional

AI_GATEWAY_URL = "https://ppe-open.shop.ele.me/OpenCli/cli/api/crm"

class NaposAPIBase:
    """Napos platform API 基类，提供公共方法。"""

    def __init__(self, wnToken: str = None):
        self.wnToken = wnToken

    def _load_config_if_needed(self, config_module, require_auth: bool = True):
        if not self.wnToken:
            cfg = config_module.load_config()
            self.wnToken = self.wnToken or cfg.get("wnToken")

        # 检查是否成功加载认证信息
        if require_auth and not self.get_token():
            raise RuntimeError(
                "未登录或登录已过期，请先运行:\n"
                "  crm-base-cli third login auth"
            )

    def _build_headers(self) -> dict:
        return {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*"
        }

    def _generate_request_id(self) -> str:
        """Generate unique request ID."""
        return f"{uuid.uuid4().hex.upper()}|{int(time.time() * 1000)}"

    def _fill_defaults(self, target: dict, defaults: dict):
        """Fill in default values for missing or empty fields.
        
        If a value is False, it will be removed from target (caller's signal to exclude).
        """
        for key, value in defaults.items():
            if key not in target or target[key] is None or target[key] == "":
                target[key] = value
        # Remove fields set to False
        for key in [k for k, v in target.items() if v is False]:
            del target[key]

    def _check_auth(self):
        """Check if auth credentials are set."""
        if not self.get_token():
            raise RuntimeError(
                "未登录或登录已过期，请先运行:\n"
                "  crm-base-cli third login auth"
            )

    def get_token(self) -> Optional[str]:
        return self.wnToken

    def get_real_url(self, default_url: str) -> str:
        if self.wnToken:
            return AI_GATEWAY_URL
        return default_url

    def _do_request(self,
                    url: str,
                    body: dict,
                    headers: dict,
                    timeout: int = 3,
                    method: str = "POST",
                    use_gateway: bool = True
                    ) -> dict:
        # 添加 x-eleme-requestid 头
        request_id = self._generate_request_id()
        headers["x-eleme-requestid"] = request_id
        
        # wnToken 模式且允许走网关：添加 origin-url 和 wn-tk 头
        if self.wnToken and use_gateway:
            headers["origin-url"] = url
            headers["wn-tk"] = self.wnToken
            url = self.get_real_url(url)

        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp_body = resp.read().decode("utf-8")
                result = json.loads(resp_body)
                return self._handle_response(result)
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8") if e.fp else ""
            raise RuntimeError(f"API request failed ({e.code}): {error_body}")

    # =========================================================================
    # xtop 协议
    # =========================================================================

    def _xtop_request(self,
                      url: str,
                      body: dict,
                      headers: dict = None,
                      require_auth: bool = True,
                      timeout: int = 3,
                      method: str = "POST"
                      ) -> dict:
        if require_auth:
            self._check_auth()

        metas = body.get("metas") or {}
        if require_auth:
            self._fill_defaults(metas, {
                "ksid": self.get_token(),
            })
        body["metas"] = metas

        req_headers = self._build_headers()
        self._fill_defaults(req_headers, headers or {})

        # require_auth=False 时不走 Gateway，直连业务服务
        if not require_auth:
            return self._do_request(url, body, req_headers, timeout, method, use_gateway=False)
        return self._do_request(url, body, req_headers, timeout, method)


    # =========================================================================
    # HSF 协议
    # =========================================================================

    HSF_GATEWAY_URL = "https://ppe-open.shop.ele.me/OpenCli/cli/api/crm"

    def _hsf_request(self,
                     interface_name: str,
                     method_name: str,
                     method_signature: list,
                     args: list,
                     headers: dict = None,
                     require_auth: bool = True,
                     method: str = "POST"
                     ) -> dict:
        """HSF 协议请求。

        Args:
            interface_name: HSF 接口名称
            method_name: 方法名称
            method_signature: 方法签名，JSON 数组，如 ["java.lang.String"]
            args: 参数列表，JSON 数组，如 ["value1"]
            headers: 额外请求头
            require_auth: 是否需要认证
            method: HTTP 方法

        Returns:
            响应数据字典
        """
        if require_auth:
            self._check_auth()

        body = {
            "args": args,
        }

        req_headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json",
            "interfaceName": interface_name,
            "methodName": method_name,
            "methodSignature": ",".join(method_signature),
        }
        self._fill_defaults(req_headers, headers or {})
        return self._do_request(
            self.HSF_GATEWAY_URL, body, req_headers,
            timeout=10, method=method
        )

    def _handle_response(self, result: dict) -> dict:
        if result.get("status") == "success" and "data" in result:
            data = result.get("data", {})
            if isinstance(data, dict) and "result" in data:
                return data["result"]
            return data

        # ncp 格式
        if "result" in result:
            if result.get("error"):
                error = result["error"]
                raise RuntimeError(f"API error: {error}")
            return result["result"]

        # agw/h5api 格式 - 带 gwOpsInfo
        if "gwOpsInfo" in result:
            if not result.get("success", True):
                error_info = result.get("gwOpsInfo", {}).get("error", {})
                error_msg = result.get("resultMsg") or result.get("resultMessage", "")
                error_key = error_info.get("key", "UNKNOWN")
                raise RuntimeError(f"API error [{error_key}]: {error_msg}")
            return result["data"] if "data" in result else result

        # xtop 格式 - success 字段
        if "success" in result:
            if not result.get("success", True):
                error_code = result.get("errorCode", "UNKNOWN")
                error_msg = result.get("errorMsg", "Unknown error")
                raise RuntimeError(f"API error [{error_code}]: {error_msg}")
            return result.get("data") or result.get("result") or result

        # xtop 格式 - succeed 字段 (登录接口等)
        if "succeed" in result:
            if not result.get("succeed", True):
                # 登录接口的错误信息在 failureData 中
                failure_data = result.get("failureData") or {}
                error_code = failure_data.get("loginFailType") or result.get("errorCode", "UNKNOWN")
                error_msg = failure_data.get("errorMessage") or result.get("errorMsg", "Unknown error")
                raise RuntimeError(f"API error [{error_code}]: {error_msg}")
            return result.get("successData") or result.get("data") or result.get("result") or result

        return result
